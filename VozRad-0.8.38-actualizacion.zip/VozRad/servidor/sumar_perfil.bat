@echo off
chcp 65001 >nul
title VozRad - sumar perfil de otro equipo
cd /d "%~dp0"
echo Suma a este equipo lo aprendido en otro (p. ej. el Mac) sin reemplazar nada de lo tuyo.
echo Cierra la ventana del motor (iniciar) antes de continuar.
pause
.venv\Scripts\python.exe perfil_portatil.py sumar
echo.
pause

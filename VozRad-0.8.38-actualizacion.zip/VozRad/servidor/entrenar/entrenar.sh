#!/usr/bin/env bash
# VozRad - entrena Parakeet con tu voz.
#   bash /mnt/c/VozRad/servidor/entrenar/entrenar.sh --prueba    ensayo corto (~10 min), no guarda modelo
#   bash /mnt/c/VozRad/servidor/entrenar/entrenar.sh             entrenamiento completo
"$HOME/vozrad-entrenar/bin/python" -u /mnt/c/VozRad/servidor/entrenar/vozrad_nemo.py entrenar "$@" 2>&1 | tee /mnt/c/VozRad/entrenamiento/entrenar.log

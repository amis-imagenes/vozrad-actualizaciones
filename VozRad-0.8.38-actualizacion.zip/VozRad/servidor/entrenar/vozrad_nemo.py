"""
VozRad - medir y entrenar Parakeet con tu voz (corre dentro de Ubuntu/WSL, con el entorno de instalar.sh).

  medir                 errores del modelo ORIGINAL en tus frases de prueba (las más recientes, nunca usadas
                        para entrenar)
  medir --modelo X      lo mismo con un modelo entrenado (archivo .nemo)
  entrenar --prueba     ensayo corto (~40 pasos) para comprobar memoria y velocidad; no guarda modelo
  entrenar              entrenamiento completo; guarda entrenamiento/modelos/vozrad-AAAAMMDD-HHMM.nemo y
                        lo mide al final contra el original

Datos: C:\\VozRad\\entrenamiento\\datos\\{entrenar,validar,prueba}.jsonl (armar_entrenamiento.bat).
Todo queda en el PC. Nada sale a internet salvo la descarga del modelo original de NVIDIA (la primera vez).
"""
import argparse
import datetime as dt
import json
import re
import sys
import time
import traceback
import unicodedata
from pathlib import Path

ENT = Path("/mnt/c/VozRad/entrenamiento")
DATOS = ENT / "datos"
MODELOS = ENT / "modelos"
BASE = "nvidia/parakeet-tdt-0.6b-v3"

# palabras donde un error es grave: se cuentan aparte
CRITICAS = {"derecho", "derecha", "derechos", "derechas", "izquierdo", "izquierda", "izquierdos", "izquierdas",
            "no", "sin", "ni", "leve", "leves", "moderado", "moderada", "severo", "severa", "bilateral"}


def normal(t: str) -> list[str]:
    """Palabras en minúscula, sin puntuación (las tildes se conservan: importan en la ortografía)."""
    t = unicodedata.normalize("NFC", (t or "").lower())
    return re.findall(r"[^\W_]+", t)


def leer(nombre: str) -> list[dict]:
    p = DATOS / f"{nombre}.jsonl"
    if not p.exists():
        sys.exit(f"[VozRad] No encontré {p}. Ejecuta armar_entrenamiento.bat en Windows.")
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


def cargar(modelo: str | None):
    import nemo.collections.asr as nemo_asr
    if modelo:
        m = nemo_asr.models.ASRModel.restore_from(modelo, map_location="cuda")
    else:
        m = nemo_asr.models.ASRModel.from_pretrained(BASE)
    return m.cuda().eval()


def errores(ref: list[str], hip: list[str]):
    """(sustituciones+borrados+inserciones, palabras de referencia, errores en palabras críticas)."""
    import difflib
    sm = difflib.SequenceMatcher(None, ref, hip, autojunk=False)
    e = crit = 0
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            continue
        e += max(i2 - i1, j2 - j1)
        if set(ref[i1:i2]) & CRITICAS or set(hip[j1:j2]) & CRITICAS:
            crit += 1
    return e, len(ref), crit


def medir(m, filas: list[dict], titulo: str, L: list[str], lote: int = 16):
    import torch
    t0 = time.time()
    hips = []
    with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
        for i in range(0, len(filas), lote):
            out = m.transcribe([f["audio_filepath"] for f in filas[i:i + lote]], batch_size=lote, verbose=False)
            hips += [getattr(o, "text", o) for o in out]
    E = N = C = 0
    peores = []
    for f, h in zip(filas, hips):
        e, n, c = errores(normal(f["text"]), normal(h))
        E, N, C = E + e, N + n, C + c
        if e:
            peores.append((e, f["text"], h))
    seg = sum(f.get("duration", 0) for f in filas)
    L += [f"{titulo}: {len(filas)} frases ({seg / 60:.0f} min de voz) · palabras erradas {E}/{N} = {100 * E / max(N, 1):.2f} %"
          f" · errores en lateralidad/negación/severidad: {C} · {time.time() - t0:.0f} s"]
    peores.sort(key=lambda x: -x[0])
    return {"wer": E / max(N, 1), "errores": E, "palabras": N, "criticos": C, "hips": hips, "peores": peores[:40]}


def cmd_medir(a, L):
    filas = leer("prueba")
    m = cargar(a.modelo)
    r = medir(m, filas, f"Modelo {'ENTRENADO ' + Path(a.modelo).name if a.modelo else 'ORIGINAL'}", L)
    L += ["", "Frases con más errores (objetivo / modelo):"]
    for e, ref, hip in r["peores"]:
        L += [f"  [{e}] {ref}", f"      {hip}"]


def cmd_entrenar(a, L):
    import torch
    from omegaconf import open_dict
    try:
        import lightning.pytorch as pl
    except ImportError:  # versiones antiguas
        import pytorch_lightning as pl
    torch.set_float32_matmul_precision("high")
    entrenar, validar, prueba = leer("entrenar"), leer("validar"), leer("prueba")
    horas = sum(f["duration"] for f in entrenar) / 3600
    L += [f"Datos: entrenar {len(entrenar)} frases ({horas:.2f} h) · validar {len(validar)} · prueba {len(prueba)}"]
    m = cargar(None)
    antes = None if a.prueba else medir(m, prueba, "ANTES  (modelo original)", L)
    m.train()
    lote_seg = a.segundos_por_lote
    pasos_epoca = max(1, int(horas * 3600 / lote_seg))
    max_pasos = 40 if a.prueba else pasos_epoca * a.epocas
    with open_dict(m.cfg):
        tr = m.cfg.train_ds
        tr.manifest_filepath = str(DATOS / "entrenar.jsonl")
        tr.text_field = "text"
        tr.use_lhotse = True
        tr.batch_size = None
        tr.batch_duration = lote_seg
        tr.use_bucketing = False
        tr.shuffle = True
        tr.num_workers = 2
        tr.min_duration = 0.3
        tr.max_duration = 30.0
        for k in ("tarred_audio_filepaths", "input_cfg"):
            if k in tr:
                tr[k] = None
        va = m.cfg.validation_ds
        va.manifest_filepath = str(DATOS / "validar.jsonl")
        va.text_field = "text"
        va.use_lhotse = True
        va.batch_size = 8
        va.num_workers = 2
        m.cfg.optim.name = "adamw"
        m.cfg.optim.lr = a.lr
        m.cfg.optim.betas = [0.9, 0.98]
        m.cfg.optim.weight_decay = 1e-3
        m.cfg.optim.sched = {"name": "CosineAnnealing", "warmup_steps": min(100, max_pasos // 10),
                             "min_lr": a.lr / 20, "max_steps": max_pasos}
    m.setup_training_data(m.cfg.train_ds)
    m.setup_validation_data(m.cfg.validation_ds)
    trainer = pl.Trainer(devices=1, accelerator="gpu", precision="bf16-mixed", max_steps=max_pasos,
                         gradient_clip_val=1.0, logger=False, enable_checkpointing=False,
                         log_every_n_steps=10, num_sanity_val_steps=0,
                         limit_val_batches=0 if a.prueba else 1.0,
                         val_check_interval=max(10, pasos_epoca) if not a.prueba else max_pasos,
                         check_val_every_n_epoch=None, enable_progress_bar=True)
    m.set_trainer(trainer)
    m.setup_optimization(m.cfg.optim)
    torch.cuda.reset_peak_memory_stats()
    t0 = time.time()
    trainer.fit(m)
    dur = time.time() - t0
    pico = torch.cuda.max_memory_allocated() / 2**30
    L += [f"Entrenamiento: {max_pasos} pasos en {dur / 60:.1f} min ({dur / max_pasos:.2f} s/paso) · "
          f"memoria de la tarjeta máx. {pico:.1f} GB de 16 · lote {lote_seg:.0f} s de audio · lr {a.lr}"]
    if a.prueba:
        L += [f"Estimado para el entrenamiento completo ({pasos_epoca * a.epocas} pasos): "
              f"{pasos_epoca * a.epocas * dur / max_pasos / 60:.0f} min"]
        return
    m.eval()
    MODELOS.mkdir(parents=True, exist_ok=True)
    destino = MODELOS / f"vozrad-{dt.datetime.now():%Y%m%d-%H%M}.nemo"
    m.save_to(str(destino))
    L += [f"Modelo guardado: {destino}"]
    despues = medir(m, prueba, "DESPUÉS (modelo entrenado)", L)
    if antes:
        mejora = 100 * (antes["errores"] - despues["errores"]) / max(antes["errores"], 1)
        L += ["", f"RESULTADO: {mejora:+.0f} % de cambio en palabras erradas (meta: al menos -20 %) · "
                  f"errores críticos {antes['criticos']} -> {despues['criticos']}"]
        L += ["", "Frases que cambiaron (objetivo / antes / después):"]
        n = 0
        for f, h0, h1 in zip(prueba, antes["hips"], despues["hips"]):
            if normal(h0) != normal(h1) and n < 80:
                L += [f"  = {f['text']}", f"    antes   {h0}", f"    después {h1}"]
                n += 1


def main():
    p = argparse.ArgumentParser()
    p.add_argument("accion", choices=["medir", "entrenar"])
    p.add_argument("--modelo")
    p.add_argument("--prueba", action="store_true")
    p.add_argument("--epocas", type=int, default=6)
    p.add_argument("--lr", type=float, default=3e-5)
    p.add_argument("--segundos-por-lote", type=float, default=90.0)
    a = p.parse_args()
    nombre = f"{a.accion}{'-prueba' if a.prueba else ''}"
    L = [f"VozRad - {nombre} ({dt.datetime.now():%d-%m-%Y %H:%M})", ""]
    try:
        (cmd_medir if a.accion == "medir" else cmd_entrenar)(a, L)
    except Exception:  # noqa: BLE001
        L += ["", "ERROR:", traceback.format_exc()]
    texto = "\n".join(L) + "\n"
    ENT.mkdir(parents=True, exist_ok=True)
    salida = ENT / f"resultado-{nombre}.txt"
    salida.write_text(texto, encoding="utf-8")
    print("\n" + texto[:6000])
    print(f"[VozRad] Resultado en C:\\VozRad\\entrenamiento\\{salida.name} (envíalo a Álvaro/Claude)")


if __name__ == "__main__":
    main()

#!/bin/bash
# VozRad - mide por qué se pierde el punto final con tus dictados. Doble clic.
cd "$(dirname "$0")" || exit 1
if [ ! -x .venv/bin/python ]; then echo "Primero haz doble clic en instalar.command"; read -r -p "Enter para cerrar..." _; exit 1; fi
echo "Prueba arreglos para el punto final con tus dictados. Tarda 5-15 minutos."
caffeinate -i .venv/bin/python evaluar_punto.py
open ~/Desktop 2>/dev/null
echo
read -r -p "Presiona Enter para cerrar..." _

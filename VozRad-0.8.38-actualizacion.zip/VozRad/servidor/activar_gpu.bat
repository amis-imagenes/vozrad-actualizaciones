@echo off
chcp 65001 >nul
title VozRad - activar tarjeta grafica
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Primero ejecuta instalar.bat
  pause & exit /b 1
)
echo Cierra la ventana del motor (iniciar) antes de continuar.
pause
.venv\Scripts\python.exe gpu.py activar
pause

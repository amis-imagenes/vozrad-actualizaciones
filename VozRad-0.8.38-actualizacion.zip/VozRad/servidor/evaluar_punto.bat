@echo off
chcp 65001 >nul
title VozRad - evaluar el punto final
cd /d "%~dp0"
echo Cierra la ventana del motor (iniciar) antes de continuar: se usa la tarjeta grafica.
pause
.venv\Scripts\python.exe evaluar_punto.py
echo.
pause

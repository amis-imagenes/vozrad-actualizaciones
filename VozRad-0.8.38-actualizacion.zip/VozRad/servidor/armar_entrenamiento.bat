@echo off
chcp 65001 >nul
title VozRad - armar datos de entrenamiento
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Primero ejecuta instalar.bat
  pause & exit /b 1
)
echo Junta tus frases dictadas con tus informes guardados. Tarda 1-5 minutos. No cambia nada de VozRad.
.venv\Scripts\python.exe armar_entrenamiento.py
echo.
pause

#!/bin/bash
# VozRad - arma los datos para entrenar el reconocedor con tu voz (no cambia nada). Doble clic.
cd "$(dirname "$0")" || exit 1
if [ ! -x .venv/bin/python ]; then echo "Primero haz doble clic en instalar.command"; read -r -p "Enter para cerrar..." _; exit 1; fi
echo "Junta tus frases dictadas con tus informes guardados. Tarda 1-5 minutos."
caffeinate -i .venv/bin/python armar_entrenamiento.py
open ~/Desktop 2>/dev/null
echo
read -r -p "Presiona Enter para cerrar..." _

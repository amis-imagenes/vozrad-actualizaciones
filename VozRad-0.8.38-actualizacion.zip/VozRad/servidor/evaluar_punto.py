"""
VozRad - mide con TUS dictados por qué se pierde el «punto» al final de la frase y prueba arreglos.

Para cada frase guardada (audio + lo que oyó el motor) busca en tu informe final si después de esa frase
había un punto. Separa:
  · frases donde el informe tiene punto y VozRad no lo puso   -> «punto perdido»
  · frases donde el informe sigue sin punto (coma o palabra)  -> «sin punto» (para medir falsas alarmas)
y vuelve a reconocer esos audios de varias maneras (con la tarjeta gráfica tarda pocos minutos):
  A  el motor actual
  B  con más silencio al final del audio
  C  Canary (el modelo grande)
  D  solo el último segundo y medio del audio (Parakeet)    E  lo mismo con Canary
Deja en el Escritorio VozRad-evaluacion-punto.txt (sin audio) para enviarlo a Álvaro/Claude.
No cambia nada de VozRad.
"""
import collections
import datetime as dt
import random
import re
import sys
import time
import wave
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import armar_entrenamiento as A  # noqa: E402

MAX_POR_GRUPO = 250
FIN_DICHO = re.compile(r"\b(punto|aparte|parte|aparta|seguido|l[ií]nea|p[aá]rrafo)\W*$", re.I)


def leer_wav(p: Path):
    """Audio como lo recibe el motor desde el panel: float32 entre -1 y 1."""
    with wave.open(str(p)) as w:
        x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
        return x, w.getframerate()


def dice_punto(t: str) -> bool:
    return bool(FIN_DICHO.search((t or "").strip()))


def casos():
    pos, neg, cont = [], [], collections.Counter()
    for nombre, hist in A.fuentes():
        finales = {}
        for r in A.leer_jsonl(hist / "correcciones_manuales.jsonl"):
            for it in r.get("dictado", []):
                c = (it.get("crudo") or "").strip()
                fin = (r.get("final") or {}).get(it.get("campo"), "") or ""
                if c and fin:
                    finales[c] = fin
        for arch in sorted(hist.glob("20??-??-??.jsonl")):
            regs = [r for r in A.leer_jsonl(arch) if r.get("audio") and r.get("crudo")]
            for i, r in enumerate(regs):
                crudo = r["crudo"].strip()
                if crudo not in finales:
                    continue
                if dice_punto(crudo):
                    cont["frases donde el motor SÍ oyó el punto"] += 1
                    continue
                final = finales[crudo]
                tf = A.tokens(final)
                v = A.ventana(A.procesado(crudo) or [t[1] for t in A.tokens(crudo)], [t[1] for t in tf])
                if not v:
                    continue
                resto = final[tf[v[1] - 1][3]:].lstrip(" \t")
                sig = regs[i + 1]["crudo"].strip() if i + 1 < len(regs) else ""
                if resto[:1] == ".":
                    if re.match(r"\W*punto\b", sig, re.I):
                        cont["punto dicho en la frase siguiente (no se perdió)"] += 1
                        continue
                    grupo = pos
                elif resto[:1] in (",", ";") or resto[:1].isalpha():
                    grupo = neg
                else:
                    continue
                wav = hist / r["audio"]
                if wav.exists():
                    grupo.append({"wav": wav, "crudo": crudo, "orden": f"{arch.stem}/{wav.name}", "fuente": nombre})
    pos.sort(key=lambda c: c["orden"])
    neg.sort(key=lambda c: c["orden"])
    cont["punto perdido (el informe tiene punto, VozRad no)"] = len(pos)
    cont["sin punto en el informe (para medir falsas alarmas)"] = len(neg)
    return pos[-MAX_POR_GRUPO:], neg[-MAX_POR_GRUPO:], cont


def main():
    import motores
    import texto
    L = [f"VozRad - evaluación del punto final ({dt.datetime.now():%d-%m-%Y %H:%M})", ""]
    try:
        pos, neg, cont = casos()
        L += ["Frases de tus informes:"] + [f"  {k}: {v}" for k, v in cont.most_common()] + [""]
        if not pos:
            L += ["No encontré frases con el punto perdido."]
            raise SystemExit
        cfg = dict(texto.CONFIG.datos())
        disp = cfg.get("dispositivo", "cpu")
        print(f"[VozRad] Cargando modelos ({disp})...", flush=True)
        par = motores.MotorParakeet(cfg.get("hilos_cpu") if isinstance(cfg.get("hilos_cpu"), int) else None, disp)
        try:
            can = motores.MotorCanary(cfg.get("hilos_cpu") if isinstance(cfg.get("hilos_cpu"), int) else None, disp)
        except Exception as e:  # noqa: BLE001
            can = None
            L += [f"(Canary no disponible: {e})"]
        L += [f"Motor: {par.descripcion}", ""]

        def variantes(pcm, sr):
            x = pcm
            out = {}
            motores.MotorParakeet.punto_por_tiempo = True
            out["A"] = par.reconocer(pcm)
            d = motores.ULTIMO_PUNTO or {}
            out["hueco"], out["voz"] = d.get("hueco"), d.get("voz")
            silencio = np.zeros(int(0.8 * sr), dtype=pcm.dtype)
            out["B"] = par.reconocer(np.concatenate([pcm, silencio]))
            out["C"] = can.reconocer(pcm) if can else ""
            cola = pcm[-int(1.5 * sr):] if pcm.size > int(1.5 * sr) else pcm
            motores.MotorParakeet.punto_por_tiempo = False
            t1 = time.perf_counter()
            out["D"] = par.reconocer(np.concatenate([cola, silencio]))
            out["ms_D"] = (time.perf_counter() - t1) * 1000
            motores.MotorParakeet.punto_por_tiempo = True
            t1 = time.perf_counter()
            out["E"] = can.reconocer(np.concatenate([cola, silencio])) if can else ""
            out["ms_E"] = (time.perf_counter() - t1) * 1000
            out["A+D"] = out["A"] if dice_punto(out["A"]) else (out["D"] if dice_punto(out["D"]) else out["A"])
            out["A+E"] = out["A"] if dice_punto(out["A"]) else (out["E"] if dice_punto(out["E"]) else out["A"])
            out["rms_final"] = float(np.sqrt(np.mean(x[-int(0.3 * sr):] ** 2))) if x.size else 0.0
            return out

        res = {"pos": [], "neg": []}
        t0 = time.time()
        total = len(pos) + len(neg)
        for nombre, grupo in (("pos", pos), ("neg", neg)):
            for n, c in enumerate(grupo):
                try:
                    pcm, sr = leer_wav(c["wav"])
                    o = variantes(pcm, sr)
                except Exception as e:  # noqa: BLE001
                    print(f"  error con {c['wav'].name}: {e}")
                    continue
                o.update(c)
                res[nombre].append(o)
                hechos = len(res["pos"]) + len(res["neg"])
                if hechos % 25 == 0:
                    print(f"[VozRad]   {hechos}/{total} frases ({time.time() - t0:.0f} s)", flush=True)

        def tasa(lista, k):
            return sum(dice_punto(o[k]) for o in lista), len(lista)

        L += ["Resultado (cuántas veces cada forma termina en «punto»):",
              "                                     punto perdido     sin punto (falsa alarma)"]
        nombres = {"A": "A motor actual", "B": "B + silencio al final", "C": "C Canary", "D": "D último 1,5 s",
                   "E": "E Canary último 1,5 s", "A+D": "A y si no, D", "A+E": "A y si no, E"}
        for k, txt in nombres.items():
            p, np_ = tasa(res["pos"], k)
            f, nf = tasa(res["neg"], k)
            L.append(f"  {txt:<30} {p:4d}/{np_:<4d} ({100 * p / max(np_, 1):4.0f} %)   {f:4d}/{nf:<4d} ({100 * f / max(nf, 1):4.0f} %)")
        todos = res["pos"] + res["neg"]
        L += ["", f"Tiempo extra por frase: D {np.median([o['ms_D'] for o in todos]):.0f} ms · "
                  f"E {np.median([o['ms_E'] for o in todos]):.0f} ms (mediana)"]
        L += ["", "Hueco entre la última palabra y el «.» del motor, y voz después (s):"]
        for nombre, txt in (("pos", "punto perdido"), ("neg", "sin punto")):
            hs = [o["hueco"] for o in res[nombre] if o.get("hueco") is not None]
            vs = [o["voz"] for o in res[nombre] if o.get("voz") is not None]
            q = lambda a: " ".join(f"{np.percentile(a, p):.2f}" for p in (10, 25, 50, 75, 90)) if a else "-"  # noqa: E731
            L.append(f"  {txt:<14} hueco p10-p90: {q(hs):<32} voz p10-p90: {q(vs)}  (n={len(hs)}/{len(vs)})")
        L += ["", "Ejemplos de punto perdido (oído antes / A / B / C / D / E):"]
        for o in random.Random(3).sample(res["pos"], min(60, len(res["pos"]))):
            L += [f"  - {o['crudo']}   [hueco {o.get('hueco')} voz {o.get('voz')}]",
                  f"      A {o['A']!r}", f"      B {o['B']!r}", f"      C {o['C']!r}", f"      D {o['D']!r}", f"      E {o['E']!r}"]
        L += ["", "Falsas alarmas (sin punto en el informe, pero alguna forma dijo «punto»):"]
        malos = [o for o in res["neg"] if any(dice_punto(o[k]) for k in "ABCDE")]
        for o in malos[:40]:
            L += [f"  - {o['crudo']}", f"      A {o['A']!r} | B {o['B']!r} | C {o['C']!r} | D {o['D']!r} | E {o['E']!r}"]
    except SystemExit:
        pass
    except Exception:  # noqa: BLE001
        import traceback
        L += ["", "ERROR:", traceback.format_exc()]
    salida = "\n".join(L) + "\n"
    destino = A.escritorio() / "VozRad-evaluacion-punto.txt"
    destino.write_text(salida, encoding="utf-8")
    print(salida[:3000])
    print(f"[VozRad] Resultado en: {destino} (sin audio; envíalo a Álvaro/Claude)")
    try:
        import os
        if os.name == "nt":
            os.startfile(str(destino))  # noqa: S606
    except Exception:  # noqa: BLE001
        pass


if __name__ == "__main__":
    main()

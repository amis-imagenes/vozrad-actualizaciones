// VozRad - puente con la página de MultiRisWeb (corre en el contexto de la página, "MAIN world").
// Es la única parte que toca el editor CKEditor del RIS. Recibe órdenes de content.js
// por window.postMessage y responde por el mismo canal.
(() => {
  "use strict";
  if (window.__vozradBridge) return;
  window.__vozradBridge = true;

  const TAG = "__vozrad";
  let cursorManual = {};
  let rangoGuardado = {};    // campo -> último cursor dentro del editor (por si el foco se va a otro lado)
  let ultimaSeleccion = { texto: "", campo: "", t: 0 };
  let ultimaInsercion = { campo: "", texto: "", t: 0, origen: "" };   // para "Entrenar palabra" y "Frase tipo"
  let propios = new Set();   // epónimos que siempre van con mayúscula (desde nombres_propios.txt)   // campo -> true si el usuario hizo clic dentro (inserta en el cursor, no al final)

  const editores = () => (window.CKEDITOR && window.CKEDITOR.instances) ? window.CKEDITOR.instances : {};
  const porPrefijo = (prefijo) => {
    const inst = editores();
    const nombre = Object.keys(inst).find((k) => k.startsWith(prefijo));
    return nombre ? inst[nombre] : null;
  };
  const textoDe = (ed) => {
    try { return (ed.editable().$.innerText || "").replace(/ /g, " ").replace(/​/g, ""); }
    catch (_) { return ""; }
  };

  // Texto de un rango del editor, con los <br> (salto de línea simple) convertidos en "\n".
  // Sin esto, tras un salto de línea simple el texto anterior parecía continuar en la misma línea
  // y se agregaba un espacio al inicio de la línea nueva.
  function textoDeRango(rr) {
    const div = document.createElement("div");
    div.appendChild(rr.cloneContents().$);
    div.querySelectorAll("br").forEach((b) => b.replaceWith("\n"));
    return (div.textContent || "").replace(/\u00a0/g, " ").replace(/\u200b/g, "");
  }

  // Texto del mismo párrafo que está justo antes del cursor.
  function antesDelCursor(ed) {
    try {
      const r = ed.getSelection().getRanges()[0];
      const path = new CKEDITOR.dom.elementPath(r.startContainer, ed.editable());
      const bloque = path.block || path.blockLimit || ed.editable();
      const rr = ed.createRange();
      rr.setStartAt(bloque, CKEDITOR.POSITION_AFTER_START);
      rr.setEnd(r.startContainer, r.startOffset);
      return textoDeRango(rr);
    } catch (_) {
      return textoDe(ed);
    }
  }

  // Texto del mismo párrafo justo DESPUÉS del cursor (para no dejar palabras pegadas al insertar en medio).
  function despuesDelCursor(ed) {
    try {
      const r = ed.getSelection().getRanges()[0];
      const path = new CKEDITOR.dom.elementPath(r.endContainer, ed.editable());
      const bloque = path.block || path.blockLimit || ed.editable();
      const rr = ed.createRange();
      rr.setStart(r.endContainer, r.endOffset);
      rr.setEndAt(bloque, CKEDITOR.POSITION_BEFORE_END);
      return textoDeRango(rr).replace(/\n$/, "");          // el <br> de relleno del final no cuenta
    } catch (_) {
      return "";
    }
  }

  // Ajusta espacio inicial y mayúscula según el texto que hay justo antes del punto de inserción.
  function prepararCon(previoCrudo, t) {
    const previo = previoCrudo.replace(/\s+$/, (m) => (m.includes("\n") ? "\n" : m ? " " : ""));
    const vacio = previo.trim() === "";
    const abreviatura = /\b(?:vs|aprox|dr|dra|sr|sra|ej|cf)\.\s*$/i.test(previo);   // «hemangioma vs.» + «metástasis»
    const finFrase = vacio || (/[.?!:]\s*$/.test(previo) && !abreviatura) || /\n$/.test(previo);
    // «punto aparte» dicho al inicio de la frase siguiente: el punto cierra el párrafo anterior
    // (si ya tenía punto, o el campo está vacío, no se repite)
    if (/^\./.test(t) && (vacio || /[.?!:;]\s*$/.test(previo))) {
      t = t.replace(/^\.[ \t]*/, "");
      if (!t) return "";
    }
    if (t.startsWith("\n")) return t;
    t = t.replace(/^\s+/, "");
    if (finFrase && !/^[,.;:)]/.test(t)) t = t.charAt(0).toUpperCase() + t.slice(1);
    else if (!finFrase) {
      // continúa una frase (p.ej. después de una coma): el motor puso mayúscula, se quita
      // incluye palabras de una letra ("Y", "A", "O"), pero no siglas (TC) ni niveles (L4, C5)
      const m = t.match(/^([A-ZÁÉÍÓÚÑ])([a-záéíóúñü]*)(?=$|[\s,.;:)])/);
      const palabra = m ? (m[1] + m[2]) : "";
      const letraSuelta = palabra.length === 1 && !"YAOEU".includes(palabra);
      if (m && !letraSuelta && !propios.has(palabra.toLowerCase())) t = m[1].toLowerCase() + t.slice(1);
    }
    // «L5» + «- S1» (guion dictado en la frase siguiente) -> «L5-S1»
    if (!vacio && /[\wÁÉÍÓÚÑáéíóúñü)]$/.test(previo) && /^-\s*\S/.test(t)) return t.replace(/^-\s*/, "-");
    if (!vacio && !/[\s(\n]$/.test(previo) && !/^[,.;:)\s]/.test(t)) t = " " + t;
    return t;
  }
  function prepararTexto(ed, t) { return prepararCon(antesDelCursor(ed), t); }

  // Texto de un rango nativo del DOM, con <br> como "\n".
  function textoNativo(rango) {
    const div = rango.startContainer.ownerDocument.createElement("div");
    div.appendChild(rango.cloneContents());
    div.querySelectorAll("br").forEach((b) => b.replaceWith("\n"));
    return (div.textContent || "").replace(/\u00a0/g, " ").replace(/\u200b/g, "");
  }
  const BLOQUES = /^(P|DIV|LI|TD|TH|H[1-6]|BLOCKQUOTE|PRE|BODY)$/;

  // Escribe una parte en el punto REAL de inserción: primero se inserta una marca invisible donde
  // el editor va a escribir y se mira el texto alrededor de ESA marca (la selección del editor puede
  // estar desactualizada si el foco se fue a otra ventana), y luego se reemplaza la marca por el texto.
  const MARCA = "\u2063";
  function escribirParte(ed, parte, ultima) {
    ed.insertText(MARCA);
    const raiz = ed.editable().$;
    const doc = raiz.ownerDocument;
    const tw = doc.createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
    let nodo = null, idx = -1;
    for (let n = tw.nextNode(); n; n = tw.nextNode()) { const k = n.data.indexOf(MARCA); if (k >= 0) { nodo = n; idx = k; } }
    if (!nodo) { const listo = prepararTexto(ed, parte); ed.insertText(listo); return { previo: "", listo }; }   // por si acaso
    let bloque = nodo.parentNode;
    while (bloque && bloque !== raiz && !BLOQUES.test(bloque.nodeName)) bloque = bloque.parentNode;
    bloque = bloque || raiz;
    const r1 = doc.createRange(); r1.setStart(bloque, 0); r1.setEnd(nodo, idx);
    const previo = textoNativo(r1);
    const r2 = doc.createRange(); r2.setStart(nodo, idx + 1); r2.setEnd(bloque, bloque.childNodes.length);
    const despues = textoNativo(r2).replace(/\n$/, "");
    let listo = prepararCon(previo, parte);
    if (ultima && !/\s$/.test(listo) && /^[A-Za-zÁÉÍÓÚÑáéíóúñü0-9(]/.test(despues)) listo += " ";
    // un espacio al inicio/fin de un trozo de texto se vería pegado: va como espacio duro
    const visible = listo.replace(/^ /, /\S$/.test(nodo.data.slice(0, idx)) ? " " : "\u00a0").replace(/ $/, "\u00a0");
    nodo.data = nodo.data.slice(0, idx) + visible + nodo.data.slice(idx + 1);
    ultimasPartes.push({ nodo, ini: idx + (visible.length - visible.replace(/^[ \u00a0]+/, "").length), fin: idx + visible.replace(/[ \u00a0]+$/, "").length });
    // quitar marcas que hubieran quedado de antes
    const tw2 = doc.createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
    for (let n = tw2.nextNode(); n; n = tw2.nextNode()) if (n !== nodo && n.data.includes(MARCA)) n.data = n.data.split(MARCA).join("");
    try {
      const r = ed.createRange();
      r.setStart(new CKEDITOR.dom.text(nodo), Math.min(idx + visible.length, nodo.data.length));
      r.collapse(true);
      ed.getSelection().selectRanges([r]);
    } catch (_) {}
    return { previo, listo, bloque: bloque.nodeName };
  }

  // ¿el cursor actual está dentro de este editor?
  function rangoValido(ed) {
    try {
      const r = ed.getSelection() && ed.getSelection().getRanges()[0];
      if (!r) return null;
      const ed0 = ed.editable();
      return (ed0.equals(r.startContainer) || ed0.contains(r.startContainer)) ? r : null;
    } catch (_) { return null; }
  }
  function guardarRango(ed, campo) {
    const r = rangoValido(ed);
    if (r) rangoGuardado[campo] = r.clone();
  }

  function alFinal(ed, campo) {
    if (cursorManual[campo]) {
      // hiciste clic en la plantilla: escribir AHÍ aunque el foco esté ahora en otra parte (panel, otro campo, otra ventana)
      if (!ed.focusManager.hasFocus) { try { ed.focus(); } catch (_) {} }
      if (!rangoValido(ed) && rangoGuardado[campo]) {
        try { ed.getSelection().selectRanges([rangoGuardado[campo]]); } catch (_) {}
      }
    }
    const sel = ed.getSelection();
    if (!cursorManual[campo] || !sel || !sel.getRanges().length || !rangoValido(ed)) {
      const r = ed.createRange();
      r.moveToElementEditEnd(ed.editable());
      ed.getSelection().selectRanges([r]);
    }
  }

  // Salto de línea real del editor (igual que apretar Enter), no un "\n" dentro del texto.
  function salto(ed) {
    try { ed.execCommand("enter"); } catch (_) { ed.insertHtml("<br>"); }
  }

  let ultimasPartes = [];     // trozos de texto de la última frase escrita (para «negrita», «todo mayúsculas»…)
  let ultimaFraseEd = null;
  function insertar(ed, campo, t) {
    if (!t) return null;
    let diag = null;
    ultimasPartes = []; ultimaFraseEd = ed; ultimaNativa = null;
    ed.fire("saveSnapshot");                       // un "deshacer" = una frase dictada
    alFinal(ed, campo);
    const partes = t.split("\n");
    partes.forEach((parte, i) => {
      if (i > 0) salto(ed);
      if (!parte.trim()) return;
      const r = escribirParte(ed, parte, i === partes.length - 1);   // escribe en el punto REAL del cursor (ver escribirParte)
      if (!diag && r) {     // diagnóstico (el motor lo muestra solo si está activado): qué había antes y qué se escribió
        const cod = (x) => JSON.stringify(x).slice(1, -1);
        diag = { previo: cod((r.previo || "").slice(-30)), listo: cod((r.listo || "").slice(0, 30)), bloque: r.bloque || "", salto: i > 0 };
      }
    });
    guardarRango(ed, campo);                       // la próxima frase sigue desde aquí
    ed.fire("saveSnapshot");
    ed.fire("change");
    return diag;
  }

  function resaltar(prefijoActivo) {
    const inst = editores();
    for (const k of Object.keys(inst)) {
      const c = inst[k].container && inst[k].container.$;
      if (!c) continue;
      const activo = prefijoActivo && k.startsWith(prefijoActivo);
      c.style.outline = activo ? "3px solid #e0533d" : "";
      c.style.outlineOffset = activo ? "1px" : "";
      c.style.transition = "outline-color .2s";
    }
  }

  function engancharFoco(campos) {
    // Si haces clic en un campo, ese pasa a ser el campo activo del dictado.
    for (const [clave, info] of Object.entries(campos)) {
      const ed = porPrefijo(info.prefijo);
      if (!ed || ed.__vozrad) continue;
      ed.__vozrad = true;
      const guardarSel = () => {
        try {
          const t = (ed.getSelection() && ed.getSelection().getSelectedText() || "").replace(/\u00a0/g, " ").trim();
          if (t) ultimaSeleccion = { texto: t, campo: clave, t: Date.now() };
        } catch (_) {}
      };
      ed.on("selectionChange", guardarSel);
      // hiciste clic o te moviste con el teclado dentro del campo: el dictado va donde dejaste el cursor
      const alUsar = () => { cursorManual[clave] = true; setTimeout(() => { guardarSel(); guardarRango(ed, clave); }, 0); };
      const enganchar = () => { ed.editable().attachListener(ed.document, "mouseup", alUsar); ed.editable().attachListener(ed.document, "keyup", alUsar); };
      ed.on("contentDom", enganchar);
      try { enganchar(); } catch (_) {}
      ed.on("focus", () => {
        cursorManual[clave] = true;
        window.postMessage({ [TAG]: "evento", tipo: "foco", campo: clave }, location.origin);
      });
    }
  }

  // ================================================================== campos libres
  // Addendum, planillas y cualquier otro cuadro de texto del RIS (también dentro de marcos/iframes del
  // mismo sitio): si haces clic en uno que no es Técnica/Antecedentes/Hallazgos/Impresión, el dictado va ahí.
  let camposCfg = {};
  let libre = null;                 // {tipo: "ck", ed} | {tipo: "nativo", el}
  let ultimaNativa = null;          // {el, ini, fin} última frase escrita en un cuadro de texto simple
  const pilaNativa = [];            // para «borrar eso» en cuadros de texto simples
  const rangoEditable = new WeakMap();
  const esTextoNativo = (el) => !!el && !el.readOnly && !el.disabled &&
    (el.tagName === "TEXTAREA" || (el.tagName === "INPUT" && /^(text|search)?$/i.test(el.getAttribute("type") || "")));
  const esDeCK = (el) => !!(el && el.closest && el.closest(".cke, .cke_editable, .cke_wysiwyg_div"));
  const esEditableSuelto = (el) => !!el && el.isContentEditable && !esDeCK(el) && !(el.ownerDocument.body && el.ownerDocument.body.classList.contains("cke_editable"));
  function raizEditable(el) { while (el.parentElement && el.parentElement.isContentEditable) el = el.parentElement; return el; }
  const configurado = (nombre) => Object.values(camposCfg).some((c) => c.prefijo && nombre.startsWith(c.prefijo));

  function nombreDe(el) {
    if (!el) return "campo";
    const doc = el.ownerDocument;
    const etiqueta = (el.id && doc.querySelector(`label[for="${CSS.escape(el.id)}"]`)) || el.closest("label");
    let n = (el.getAttribute && (el.getAttribute("aria-label") || el.getAttribute("placeholder") || el.getAttribute("title"))) ||
      (etiqueta && etiqueta.textContent) || "";
    if (!n) {   // texto justo antes del campo (celda de la izquierda, título de la sección)
      const celda = el.closest("td, div");
      const previa = celda && celda.previousElementSibling;
      n = (previa && previa.textContent) || el.name || el.id || "";
    }
    n = n.replace(/\s+/g, " ").replace(/[:*]\s*$/, "").trim();
    return n.slice(0, 30) || "campo";
  }

  function marcarLibre(obj, nombre) {
    libre = obj;
    cursorManual.libre = true;
    window.postMessage({ [TAG]: "evento", tipo: "foco", campo: "libre", nombre }, location.origin);
  }

  function vigilarDocumento(doc) {
    if (!doc || doc.__vozradLibre) return;
    doc.__vozradLibre = true;
    doc.addEventListener("focusin", (e) => {
      const el = e.target;
      if (esTextoNativo(el)) marcarLibre({ tipo: "nativo", el }, nombreDe(el));
      else if (esEditableSuelto(el)) marcarLibre({ tipo: "nativo", el: raizEditable(el) }, nombreDe(raizEditable(el)));
    }, true);
    const recordar = (e) => {
      const el = e.target;
      try {
        if (esTextoNativo(el)) {
          const t = el.value.slice(el.selectionStart, el.selectionEnd).trim();
          if (t) ultimaSeleccion = { texto: t, campo: "libre", t: Date.now() };
        } else if (el && el.isContentEditable && !esDeCK(el)) {
          const sel = el.ownerDocument.getSelection();
          if (sel && sel.rangeCount) {
            rangoEditable.set(raizEditable(el), sel.getRangeAt(0).cloneRange());
            const t = sel.toString().trim();
            if (t) ultimaSeleccion = { texto: t, campo: "libre", t: Date.now() };
          }
        }
      } catch (_) {}
    };
    doc.addEventListener("mouseup", recordar, true);
    doc.addEventListener("keyup", recordar, true);
  }

  // editores CKEditor que no son los 4 campos del informe (addendum, planillas…), en esta ventana o en marcos
  function engancharCK(win) {
    let inst = {};
    try { inst = (win.CKEDITOR && win.CKEDITOR.instances) || {}; } catch (_) { return; }
    for (const [nombre, ed] of Object.entries(inst)) {
      if (ed.__vozradLibre || (win === window && configurado(nombre))) continue;
      ed.__vozradLibre = true;
      const etiqueta = () => {
        try { return nombreDe(ed.element && ed.element.$) || nombre; } catch (_) { return nombre; }
      };
      ed.on("focus", () => marcarLibre({ tipo: "ck", ed }, etiqueta()));
      ed.on("selectionChange", () => {
        try {
          const t = (ed.getSelection() && ed.getSelection().getSelectedText() || "").replace(/\u00a0/g, " ").trim();
          if (t) ultimaSeleccion = { texto: t, campo: "libre", t: Date.now() };
          if (libre && libre.ed === ed) guardarRango(ed, "libre");
        } catch (_) {}
      });
      const alUsar = () => { if (libre && libre.ed === ed) setTimeout(() => guardarRango(ed, "libre"), 0); };
      const enganchar = () => { try { ed.editable().attachListener(ed.document, "mouseup", alUsar); ed.editable().attachListener(ed.document, "keyup", alUsar); } catch (_) {} };
      ed.on("contentDom", enganchar);
      enganchar();
    }
  }

  function marcos(win, out = [], prof = 0) {
    out.push(win);
    if (prof > 4) return out;
    for (let i = 0; i < win.frames.length; i++) {
      try { const f = win.frames[i]; if (f.document) marcos(f, out, prof + 1); } catch (_) {}   // otro sitio: no se toca
    }
    return out;
  }
  function escanear() {
    if (!Object.keys(camposCfg).length) return;     // aún no se sabe cuáles son los campos del informe
    for (const w of marcos(window)) {
      try { vigilarDocumento(w.document); engancharCK(w); } catch (_) {}
    }
  }
  setInterval(escanear, 2000);

  // ¿cuántos lugares donde dictar hay en la página (y sus marcos)?
  function contarEditables() {
    let n = 0;
    for (const w of marcos(window)) {
      try {
        n += Object.keys((w.CKEDITOR && w.CKEDITOR.instances) || {}).length;
        n += w.document.querySelectorAll("textarea:not([readonly]):not([disabled]), [contenteditable=''], [contenteditable='true']").length;
      } catch (_) {}
    }
    return n;
  }

  function libreVivo() {
    if (!libre) return null;
    if (libre.tipo === "ck") { try { if (libre.ed.status === "destroyed" || !libre.ed.editable()) return null; } catch (_) { return null; } }
    else if (!libre.el.isConnected) return null;
    return libre;
  }

  function insertarNativo(el, t) {
    const doc = el.ownerDocument;
    if (el.isContentEditable) {
      el.focus();
      const sel = doc.getSelection();
      const r0 = rangoEditable.get(el);
      if (r0 && (!sel.rangeCount || !el.contains(sel.getRangeAt(0).startContainer))) { sel.removeAllRanges(); sel.addRange(r0); }
      if (!sel.rangeCount || !el.contains(sel.getRangeAt(0).startContainer)) { const r = doc.createRange(); r.selectNodeContents(el); r.collapse(false); sel.removeAllRanges(); sel.addRange(r); }
      t.split("\n").forEach((parte, i) => {
        if (i > 0) doc.execCommand("insertLineBreak");
        if (!parte.trim()) return;
        const r = sel.getRangeAt(0);
        const rp = doc.createRange(); rp.setStart(el, 0); rp.setEnd(r.startContainer, r.startOffset);
        const previo = textoNativo(rp).split("\n").pop();
        doc.execCommand("insertText", false, prepararCon(previo, parte));
      });
      try { rangoEditable.set(el, sel.getRangeAt(0).cloneRange()); } catch (_) {}
      return true;
    }
    const multi = el.tagName === "TEXTAREA";
    if (!multi) t = t.replace(/\n+/g, " ");
    const v = el.value;
    const a = el.selectionStart == null ? v.length : el.selectionStart;
    const b = el.selectionEnd == null ? v.length : el.selectionEnd;
    pilaNativa.push({ el, valor: v, a, b }); if (pilaNativa.length > 30) pilaNativa.shift();
    let previo = v.slice(v.lastIndexOf("\n", a - 1) + 1, a), out = "", diag = null;
    t.split("\n").forEach((parte, i) => {
      if (i > 0) { out += "\n"; previo = ""; }
      if (!parte.trim()) return;
      const listo = prepararCon(previo, parte);
      if (!diag) diag = { previo: JSON.stringify(previo.slice(-30)).slice(1, -1), listo: JSON.stringify(listo.slice(0, 30)).slice(1, -1), bloque: el.tagName, salto: i > 0 };
      out += listo; previo += listo;
    });
    if (/^[A-Za-zÁÉÍÓÚÑáéíóúñü0-9(]/.test(v.slice(b)) && !/\s$/.test(out)) out += " ";
    el.focus();
    el.setRangeText(out, a, b, "end");
    ultimaNativa = { el, ini: a + (out.length - out.replace(/^\s+/, "").length), fin: a + out.replace(/\s+$/, "").length };
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return diag || true;
  }

  function resaltarLibre(activo) {
    for (const w of marcos(window)) {
      try { w.document.querySelectorAll("[data-vozrad-libre]").forEach((x) => { x.style.outline = ""; delete x.dataset.vozradLibre; }); } catch (_) {}
    }
    const l = activo && libreVivo();
    if (!l) return;
    const el = l.tipo === "ck" ? (l.ed.container && l.ed.container.$) : l.el;
    if (el) { el.style.outline = "3px solid #e0533d"; el.style.outlineOffset = "1px"; el.dataset.vozradLibre = "1"; }
  }

  // ================================================================== formato por voz
  const CASO = { mayusculas: (x) => x.toLocaleUpperCase("es"), minusculas: (x) => x.toLocaleLowerCase("es") };
  const CMD_CK = { negrita: "bold", cursiva: "italic", subrayado: "underline" };

  // Rango nativo de lo que hay que formatear: lo seleccionado en el editor o, si no hay, la última frase dictada.
  function rangoAFormatear(ed) {
    const r = rangoValido(ed);
    if (r && !r.collapsed) return { ck: r, seleccion: true };
    const partes = (ultimaFraseEd === ed ? ultimasPartes : []).filter((p) => p.nodo.isConnected && p.fin <= p.nodo.data.length && p.fin > p.ini);
    if (!partes.length) return null;
    const ck = ed.createRange();
    ck.setStart(new CKEDITOR.dom.text(partes[0].nodo), partes[0].ini);
    ck.setEnd(new CKEDITOR.dom.text(partes[partes.length - 1].nodo), partes[partes.length - 1].fin);
    return { ck, partes, seleccion: false };
  }

  function cambiarCasoRango(rangoNat, f) {
    const doc = rangoNat.startContainer.ownerDocument;
    const raiz = rangoNat.commonAncestorContainer.nodeType === 3 ? rangoNat.commonAncestorContainer.parentNode : rangoNat.commonAncestorContainer;
    const tw = doc.createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
    const nodos = [];
    for (let n = tw.nextNode(); n; n = tw.nextNode()) if (rangoNat.intersectsNode(n)) nodos.push(n);
    for (const n of nodos) {
      const a = n === rangoNat.startContainer ? rangoNat.startOffset : 0;
      const b = n === rangoNat.endContainer ? rangoNat.endOffset : n.data.length;
      n.data = n.data.slice(0, a) + f(n.data.slice(a, b)) + n.data.slice(b);
    }
  }

  function formatoCK(ed, formato) {
    const obj = rangoAFormatear(ed);
    if (!obj) return { error: "Selecciona el texto o dicta primero la frase a la que quieres dar formato." };
    ed.fire("saveSnapshot");
    if (CASO[formato]) {
      if (obj.partes) for (const p of obj.partes) p.nodo.data = p.nodo.data.slice(0, p.ini) + CASO[formato](p.nodo.data.slice(p.ini, p.fin)) + p.nodo.data.slice(p.fin);
      else {
        const sel = ed.getSelection().getNative();
        if (sel && sel.rangeCount) cambiarCasoRango(sel.getRangeAt(0), CASO[formato]);
      }
    } else {
      const cmd = ed.getCommand(CMD_CK[formato]);
      if (!cmd || cmd.state === CKEDITOR.TRISTATE_DISABLED) {
        return { error: `El editor de este campo no permite ${formato} (el RIS lo tiene desactivado).` };
      }
      try { ed.focus(); } catch (_) {}
      ed.getSelection().selectRanges([obj.ck]);
      ed.execCommand(CMD_CK[formato]);
      if (!obj.seleccion) {           // seguir dictando DESPUÉS de la frase, sin el formato
        try {
          const r = ed.getSelection().getRanges()[0];
          r.collapse(false);
          // salir de <strong>/<em>/<u> para que lo que dictes después no quede con ese formato
          let el = r.startContainer.type === CKEDITOR.NODE_TEXT ? r.startContainer.getParent() : r.startContainer, fuera = null;
          while (el && !el.equals(ed.editable()) && /^(strong|b|em|i|u|span)$/.test(el.getName())) { fuera = el; el = el.getParent(); }
          if (fuera) {
            r.setStartAfter(fuera); r.collapse(true);
            const sig = fuera.getNext();
            if (!sig || sig.type !== CKEDITOR.NODE_TEXT) { const t = new CKEDITOR.dom.text(""); t.insertAfter(fuera); r.setStart(t, 0); r.collapse(true); }
          }
          ed.getSelection().selectRanges([r]);
        } catch (_) {}
      }
    }
    ed.fire("saveSnapshot"); ed.fire("change");
    return { ok: true, sobre: obj.seleccion ? "selección" : "última frase" };
  }

  function formatoNativo(el, formato) {
    if (!CASO[formato]) return { error: "Este cuadro de texto no admite negrita, cursiva ni subrayado (solo mayúsculas/minúsculas)." };
    if (el.isContentEditable) {
      const sel = el.ownerDocument.getSelection();
      if (!sel.rangeCount || sel.isCollapsed) return { error: "Selecciona el texto al que quieres dar formato." };
      cambiarCasoRango(sel.getRangeAt(0), CASO[formato]);
      return { ok: true };
    }
    let a = el.selectionStart, b = el.selectionEnd, sobre = "selección";
    if (a === b) {
      if (!ultimaNativa || ultimaNativa.el !== el) return { error: "Selecciona el texto o dicta primero la frase a la que quieres dar formato." };
      ({ ini: a, fin: b } = ultimaNativa); sobre = "última frase";
    }
    const v = el.value;
    pilaNativa.push({ el, valor: v, a: el.selectionStart, b: el.selectionEnd });
    el.value = v.slice(0, a) + CASO[formato](v.slice(a, b)) + v.slice(b);
    el.setSelectionRange(b, b);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return { ok: true, sobre };
  }

  // editor (CKEditor) o cuadro de texto al que va el dictado de este campo
  function destino(campo, prefijo) {
    if (campo === "libre") {
      const l = libreVivo();
      return l ? (l.tipo === "ck" ? { ed: l.ed, campo: "libre" } : { el: l.el }) : null;
    }
    const ed = porPrefijo(prefijo);
    if (ed) return { ed, campo };
    const l = libreVivo();       // pantalla sin los campos del informe (addendum, planilla): el último cuadro que usaste
    return l ? (l.tipo === "ck" ? { ed: l.ed, campo: "libre" } : { el: l.el }) : null;
  }

  const ops = {
    seleccion: () => (Date.now() - ultimaSeleccion.t < 5 * 60 * 1000 ? ultimaSeleccion : { texto: "", campo: "" }),

    ping: () => { escanear(); return { ckeditor: !!window.CKEDITOR, instancias: Object.keys(editores()), editables: contarEditables() }; },

    preparar: ({ campos, nombresPropios }) => {
      camposCfg = campos || {};
      engancharFoco(campos);
      escanear();
      propios = new Set((nombresPropios || []).map((w) => w.toLowerCase()));
      return true;
    },

    activar: ({ campo, prefijo, desdeClic }) => {
      if (!desdeClic) { cursorManual = {}; rangoGuardado = {}; }   // cambiar de campo por voz/botón: escribe al final
      resaltar(campo === "libre" ? null : prefijo);
      resaltarLibre(campo === "libre");
      return true;
    },

    contexto: ({ campo, prefijo }) => {
      const d = destino(campo, prefijo);
      if (!d) return "";
      if (d.ed) return textoDe(d.ed).slice(-250);
      const v = d.el.isContentEditable ? d.el.innerText : d.el.value.slice(0, d.el.selectionStart == null ? undefined : d.el.selectionStart);
      return (v || "").slice(-250);
    },

    insertar: ({ campo, prefijo, texto, origen }) => {
      const d = destino(campo, prefijo);
      if (!d) return { error: campo === "libre" ? "El cuadro de texto ya no está en la página: haz clic donde quieres dictar." : "Haz clic en el cuadro de texto donde quieres dictar." };
      if (d.el) {
        const ahora0 = Date.now();
        if (ultimaInsercion.campo === "libre" && ultimaInsercion.texto === texto && texto.length > 25 && ahora0 - ultimaInsercion.t < 3000) return { repetida: true, antes: ultimaInsercion.origen, ahora: origen || "" };
        ultimaInsercion = { campo: "libre", texto, t: ahora0, origen: origen || "" };
        const dg = insertarNativo(d.el, texto);
        return dg && dg !== true ? { ok: true, diag: dg } : true;
      }
      const ed = d.ed; campo = d.campo;
      if (ed.readOnly) return { error: "el campo está bloqueado (solo lectura)" };
      // la misma frase al mismo campo dos veces en < 3 s: se escribe una sola vez
      const ahora = Date.now();
      if (ultimaInsercion.campo === campo && ultimaInsercion.texto === texto && texto.length > 25 && ahora - ultimaInsercion.t < 3000) {
        return { repetida: true, antes: ultimaInsercion.origen, ahora: origen || "" };
      }
      ultimaInsercion = { campo, texto, t: ahora, origen: origen || "" };
      const diag = insertar(ed, campo, texto);
      return diag ? { ok: true, diag } : true;
    },

    // Plantilla: llena varios campos. Si el campo está vacío lo llena; si tiene texto, agrega al final.
    // contenido[campo] puede ser texto, o {texto, html} (plantillas importadas del RIS, con su formato)
    plantilla: ({ contenido, campos }) => {
      for (const [clave, v] of Object.entries(contenido)) {
        if (!campos[clave]) continue;
        const ed = porPrefijo(campos[clave].prefijo);
        if (!ed || ed.readOnly) continue;
        const t = typeof v === "string" ? v : (v && v.texto) || "";
        const html = typeof v === "object" && v ? v.html : "";
        const vacio = textoDe(ed).trim() === "";
        if (clave === "titulo" && !vacio) continue;        // no duplicar el título que ya trae el RIS
        if (html) {
          ed.fire("saveSnapshot");
          alFinal(ed, clave);
          if (!vacio) salto(ed);
          ed.insertHtml(html);
          ed.fire("saveSnapshot"); ed.fire("change");
        } else if (t) {
          insertar(ed, clave, vacio ? t : "\n" + t);
        }
      }
      return true;
    },

    salto: ({ campo, prefijo, punto }) => {
      const d = destino(campo, prefijo);
      if (d && d.el) {
        const v = d.el.isContentEditable ? d.el.innerText : d.el.value.slice(0, d.el.selectionStart);
        insertarNativo(d.el, (punto && /[^\s.:;?!]\s*$/.test(v) ? "." : "") + (d.el.tagName === "INPUT" ? " " : "\n"));
        return true;
      }
      const ed = d && d.ed;
      if (d) campo = d.campo;
      if (!ed || ed.readOnly) return { error: "campo no disponible" };
      ed.fire("saveSnapshot");
      alFinal(ed, campo);
      if (punto && /[^\s.:;?!]\s*$/.test(antesDelCursor(ed))) ed.insertText(".");
      salto(ed);
      ed.fire("saveSnapshot"); ed.fire("change");
      return true;
    },

    deshacer: ({ campo, prefijo }) => {
      const d = destino(campo, prefijo);
      if (d && d.el) {
        if (d.el.isContentEditable) { d.el.focus(); d.el.ownerDocument.execCommand("undo"); return true; }
        const ult = pilaNativa.length && pilaNativa[pilaNativa.length - 1];
        if (ult && ult.el === d.el) {
          pilaNativa.pop();
          d.el.value = ult.valor; d.el.setSelectionRange(ult.a, ult.b);
          d.el.dispatchEvent(new Event("input", { bubbles: true }));
        }
        return true;
      }
      if (d && d.ed) d.ed.execCommand("undo");
      return true;
    },

    formato: ({ campo, prefijo, formato }) => {
      const d = destino(campo, prefijo);
      if (!d) return { error: "Haz clic en el campo donde quieres el formato." };
      return d.ed ? formatoCK(d.ed, formato) : formatoNativo(d.el, formato);
    },

    textos: ({ campos }) => {
      const out = {};
      for (const [clave, info] of Object.entries(campos)) {
        const ed = porPrefijo(info.prefijo);
        if (ed) out[clave] = textoDe(ed);
      }
      return out;
    },
  };

  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data || e.data[TAG] !== "req") return;
    const { id, op, args } = e.data;
    let resultado, error;
    try { resultado = ops[op] ? ops[op](args || {}) : undefined; if (!ops[op]) error = "op desconocida"; }
    catch (err) { error = String(err && err.message || err); }
    window.postMessage({ [TAG]: "res", id, resultado, error }, location.origin);
  });
})();

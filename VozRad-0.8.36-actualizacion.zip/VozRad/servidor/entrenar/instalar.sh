#!/usr/bin/env bash
# VozRad - instala el programa de entrenamiento (NVIDIA NeMo) dentro de Ubuntu (WSL).
# Uso, en la ventana de Ubuntu:   bash /mnt/c/VozRad/servidor/entrenar/instalar.sh
# Tarda 20-40 minutos (descarga ~6 GB). Pide tu contraseña de Linux una vez.
# Todo queda en tu PC: el programa en ~/vozrad-entrenar y los modelos en ~/.cache.
# No toca Windows ni VozRad. Se puede repetir sin problema.
set -uo pipefail

VOZRAD=/mnt/c/VozRad
ENT="$VOZRAD/entrenamiento"
ENV="$HOME/vozrad-entrenar"
mkdir -p "$ENT"
LOG="$ENT/instalacion.log"
exec > >(tee -a "$LOG") 2>&1
echo "================ VozRad - instalación del entrenamiento $(date '+%d-%m-%Y %H:%M') ================"

paso() { echo; echo "[VozRad] $*"; }
falla() { echo; echo "[VozRad] ERROR: $*"; echo "[VozRad] Envía el archivo C:\\VozRad\\entrenamiento\\instalacion.log a Álvaro/Claude."; exit 1; }

paso "1/6 Revisando la tarjeta gráfica..."
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader || falla "Ubuntu no ve la tarjeta (nvidia-smi)."

paso "2/6 Instalando herramientas de Ubuntu (pide tu contraseña de Linux)..."
sudo apt-get update -y && sudo apt-get install -y build-essential git curl ffmpeg libsndfile1 sox \
  || falla "no se pudieron instalar las herramientas de Ubuntu."

paso "3/6 Instalando uv (administrador de Python)..."
if ! command -v uv >/dev/null 2>&1 && [ ! -x "$HOME/.local/bin/uv" ]; then
  curl -LsSf https://astral.sh/uv/install.sh | sh || falla "no se pudo instalar uv."
fi
export PATH="$HOME/.local/bin:$PATH"
uv --version || falla "uv no quedó instalado."

paso "4/6 Creando el entorno de Python 3.12 en $ENV ..."
[ -x "$ENV/bin/python" ] || uv venv --python 3.12 "$ENV" || falla "no se pudo crear el entorno de Python."
PY="$ENV/bin/python"

paso "5/6 Instalando PyTorch (CUDA) y NVIDIA NeMo (~6 GB, 15-30 minutos)..."
# PyTorch de PyPI para Linux ya trae las librerías CUDA; NeMo elige la versión compatible
VIRTUAL_ENV="$ENV" uv pip install torch torchaudio "nemo_toolkit[asr]>=2.4" soundfile jiwer \
  || falla "no se pudo instalar PyTorch/NeMo."

paso "6/6 Probando: tarjeta, NeMo y el modelo Parakeet con uno de tus audios..."
"$PY" - <<'PYEOF' || falla "la prueba final no funcionó."
import json, time, pathlib, torch
print(f"PyTorch {torch.__version__} · CUDA disponible: {torch.cuda.is_available()}")
assert torch.cuda.is_available(), "PyTorch no ve la tarjeta"
print("Tarjeta:", torch.cuda.get_device_name(0), f"· bf16: {torch.cuda.is_bf16_supported()}")
import nemo, nemo.collections.asr as nemo_asr
print("NeMo", nemo.__version__)
t0 = time.time()
m = nemo_asr.models.ASRModel.from_pretrained("nvidia/parakeet-tdt-0.6b-v3")
m = m.cuda().eval()
print(f"Parakeet cargado en {time.time() - t0:.0f} s")
prueba = pathlib.Path("/mnt/c/VozRad/entrenamiento/datos/prueba.jsonl")
if prueba.exists():
    filas = [json.loads(l) for l in prueba.read_text(encoding="utf-8").splitlines()[:3]]
    salida = m.transcribe([f["audio_filepath"] for f in filas], batch_size=3)
    for f, s in zip(filas, salida):
        print("  oído antes :", f["crudo"])
        print("  NeMo ahora :", getattr(s, "text", s))
else:
    print("(no hay datos armados todavía: ejecuta armar_entrenamiento.bat en Windows)")
print("OK")
PYEOF

echo
echo "[VozRad] LISTO: el entorno de entrenamiento quedó instalado y funcionando."
echo "[VozRad] Envía C:\\VozRad\\entrenamiento\\instalacion.log a Álvaro/Claude."

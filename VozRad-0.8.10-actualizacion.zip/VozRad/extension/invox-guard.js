// VozRad - "modo VozRad": deja a Invox (Vocali) sin SpeechMike, sin micrófono y sin su agente local.
// Corre en el contexto de la página ANTES que los scripts del RIS (document_start).
// No borra ni modifica archivos de Invox: solo le muestra "ningún dispositivo", un micrófono en
// silencio, le impide hablar con su agente instalado en el PC y oculta su barra.
// VozRad sigue viendo los dispositivos reales porque corre en su propio contexto aislado.
// Se activa/desactiva desde el panel de VozRad (se aplica al recargar la página).
(() => {
  "use strict";
  let activo = true;
  try { activo = localStorage.getItem("vozrad_bloquear_invox") !== "0"; } catch (_) {}
  window.__vozradInvoxBloqueado = activo;
  if (!activo) return;

  const def = (obj, k, v) => { try { Object.defineProperty(obj, k, { value: v, configurable: true, writable: true }); } catch (_) {} };

  // 1) SpeechMike por WebHID: para la página no hay dispositivos
  const hid = navigator.hid;
  if (hid) {
    def(hid, "getDevices", async () => []);
    def(hid, "requestDevice", async () => []);
    def(hid, "addEventListener", () => {});
    def(hid, "onconnect", null);
    def(hid, "ondisconnect", null);
  }

  // 2) Micrófono: la página recibe una señal en silencio (no da error ni muestra alertas)
  const md = navigator.mediaDevices;
  if (md && md.getUserMedia) {
    let silencio = null;
    const flujoSilencioso = () => {
      if (!silencio) {
        const ctx = new AudioContext();
        const dest = ctx.createMediaStreamDestination();
        const g = ctx.createGain(); g.gain.value = 0;
        const o = ctx.createOscillator(); o.connect(g); g.connect(dest); o.start();
        silencio = dest.stream;
      }
      return silencio.clone();
    };
    def(md, "getUserMedia", async (c) => (c && c.audio ? flujoSilencioso() : Promise.reject(new DOMException("No disponible", "NotAllowedError"))));
  }
  for (const k of ["getUserMedia", "webkitGetUserMedia", "mozGetUserMedia"]) {
    if (navigator[k]) def(navigator, k, (_c, _ok, err) => err && err(new DOMException("No disponible", "NotAllowedError")));
  }

  // 3) Agente local de Invox (programa en el PC que maneja el SpeechMike): bloquear conexiones a este equipo
  const esLocal = (u) => {
    try {
      const h = new URL(String(u), location.href).hostname.replace(/^\[|\]$/g, "");
      return h === "localhost" || h === "127.0.0.1" || h === "::1" || h.endsWith(".localhost") || /^127\./.test(h);
    } catch (_) { return false; }
  };
  const avisar = (u) => { try { console.info("[VozRad] conexión de Invox al agente local bloqueada:", String(u).split("?")[0]); } catch (_) {} };

  const WS = window.WebSocket;
  if (WS) {
    const WSBloq = function (url, prot) {
      if (esLocal(url)) {
        avisar(url);
        // objeto inerte que nunca se conecta
        const falso = new EventTarget();
        Object.assign(falso, { readyState: 3, url: String(url), send() {}, close() {}, onopen: null, onclose: null, onerror: null, onmessage: null });
        setTimeout(() => { try { falso.dispatchEvent(new Event("error")); falso.onerror && falso.onerror(new Event("error")); } catch (_) {} }, 0);
        return falso;
      }
      return prot === undefined ? new WS(url) : new WS(url, prot);
    };
    WSBloq.prototype = WS.prototype;
    Object.assign(WSBloq, { CONNECTING: 0, OPEN: 1, CLOSING: 2, CLOSED: 3 });
    def(window, "WebSocket", WSBloq);
  }

  const f = window.fetch;
  if (f) def(window, "fetch", function (input, init) {
    const u = input && input.url ? input.url : input;
    if (esLocal(u)) { avisar(u); return Promise.reject(new TypeError("Failed to fetch")); }
    return f.apply(this, arguments);
  });

  const XO = XMLHttpRequest.prototype.open, XS = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__vozradLocal = esLocal(u); if (this.__vozradLocal) avisar(u); return XO.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function () {
    if (this.__vozradLocal) { setTimeout(() => this.dispatchEvent(new Event("error")), 0); return; }
    return XS.apply(this, arguments);
  };

  const ES = window.EventSource;
  if (ES) {
    const ESBloq = function (url, cfg) {
      if (esLocal(url)) { avisar(url); throw new DOMException("Bloqueado por VozRad", "SecurityError"); }
      return new ES(url, cfg);
    };
    ESBloq.prototype = ES.prototype;
    def(window, "EventSource", ESBloq);
  }

  // 4) Ocultar la barra y los botones de Invox (no los editores del informe)
  const css = `
    a.cke_button[title*="INVOX" i], .cke_button[title*="invox" i] { display: none !important; }
    [data-vozrad-oculto] { display: none !important; }
  `;
  const ocultar = (raiz) => {
    const els = raiz.querySelectorAll ? [raiz, ...raiz.querySelectorAll("*")] : [];
    for (const el of els) {
      if (!el.tagName) continue;
      const tag = el.tagName || "";
      // componentes propios de Invox (p.ej. <invox-bar>, <invoxmd-...>)
      if (/^INVOX/i.test(tag) || /(^|-)invox/i.test(tag)) { el.setAttribute("data-vozrad-oculto", ""); continue; }
      // botón "Microphone ...: SpeechMike" de la barra de Invox
      if (tag === "BUTTON" && /^\s*Microphone\b/i.test(el.textContent || "")) {
        const barra = el.closest("[class*='bar' i], [id*='bar' i]") || el;
        barra.setAttribute("data-vozrad-oculto", "");
      }
    }
  };
  const iniciarOcultar = () => {
    try {
      const st = document.createElement("style");
      st.textContent = css;
      (document.head || document.documentElement).appendChild(st);
      ocultar(document);
      new MutationObserver((ms) => { for (const m of ms) for (const n of m.addedNodes) if (n.nodeType === 1) ocultar(n); })
        .observe(document.documentElement, { childList: true, subtree: true });
      // la barra de Invox cambia su texto después de crearse: revisar unas veces más
      let veces = 0;
      const t = setInterval(() => { ocultar(document); if (++veces >= 15) clearInterval(t); }, 2000);
    } catch (_) {}
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciarOcultar); else iniciarOcultar();
})();

// VozRad - intermediario entre la página del RIS y el motor de voz.
// Por defecto el motor está en este mismo computador (127.0.0.1). En ⚙ se puede elegir un
// «motor en red» (otro computador con VozRad abierto con iniciar_en_red), con su clave.
const LOCAL = { url: "http://127.0.0.1:8765", clave: "" };

async function destino() {
  try {
    const { servidor } = await chrome.storage.local.get("servidor");
    if (servidor && servidor.url) return servidor;
  } catch (_) {}
  return LOCAL;
}

chrome.runtime.onMessage.addListener((msg, _sender, responder) => {
  if (msg.tipo === "abrir_opciones") { chrome.runtime.openOptionsPage(); return; }
  if (msg.tipo === "recargar_extension") { setTimeout(() => chrome.runtime.reload(), 1500); return; }
  if (msg.tipo !== "api") return;
  (async () => {
    const d = await destino();
    const remoto = d.url !== LOCAL.url;
    const headers = { "Content-Type": "application/json" };
    if (d.clave) headers["X-VozRad-Clave"] = d.clave;
    const opciones = msg.cuerpo ? { method: "POST", headers, body: JSON.stringify(msg.cuerpo) } : { method: "GET", headers };
    // que una red caída no deje el dictado colgado
    const ctl = new AbortController();
    const espera = setTimeout(() => ctl.abort(), msg.ruta === "/estado" ? 5000 : msg.ruta === "/actualizacion/aplicar" ? 180000 : 60000);
    try {
      const r = await fetch(d.url + msg.ruta, { ...opciones, signal: ctl.signal });
      if (r.status === 401) throw new Error("clave incorrecta del motor en red (revisa ⚙)");
      if (!r.ok) throw new Error("servidor respondió " + r.status);
      responder({ ok: true, datos: await r.json(), remoto });
    } catch (e) {
      const txt = e.name === "AbortError" ? "el motor no respondió a tiempo" : String(e.message || e);
      responder({ ok: false, error: remoto && /fetch|respondió a tiempo/i.test(txt) ? `el motor en red (${d.url}) no responde` : txt, remoto });
    } finally {
      clearTimeout(espera);
    }
  })();
  return true; // respuesta asíncrona
});

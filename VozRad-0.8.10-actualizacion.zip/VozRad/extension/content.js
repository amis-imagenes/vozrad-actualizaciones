// VozRad - lógica principal de la extensión (corre dentro de MultiRisWeb).
//  · Panel flotante de dictado
//  · Captura del micrófono y corte automático en frases (por silencios)
//  · Botones del SpeechMike por WebHID (librería abierta de Google/Philips)
//  · Envía cada frase al servidor local y escribe el resultado en el campo activo
(() => {
  "use strict";
  if (window.__vozradContent) return;
  window.__vozradContent = true;

  const TAG = "__vozrad";
  const ETIQUETAS = { titulo: "Título", tecnica: "Técnica", antecedentes: "Antecedentes", hallazgos: "Hallazgos", impresion: "Impresión" };

  const estado = {
    campos: {},          // desde config.json del servidor
    audioCfg: { silencio_fin_frase_ms: 700, duracion_max_frase_s: 25, sensibilidad: 2.5 },
    activo: "hallazgos",
    grabando: false,
    servidorOk: false,
    pendientes: 0,
    insertados: [],      // [{campo, texto}] para aprender de tus correcciones
    speechmike: null,
  };

  // ------------------------------------------------------------------ puente con la página
  let idSec = 0;
  const esperas = new Map();
  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data) return;
    if (e.data[TAG] === "res" && esperas.has(e.data.id)) {
      const { ok, ko } = esperas.get(e.data.id);
      esperas.delete(e.data.id);
      e.data.error ? ko(new Error(e.data.error)) : ok(e.data.resultado);
    } else if (e.data[TAG] === "evento" && e.data.tipo === "foco") {
      activarCampo(e.data.campo, true);
    }
  });
  function pagina(op, args) {
    return new Promise((ok, ko) => {
      const id = ++idSec;
      esperas.set(id, { ok, ko });
      window.postMessage({ [TAG]: "req", id, op, args }, location.origin);
      setTimeout(() => { if (esperas.delete(id)) ko(new Error("la página no respondió")); }, 4000);
    });
  }

  // ------------------------------------------------------------------ servidor local (vía background.js)
  function api(ruta, cuerpo) {
    return new Promise((ok, ko) => {
      chrome.runtime.sendMessage({ tipo: "api", ruta, cuerpo }, (r) => {
        if (chrome.runtime.lastError) return ko(new Error(chrome.runtime.lastError.message));
        r && r.ok ? ok(r.datos) : ko(new Error((r && r.error) || "sin respuesta"));
      });
    });
  }

  // ------------------------------------------------------------------ panel
  const host = document.createElement("div");
  host.id = "vozrad-panel";
  host.style.cssText = "position:fixed;right:20px;bottom:20px;z-index:2147483647;";
  const raiz = host.attachShadow({ mode: "open" });
  raiz.innerHTML = `
    <link rel="stylesheet" href="${chrome.runtime.getURL("panel.css")}">
    <div class="panel" part="panel">
      <header>
        <span class="marca">VozRad</span>
        <span class="servidor" title="Servidor de voz local"></span>
        <button class="mic-btn" title="Probar la calidad del micrófono">🎙</button>
        <button class="cfg-btn" title="Motor de voz: este computador o motor en red">⚙</button>
        <button class="ayuda-btn" title="Ayuda: botones y comandos de voz">?</button>
        <button class="min" title="Minimizar">–</button>
      </header>
      <div class="ayuda" hidden>
        <div class="ayuda-tabs">
          <button data-t="sm" class="sel">SpeechMike</button><button data-t="voz">Voz</button><button data-t="pl">Plantillas</button>
        </div>
        <div class="ayuda-cont"></div>
        <button class="ayuda-cerrar">Cerrar ayuda</button>
      </div>
      <div class="actualizar" hidden>
        <span class="act-txt"></span>
        <button class="act-ver">Novedades</button><button class="act-btn">Actualizar</button>
        <div class="act-notas" hidden></div>
      </div>
      <div class="actualizar ext-vieja" hidden></div>
      <div class="caja mic-caja" hidden></div>
      <div class="cuerpo">
        <button class="dictar"><span class="punto"></span><span class="lbl">Dictar</span></button>
        <div class="campos"></div>
        <div class="vivo" title="Lo que vas diciendo (borrador; el texto final aparece al hacer la pausa)"></div>
        <div class="ultimo" title="Última frase reconocida"></div>
        <div class="latencia" title="motor = reconocimiento en tu PC · total = desde que dejaste de hablar hasta que apareció el texto · ⚡ = reconocida por adelantado mientras hacías la pausa"></div>
        <div class="fila">
          <button class="deshacer" title="Deshacer la última frase">↶ Deshacer</button>
          <button class="sm">Conectar SpeechMike</button>
        </div>
        <div class="fila">
          <button class="entrenar-btn" title="Selecciona en el informe la palabra bien escrita y pulsa aquí">🎯 Entrenar palabra</button>
          <button class="frase-btn" title="Selecciona en el informe un texto y guárdalo con un nombre corto para dictarlo">➕ Frase tipo</button>
        </div>
        <div class="caja entrenar-caja" hidden></div>
        <div class="caja frase-caja" hidden>
          <div class="caja-tit">Nueva frase tipo</div>
          <div class="frase-texto"></div>
          <input class="frase-nombre" placeholder="Nombre para dictar (ej: hígado graso)">
          <div class="fila"><button class="frase-guardar">Guardar</button><button class="frase-cancelar">Cancelar</button></div>
        </div>
        <div class="calidad"><span class="precision" title="Palabras que no tuviste que corregir (según tus informes guardados)"></span><button class="sug-btn" hidden></button></div>
        <div class="sug-lista" hidden></div>
        <div class="aprendi" hidden></div>
        <div class="invox"><span class="invox-txt"></span><button class="invox-btn"></button></div>
        <div class="aviso"></div>
      </div>
    </div>`;
  const $ = (s) => raiz.querySelector(s);

  function pintar() {
    const p = $(".panel");
    p.classList.toggle("grabando", estado.grabando);
    $(".dictar .lbl").textContent = estado.grabando ? (estado.pendientes ? "Escuchando… (procesando)" : "Escuchando…") : "Dictar";
    const s = $(".servidor");
    s.classList.toggle("ok", estado.servidorOk);
    const eq = (estado.equipo || "red").replace(/^MacBook-Pro-de-/i, "Mac ").slice(0, 14);
    s.textContent = estado.servidorOk ? (estado.remoto ? `🌐 ${eq}` : "motor listo")
      : (estado.remoto ? "🌐 sin respuesta" : "motor apagado");
    s.title = estado.remoto ? `Motor de voz en otro computador (${estado.urlMotor}). Cámbialo en ⚙` : "Motor de voz en este computador";
    $(".sm").textContent = estado.speechmike ? `SpeechMike ✓` : "Conectar SpeechMike";
    $(".sm").classList.toggle("conectado", !!estado.speechmike);
    raiz.querySelectorAll(".campos button").forEach((b) => b.classList.toggle("activo", b.dataset.campo === estado.activo));
  }
  function aviso(t, ms = 5000) {
    const a = $(".aviso");
    a.textContent = t || "";
    if (t && ms) setTimeout(() => { if (a.textContent === t) a.textContent = ""; }, ms);
  }
  function mostrarUltimo(t, clase = "") {
    const u = $(".ultimo");
    u.textContent = t;
    u.className = "ultimo " + clase;
  }

  function construirBotonesCampos() {
    const c = $(".campos");
    c.innerHTML = "";
    for (const [clave, info] of Object.entries(estado.campos)) {
      if (clave === "titulo") continue;
      const b = document.createElement("button");
      b.dataset.campo = clave;
      b.innerHTML = `${ETIQUETAS[clave] || clave}${info.boton ? `<small>${info.boton}</small>` : ""}`;
      b.onclick = () => activarCampo(clave);
      c.appendChild(b);
    }
  }

  // arrastrar el panel
  (() => {
    let dx, dy, mov = false;
    $("header").addEventListener("mousedown", (e) => {
      if (e.target.closest("button")) return;
      mov = true; const r = host.getBoundingClientRect(); dx = e.clientX - r.left; dy = e.clientY - r.top; e.preventDefault();
    });
    window.addEventListener("mousemove", (e) => {
      if (!mov) return;
      host.style.left = Math.max(0, e.clientX - dx) + "px"; host.style.top = Math.max(0, e.clientY - dy) + "px";
      host.style.right = "auto"; host.style.bottom = "auto";
    });
    window.addEventListener("mouseup", () => {
      if (!mov) return; mov = false;
      chrome.storage.local.set({ posicion: { left: host.style.left, top: host.style.top } });
    });
  })();
  // Si el panel crece (prueba de micrófono, ayuda...), se sube para que ningún botón quede fuera de la pantalla.
  function ajustarPosicion() {
    const r = host.getBoundingClientRect();
    if (host.style.top && host.style.top !== "auto" && r.bottom > window.innerHeight - 4) {
      host.style.top = Math.max(0, window.innerHeight - r.height - 8) + "px";
    }
  }
  try { new ResizeObserver(ajustarPosicion).observe($(".panel")); } catch (_) {}
  window.addEventListener("resize", ajustarPosicion);

  // ---- Invox: bloqueado (modo VozRad) o activo. Se aplica al recargar la página.
  const invoxBloqueado = () => { try { return localStorage.getItem("vozrad_bloquear_invox") !== "0"; } catch (_) { return true; } };
  function pintarInvox() {
    const b = invoxBloqueado();
    $(".invox-txt").textContent = b ? "Invox desactivado en esta página" : "Invox activo (puede chocar con VozRad)";
    $(".invox-btn").textContent = b ? "Volver a Invox" : "Desactivar Invox";
    $(".invox").classList.toggle("alerta", !b);
  }
  $(".invox-btn").onclick = () => {
    const nuevo = invoxBloqueado() ? "0" : "1";
    if (!confirmarRecarga()) return;
    try { localStorage.setItem("vozrad_bloquear_invox", nuevo); } catch (_) {}
    location.reload();
  };
  function confirmarRecarga() {
    // Sin diálogos del navegador: se pide un segundo clic.
    const b = $(".invox-btn");
    if (b.dataset.confirmar) return true;
    b.dataset.confirmar = "1";
    b.textContent = "Clic otra vez (recarga; guarda antes)";
    setTimeout(() => { delete b.dataset.confirmar; pintarInvox(); }, 4000);
    return false;
  }

  $(".min").onclick = () => { $(".panel").classList.toggle("minimizado"); };

  // ------------------------------------------------------------------ ayuda
  let datosAyuda = null;
  const esc = (x) => String(x).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const fila = (a, b) => `<div class="ay-fila"><span class="ay-k">${a}</span><span>${b}</span></div>`;
  function ayudaSpeechMike() {
    const campos = (datosAyuda && datosAyuda.campos) || estado.campos || {};
    let h = `<div class="ay-tit">Botones del SpeechMike</div>`;
    h += fila("● Grabar", "Empezar / pausar el dictado");
    for (const [clave, info] of Object.entries(campos)) if (info.boton) h += fila(esc(info.boton), "Ir a " + esc(ETIQUETAS[clave] || clave));
    h += fila("EOL", "Siguiente campo");
    h += fila("INS/OVR", "Deshacer la última frase");
    h += fila("■ Stop", "Pausar el dictado");
    h += `<div class="ay-tit">En pantalla</div>`;
    h += fila("Clic en un campo", "Dictar en ese campo (y en el punto donde hiciste clic)");
    h += fila("Botones del panel", "Técnica / Antecedentes / Hallazgos / Impresión");
    h += fila("💡 sugerencias", "Correcciones que repites: ✓ aceptar · ✗ descartar");
    h += fila("Aprendí… Deshacer", "VozRad aprende solo tus correcciones; puedes deshacer");
    h += fila("🎯 Entrenar palabra", "Selecciona la palabra bien escrita en el informe, pulsa y dila 3 veces");
    h += fila("➕ Frase tipo", "Selecciona un texto del informe, pulsa y ponle un nombre corto");
    return h;
  }
  function ayudaVoz() {
    const d = datosAyuda || {};
    let h = `<div class="ay-tit">Puntuación (dila como palabra)</div>`;
    h += fila("coma · punto", ", ·  .");
    h += fila("punto aparte", "punto y nuevo párrafo");
    h += fila("nueva línea", "salto de línea");
    h += fila("dos puntos · punto y coma", ":  ·  ;");
    h += fila("abrir / cerrar paréntesis", "( … )");
    h += fila("guion", "-");
    h += `<div class="ay-tit">Moverse entre campos</div>`;
    h += fila("campo hallazgos", "o «ir a impresión», «técnica», «antecedentes», «título»");
    h += `<div class="ay-tit">Comandos</div>`;
    h += fila("plantilla &lt;nombre&gt;", "Inserta una plantilla completa (ver pestaña Plantillas)");
    h += fila("&lt;nombre de frase tipo&gt;", "Dicho solo (ej. «hígado graso») inserta la frase completa");
    h += fila("normal &lt;nombre&gt; · frase &lt;nombre&gt;", "Lo mismo, con prefijo");
    h += fila(esc((d.deshacer || ["borrar eso"])[0]), "Borra la última frase dictada");
    h += fila(esc((d.detener || ["detener dictado"])[0]), "Pausa el dictado");
    h += `<div class="ay-tit">Formato automático</div>`;
    h += fila("3 por 2 centímetros", "3 x 2 cm");
    h += fila("mide seis por siete", "mide 6 x 7 (tras «mide», «diámetro de», «hasta»… siempre cifras)");
    h += fila("dos coma cinco milímetros", "2,5 mm");
    h += fila("segmento cuatro a · grado dos", "segmento IVa · grado II");
    h += fila("romano siete · siete romano", "VII");
    h += fila("L cuatro L cinco", "L4-L5");
    h += fila("noventa milímetros cúbicos", "90 mm³");
    h += `<div class="ay-tit">Aprende de tus informes</div>`;
    h += fila("Contexto", "Si el motor escribe algo raro (conducto «Wilson»), se usa lo que dicen tus informes en ese contexto (Wirsung)");
    h += `<div class="ay-tit">Calidad y velocidad</div>`;
    h += fila("🎙 (arriba)", "Prueba de micrófono: volumen, ruido, saturación, zumbido y cuánto entiende el motor, con consejos");
    h += fila("⚡ en la latencia", "La frase se reconoció por adelantado mientras hacías la pausa: el texto aparece antes");
    h += fila("total", "Tiempo desde que dejas de hablar hasta que aparece el texto (verde: menos de 1,2 s)");
    return h;
  }
  function ayudaPlantillas(filtro = "") {
    const d = datosAyuda || {};
    const f = filtro.trim().toLowerCase();
    const pl = (d.plantillas || []).filter((n) => !f || n.includes(f));
    const fr = (d.frases || []).filter((n) => !f || n.includes(f));
    let h = `<input class="ay-buscar" placeholder="Buscar plantilla o frase…" value="${esc(filtro)}">`;
    h += `<div class="ay-tit">Plantillas (${pl.length}) — di «plantilla» + nombre</div>`;
    h += pl.length ? pl.map((n) => `<div class="ay-item">plantilla ${esc(n)}</div>`).join("") : `<div class="ay-vacio">Sin plantillas. Impórtalas desde PLANTILLAS del RIS o con generar_perfil</div>`;
    h += `<div class="ay-tit">Frases tipo (${fr.length}) — di el nombre solo</div>`;
    h += fr.length ? fr.map((n) => `<div class="ay-item ay-frase"><span>${n.trim().includes(" ") ? esc(n) : "normal " + esc(n)}</span><button data-borrar="${esc(n)}" title="Borrar esta frase tipo">✗</button></div>`).join("") : `<div class="ay-vacio">Sin frases. Selecciona un texto en el informe y usa ➕ Frase tipo.</div>`;
    return h;
  }
  function pintarAyuda(tab, filtro = "") {
    raiz.querySelectorAll(".ayuda-tabs button").forEach((b) => b.classList.toggle("sel", b.dataset.t === tab));
    const c = $(".ayuda-cont");
    c.innerHTML = tab === "sm" ? ayudaSpeechMike() : tab === "voz" ? ayudaVoz() : ayudaPlantillas(filtro);
    c.querySelectorAll("[data-borrar]").forEach((b) => {
      b.onclick = async () => {
        if (!b.dataset.ok) { b.dataset.ok = "1"; b.textContent = "¿borrar?"; setTimeout(() => { delete b.dataset.ok; b.textContent = "✗"; }, 3000); return; }
        await api("/frases/borrar", { nombre: b.dataset.borrar }).catch(() => {});
        datosAyuda = await api("/ayuda").catch(() => datosAyuda);
        pintarAyuda("pl", (c.querySelector(".ay-buscar") || {}).value || "");
      };
    });
    const inp = c.querySelector(".ay-buscar");
    if (inp) {
      inp.oninput = () => { const pos = inp.selectionStart; pintarAyuda("pl", inp.value); const n = $(".ay-buscar"); n.focus(); n.setSelectionRange(pos, pos); };
    }
  }
  $(".ayuda-btn").onclick = async () => {
    const a = $(".ayuda");
    if (!a.hidden) { a.hidden = true; return; }
    try { datosAyuda = await api("/ayuda"); } catch (_) {}
    a.hidden = false;
    pintarAyuda("sm");
  };
  $(".ayuda-cerrar").onclick = () => { $(".ayuda").hidden = true; };
  raiz.querySelectorAll(".ayuda-tabs button").forEach((b) => { b.onclick = () => pintarAyuda(b.dataset.t); });
  $(".dictar").onclick = () => alternarGrabacion();
  $(".deshacer").onclick = () => deshacer();
  // Siempre hace algo: si no hay ninguno autorizado abre el selector; si ya estaba, reconecta desde cero.
  $(".sm").onclick = () => conectarSpeechMike(true, true);

  // ------------------------------------------------------------------ campos
  let cambiosManuales = 0;
  async function activarCampo(clave, desdeClic = false, porVoz = false) {
    if (!estado.campos[clave]) return;
    if (!porVoz) cambiosManuales++;
    estado.activo = clave;
    pintar();
    await pagina("activar", { campo: clave, prefijo: estado.campos[clave].prefijo, desdeClic }).catch(() => {});
    actualizarLeds();
  }
  function siguienteCampo(delta = 1) {
    const orden = Object.keys(estado.campos).filter((c) => c !== "titulo");
    const i = orden.indexOf(estado.activo);
    activarCampo(orden[(i + delta + orden.length) % orden.length]);
  }
  async function deshacer() {
    await pagina("deshacer", { prefijo: estado.campos[estado.activo].prefijo }).catch(() => {});
    mostrarUltimo("↶ deshecho", "suave");
  }

  // ------------------------------------------------------------------ audio y corte en frases
  let flujo = null, ctx = null, proc = null;
  const VAD = { ruido: 0.003, enVoz: false, silencioMs: 0, vozMs: 0, buffer: [], previo: [], finVoz: 0 };
  // Reconocimiento adelantado: apenas callas ~0,25 s se empieza a reconocer la frase; si al cumplirse la
  // pausa completa no volviste a hablar, el texto ya está listo (si retomas, se descarta y no pasa nada).
  let SPEC = { frase: -1, valido: false, enVuelo: false };
  const FRAME = 1024; // ~64 ms a 16 kHz

  async function elegirMicrofono() {
    const { microfono } = await chrome.storage.local.get("microfono");
    const disp = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === "audioinput");
    const sm = disp.find((d) => d.deviceId === microfono) || disp.find((d) => /speechmike|philips/i.test(d.label));
    return sm ? { deviceId: { exact: sm.deviceId } } : {};
  }

  async function iniciarAudio() {
    const base = { channelCount: 1, echoCancellation: false, noiseSuppression: false, autoGainControl: false };
    let pref = {};
    try { pref = await elegirMicrofono(); } catch (_) {}
    flujo = await navigator.mediaDevices.getUserMedia({ audio: { ...base, ...pref } });
    if (!pref.deviceId) {  // tras el primer permiso ya se ven los nombres: reintenta con el SpeechMike
      const p2 = await elegirMicrofono();
      if (p2.deviceId) { flujo.getTracks().forEach((t) => t.stop()); flujo = await navigator.mediaDevices.getUserMedia({ audio: { ...base, ...p2 } }); }
    }
    const pista = flujo.getAudioTracks()[0];
    aviso("Micrófono: " + (pista && pista.label || "predeterminado"), 4000);
    ctx = new AudioContext({ sampleRate: 16000 });
    const fuente = ctx.createMediaStreamSource(flujo);
    proc = ctx.createScriptProcessor(FRAME, 1, 1);
    proc.onaudioprocess = (e) => procesarFrame(e.inputBuffer.getChannelData(0));
    fuente.connect(proc);
    proc.connect(ctx.destination);
  }

  function detenerAudio() {
    try { proc && proc.disconnect(); } catch (_) {}
    try { ctx && ctx.close(); } catch (_) {}
    if (flujo) flujo.getTracks().forEach((t) => t.stop());
    flujo = ctx = proc = null;
    setTimeout(vigilarSpeechMike, 800);
  }

  function procesarFrame(f32) {
    const copia = new Float32Array(f32);
    let s = 0; for (let i = 0; i < copia.length; i++) s += copia[i] * copia[i];
    const rms = Math.sqrt(s / copia.length);
    const ms = (copia.length / 16000) * 1000;
    const cfg = estado.audioCfg;
    const umbral = Math.max(VAD.ruido * (cfg.sensibilidad || 2.5), 0.006);
    const hayVoz = rms > umbral;

    if (!VAD.enVoz) {
      // estima el ruido de fondo solo cuando no se habla
      VAD.ruido = hayVoz ? VAD.ruido * 1.001 : VAD.ruido * 0.95 + rms * 0.05;
      VAD.previo.push(copia); if (VAD.previo.length > 5) VAD.previo.shift();   // ~300 ms antes de la voz
      if (hayVoz) { VAD.enVoz = true; VAD.buffer = [...VAD.previo]; VAD.previo = []; VAD.silencioMs = 0; VAD.vozMs = 0; }
      return;
    }
    VAD.buffer.push(copia);
    if (hayVoz) {
      VAD.silencioMs = 0; VAD.vozMs += ms;
      if (SPEC.frase === VIVO.frase) SPEC.valido = false;          // retomaste la frase: lo adelantado no sirve
    } else {
      if (VAD.silencioMs === 0) VAD.finVoz = performance.now() - ms;
      VAD.silencioMs += ms;
    }
    const largoS = (VAD.buffer.length * ms) / 1000;
    if (VAD.silencioMs >= (cfg.silencio_fin_frase_ms || 700) || largoS >= (cfg.duracion_max_frase_s || 25)) cerrarFrase();
    else if (VAD.silencioMs >= (cfg.adelantar_ms || 250) && cfg.adelantar !== false) adelantar();
    else quizasParcial();
  }

  function adelantar() {
    if ((SPEC.frase === VIVO.frase && SPEC.valido) || SPEC.enVuelo) return;
    if (estado.pendientes > 0 || ENTRENO.restantes > 0 || VAD.vozMs < 200) return;
    const campo = estado.activo;
    const pcm = aPCM(VAD.buffer);
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
    const s = { frase: VIVO.frase, valido: true, enVuelo: true, id, campo, marca: cambiosManuales, pcm };
    s.promesa = pagina("contexto", { prefijo: estado.campos[campo].prefijo }).catch(() => "")
      .then((contexto) => api("/transcribir", { audio: aBase64(pcm), contexto, campo, provisional: true, id }));
    s.promesa.catch(() => {}).finally(() => { s.enVuelo = false; });
    SPEC = s;
  }

  function aPCM(trozos) {
    let n = 0; trozos.forEach((t) => (n += t.length));
    const pcm = new Int16Array(n); let o = 0;
    for (const t of trozos) for (let i = 0; i < t.length; i++) { const v = Math.max(-1, Math.min(1, t[i])); pcm[o++] = v < 0 ? v * 0x8000 : v * 0x7fff; }
    return pcm;
  }

  // ---- texto en vivo: cada ~1 s manda lo que llevas de la frase (si el motor está libre)
  const VIVO = { activo: true, enVuelo: false, ultimo: 0, frase: 0, lentos: 0 };
  function quizasParcial() {
    if (!VIVO.activo || VIVO.enVuelo || estado.pendientes > 0 || VAD.silencioMs > 0) return;
    const ahora = performance.now();
    if (ahora - VIVO.ultimo < 1000 || VAD.vozMs < 700) return;
    VIVO.ultimo = ahora; VIVO.enVuelo = true;
    const frase = VIVO.frase;
    const trozos = VAD.buffer.slice(-160);            // últimos ~10 s
    api("/parcial", { audio: aBase64(aPCM(trozos)) })
      .then((r) => {
        if (r.tipo !== "parcial" || frase !== VIVO.frase) return;
        $(".vivo").textContent = r.texto ? r.texto + " …" : "";
        // si tu tarjeta no da abasto, se apaga solo para no frenar el dictado
        VIVO.lentos = r.ms > 1200 ? VIVO.lentos + 1 : 0;
        if (VIVO.lentos >= 3) { VIVO.activo = false; aviso("Texto en vivo desactivado: el motor es lento en este equipo.", 6000); }
      })
      .catch(() => {})
      .finally(() => { VIVO.enVuelo = false; });
  }

  function cerrarFrase() {
    const spec = SPEC.frase === VIVO.frase && SPEC.valido && SPEC.campo === estado.activo && SPEC.marca === cambiosManuales ? SPEC : null;
    const finVoz = VAD.silencioMs > 0 && VAD.finVoz ? VAD.finVoz : performance.now();
    VIVO.frase++; $(".vivo").textContent = "";
    const trozos = VAD.buffer, voz = VAD.vozMs;
    VAD.buffer = []; VAD.enVoz = false; VAD.silencioMs = 0; VAD.vozMs = 0;
    if (voz < 200 || !trozos.length) return;      // ruido, golpe o tos corta
    encolar(spec ? spec.pcm : aPCM(trozos), finVoz, spec);
  }

  // Las frases se procesan en orden, una tras otra.
  let cola = Promise.resolve();
  function encolar(pcm, t0, spec = null) {
    estado.pendientes++; pintar();
    const campo = estado.activo, marca = cambiosManuales;
    cola = cola.then(() => transcribir(pcm, campo, marca, t0, spec)).catch((e) => aviso("Error: " + e.message, 8000))
      .finally(() => { estado.pendientes--; pintar(); });
  }

  function aBase64(int16) {
    const bytes = new Uint8Array(int16.buffer);
    let bin = ""; const paso = 0x8000;
    for (let i = 0; i < bytes.length; i += paso) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + paso));
    return btoa(bin);
  }

  function mostrarLatencia(r, t0, pcm) {
    const total = performance.now() - t0;   // desde que dejaste de hablar hasta ahora
    const seg = (ms) => (ms / 1000).toFixed(1).replace(".", ",") + " s";
    const el = $(".latencia");
    el.textContent = `${r.adelantada ? "⚡ " : ""}motor ${seg(r.ms || 0)} · total ${seg(total)} · frase de ${seg(pcm.length / 16)}`;
    el.title = `motor ${r.ms || 0} ms · texto ${r.ms_texto || 0} ms · total ${Math.round(total)} ms (pausa de fin de frase: ${estado.audioCfg.silencio_fin_frase_ms || 700} ms)` + (r.adelantada ? " · reconocida por adelantado" : "");
    el.className = "latencia " + (total < 1200 ? "ok" : total < 2500 ? "medio" : "lento");
  }

  // ------------------------------------------------------------------ entrenar palabra
  const ENTRENO = { palabra: "", restantes: 0, iniciadoPorMi: false, resultados: [] };
  function pintarEntreno(msg) {
    const c = $(".entrenar-caja");
    c.hidden = false;
    c.innerHTML = "";
    const t = document.createElement("div"); t.className = "caja-tit"; t.textContent = `Entrenar «${ENTRENO.palabra}»`;
    const m = document.createElement("div"); m.className = "caja-msg"; m.textContent = msg;
    const b = document.createElement("button"); b.textContent = ENTRENO.restantes > 0 ? "Cancelar" : "Cerrar";
    b.onclick = () => terminarEntreno(true);
    c.append(t, m, b);
  }
  async function empezarEntreno() {
    const sel = await pagina("seleccion").catch(() => null);
    const palabra = sel && sel.texto ? sel.texto.trim() : "";
    if (!palabra || palabra.split(/\s+/).length > 4) {
      aviso("Primero selecciona con el mouse (en el informe) la palabra bien escrita, de 1 a 4 palabras.", 7000);
      return;
    }
    $(".frase-caja").hidden = true;
    Object.assign(ENTRENO, { palabra, restantes: 3, resultados: [], iniciadoPorMi: !estado.grabando });
    pintarEntreno("Di la palabra ahora (1 de 3). Haz una pausa después de cada vez.");
    if (!estado.grabando) await iniciarGrabacion();
  }
  function terminarEntreno(cerrar) {
    const yoInicie = ENTRENO.iniciadoPorMi && ENTRENO.restantes >= 0;
    ENTRENO.restantes = 0;
    if (yoInicie && estado.grabando) detenerGrabacion();
    ENTRENO.iniciadoPorMi = false;
    if (cerrar) $(".entrenar-caja").hidden = true;
  }
  async function entrenarCon(pcm) {
    const n = 4 - ENTRENO.restantes;
    pintarEntreno(`Procesando ${n} de 3…`);
    try {
      const r = await api("/entrenar", { palabra: ENTRENO.palabra, audio: aBase64(pcm) });
      ENTRENO.resultados.push(r);
    } catch (e) { aviso("Error al entrenar: " + e.message, 6000); }
    ENTRENO.restantes--;
    if (ENTRENO.restantes > 0) { pintarEntreno(`Bien. Dila de nuevo (${n + 1} de 3).`); return; }
    // resumen
    const aprendidas = [...new Set(ENTRENO.resultados.flatMap((r) => (r.aprendido || []).map((x) => x.de)))];
    const comunes = [...new Set(ENTRENO.resultados.flatMap((r) => r.comunes || []))];
    const correctas = ENTRENO.resultados.filter((r) => r.correcto).length;
    let msg = aprendidas.length
      ? `Listo. Cuando el motor escuche ${aprendidas.map((x) => `«${x}»`).join(", ")} escribirá «${ENTRENO.palabra}».`
      : correctas ? `El motor ya la reconoce bien (${correctas} de 3). Quedó en tu vocabulario.` : "No pude escuchar la palabra. Intenta de nuevo más cerca del micrófono.";
    if (comunes.length) msg += ` (No reemplazo ${comunes.map((x) => `«${x}»`).join(", ")} porque es una palabra que usas.)`;
    const avisos = [...new Set(ENTRENO.resultados.map((r) => r.aviso).filter(Boolean))];
    if (avisos.length) msg = "⚠️ " + avisos[0];
    terminarEntreno(false);
    pintarEntreno(msg);
    mostrarUltimo("Entrenada: " + ENTRENO.palabra, "suave");
  }
  $(".entrenar-btn").onclick = () => (ENTRENO.restantes > 0 ? terminarEntreno(true) : empezarEntreno());

  // ------------------------------------------------------------------ frases tipo
  let fraseSel = "";
  $(".frase-btn").onclick = async () => {
    const sel = await pagina("seleccion").catch(() => null);
    fraseSel = sel && sel.texto ? sel.texto.trim() : "";
    if (!fraseSel) { aviso("Primero selecciona con el mouse (en el informe) el texto que quieres guardar.", 7000); return; }
    $(".entrenar-caja").hidden = true;
    $(".frase-texto").textContent = fraseSel.length > 160 ? fraseSel.slice(0, 160) + "…" : fraseSel;
    $(".frase-nombre").value = "";
    $(".frase-caja").hidden = false;
    $(".frase-nombre").focus();
  };
  $(".frase-cancelar").onclick = () => { $(".frase-caja").hidden = true; };
  async function guardarFrase() {
    const nombre = $(".frase-nombre").value.trim();
    if (!nombre) { $(".frase-nombre").focus(); return; }
    if (!nombre.trim().includes(" ")) aviso("Con un nombre de una sola palabra tendrás que decir «normal " + nombre + "». Con 2 o más palabras basta el nombre.", 9000);
    try {
      const r = await api("/frases/agregar", { nombre, texto: fraseSel });
      $(".frase-caja").hidden = true;
      aviso(`${r.reemplazo ? "Actualizada" : "Guardada"}: di «${r.nombre}» para insertarla.`, 8000);
    } catch (e) { aviso("Error al guardar: " + e.message, 6000); }
  }
  $(".frase-guardar").onclick = guardarFrase;
  $(".frase-nombre").addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter") guardarFrase(); if (e.key === "Escape") $(".frase-caja").hidden = true; });

  async function transcribir(pcm, campoAlGrabar, marca, t0, spec = null) {
    if (ENTRENO.restantes > 0) return entrenarCon(pcm);
    // Si cambiaste de campo con botón/clic después de decir la frase, va al campo donde la dijiste.
    // Si el cambio fue por voz ("campo hallazgos"), ya se aplicó en orden y vale el campo actual.
    const campo = marca !== cambiosManuales ? campoAlGrabar : estado.activo;
    let r = null;
    if (spec && spec.campo === campo) {
      try { r = await spec.promesa; } catch (_) { r = null; }
      if (r) { r.adelantada = true; api("/confirmar", { id: spec.id }).catch(() => {}); }
    }
    if (!r) {
      const contexto = await pagina("contexto", { prefijo: estado.campos[campo].prefijo }).catch(() => "");
      r = await api("/transcribir", { audio: aBase64(pcm), contexto, campo });
    }
    mostrarLatencia(r, t0, pcm);
    if (r.tipo === "vacio") return;
    if (r.tipo === "comando") return ejecutarComando(r);
    if (!r.texto) return;
    const norm = (x) => x.toLowerCase().replace(/[^a-záéíóúñü0-9]+/g, " ").trim();
    const previa = estado.insertados[estado.insertados.length - 1];
    const origen = `frase ${spec ? "⚡" + spec.id : "normal"} · ${(pcm.length / 16000).toFixed(1)} s · cola ${estado.pendientes}`;
    if (previa && previa.campo === campo && norm(previa.texto) === norm(r.texto) && norm(r.texto).split(" ").length >= 6 &&
        Date.now() - (previa.t || 0) < 15000) {
      aviso("Ignoré una frase idéntica a la anterior (si de verdad querías repetirla, díctala de nuevo).", 8000);
      api("/diagnostico", { tipo: "frase repetida (panel)", antes: previa.origen, ahora: origen, segundos: (Date.now() - previa.t) / 1000, texto: r.texto.slice(0, 80) }).catch(() => {});
      previa.t = 0;                                     // una segunda repetición sí se escribe
      return;
    }
    const res = await pagina("insertar", { campo, prefijo: estado.campos[campo].prefijo, texto: r.texto, origen });
    if (res && res.error) { aviso(res.error, 6000); return; }
    if (res && res.diag) api("/diagnostico", { tipo: "insercion", ...res.diag, texto: r.texto.slice(0, 60) }).catch(() => {});
    if (res && res.repetida) {
      api("/diagnostico", { tipo: "frase repetida (editor)", antes: res.antes, ahora: res.ahora, texto: r.texto.slice(0, 80) }).catch(() => {});
      return;
    }
    estado.insertados.push({ campo, texto: r.texto, crudo: r.crudo, t: Date.now(), origen });
    mostrarUltimo(r.texto.replace(/\n/g, " ⏎ "));
  }

  async function ejecutarComando(c) {
    switch (c.accion) {
      case "campo": await activarCampo(c.campo, false, true); mostrarUltimo("→ " + (ETIQUETAS[c.campo] || c.campo), "suave"); break;
      case "deshacer": await deshacer(); break;
      case "salto":
        await pagina("salto", { campo: estado.activo, prefijo: estado.campos[estado.activo].prefijo, punto: !!c.punto });
        mostrarUltimo(c.punto ? "punto aparte ⏎" : "nueva línea ⏎", "suave"); break;
      case "detener": detenerGrabacion(); break;
      case "plantilla":
        await pagina("plantilla", { contenido: c.contenido, campos: estado.campos });
        mostrarUltimo("Plantilla: " + c.nombre, "suave"); break;
      case "frase": {
        await pagina("insertar", { campo: estado.activo, prefijo: estado.campos[estado.activo].prefijo, texto: c.texto });
        mostrarUltimo("Frase: " + c.nombre, "suave"); break;
      }
      case "aviso": aviso(c.mensaje); break;
    }
  }

  let iniciando = false;
  async function iniciarGrabacion() {
    if (estado.grabando || iniciando) return;          // dos pulsaciones seguidas no abren dos micrófonos
    iniciando = true;
    try { await iniciarGrabacionReal(); } finally { iniciando = false; }
  }
  async function iniciarGrabacionReal() {
    if (!estado.servidorOk) { await revisarServidor(); if (!estado.servidorOk) { aviso("El motor de voz no está encendido. Abre «iniciar» de VozRad (iniciar.bat en Windows, iniciar.command en Mac), o revisa ⚙ si usas un motor en red", 8000); return; } }
    try { await iniciarAudio(); } catch (e) { aviso("No pude abrir el micrófono: " + e.message, 8000); return; }
    estado.grabando = true; pintar(); actualizarLeds();
  }
  function detenerGrabacion() {
    if (!estado.grabando || iniciando) return;
    if (VAD.enVoz) cerrarFrase();   // envía lo que quedaba
    detenerAudio();
    estado.grabando = false; pintar(); actualizarLeds();
  }
  function alternarGrabacion() { estado.grabando ? detenerGrabacion() : iniciarGrabacion(); }

  // ------------------------------------------------------------------ SpeechMike (WebHID)
  const DS = window.DictationSupport;
  let gestor = null, mascaraPrevia = 0;
  const NOMBRE_BOTON = DS ? {
    RECORD: DS.ButtonEvent.RECORD, STOP: DS.ButtonEvent.STOP, PLAY: DS.ButtonEvent.PLAY,
    F1: DS.ButtonEvent.F1_A, F2: DS.ButtonEvent.F2_B, F3: DS.ButtonEvent.F3_C, F4: DS.ButtonEvent.F4_D,
    EOL: DS.ButtonEvent.EOL_PRIO, INS_OVR: DS.ButtonEvent.INS_OVR, INSTR: DS.ButtonEvent.INSTR,
    REWIND: DS.ButtonEvent.REWIND, FORWARD: DS.ButtonEvent.FORWARD, COMMAND: DS.ButtonEvent.COMMAND,
  } : {};

  function alPresionar(nombre) {
    // F1..F4 -> el campo que tenga asignado ese botón en config.json
    const campo = Object.keys(estado.campos).find((k) => estado.campos[k].boton === nombre);
    if (campo) return activarCampo(campo);
    switch (nombre) {
      case "RECORD": return alternarGrabacion();
      case "STOP": return detenerGrabacion();
      case "PLAY": return alternarGrabacion();
      case "EOL": return siguienteCampo(1);
      case "INS_OVR": return deshacer();
    }
  }

  async function alBoton(_disp, mascara) {
    const nuevos = mascara & ~mascaraPrevia;          // solo los que se acaban de presionar
    mascaraPrevia = mascara;
    ultimoEventoHID = Date.now();
    if (MIC.activo) {
      // durante la prueba de micrófono el SpeechMike solo sirve para terminar la lectura (no inicia el dictado)
      if (nuevos & (NOMBRE_BOTON.RECORD | NOMBRE_BOTON.STOP | NOMBRE_BOTON.PLAY | NOMBRE_BOTON.EOL) && MIC.boton) MIC.boton();
      return;
    }
    for (const [nombre, bit] of Object.entries(NOMBRE_BOTON)) if (nuevos & bit) alPresionar(nombre);
  }

  async function actualizarLeds() {
    const d = estado.speechmike;
    if (!d || !DS || typeof d.setSimpleLedState !== "function") return;
    try {
      const encendido = estado.grabando || MIC.fase === "voz";
      await d.setSimpleLedState(encendido ? DS.SimpleLedState.RECORD_INSERT : DS.SimpleLedState.RECORD_STANDBY_INSERT);
    } catch (_) {}
  }

  async function revisarModo(d) {
    if (!DS || typeof d.getEventMode !== "function") return;
    try {
      const modo = await d.getEventMode();
      if (modo !== DS.EventMode.HID) {
        await d.setEventMode(DS.EventMode.HID);
        aviso("SpeechMike cambiado a modo HID (necesario para usarlo sin foco en esta ventana).", 7000);
      }
    } catch (_) {}
  }

  let ultimoEventoHID = 0, conectando = false;
  // los mismos que usa la librería de Philips (interfaz HID de botones, gamepad, pedal, PowerMic)
  const FILTROS_HID = [
    [2321, 3100, 65440, 1], [2321, 3101, 65440, 1], [2321, 3102, 65440, 1], [2321, 4000, 65440, 1], [1364, 100, 65440, 1],
    [2321, 4000, 1, 4], [2321, 3102, 1, 4], [1364, 100, 1, 4], [2321, 6212, 1, 4], [2321, 2330, 1, 4], [1364, 4097, 1, 0],
  ].map(([vendorId, productId, usagePage, usage]) => ({ vendorId, productId, usagePage, usage }));

  async function cerrarGestor() {
    if (!gestor) return;
    const g = gestor; gestor = null;
    // se cierra cada dispositivo esperando a que termine (si no, el nuevo gestor lo encuentra "abierto"
    // y luego se cierra solo: el SpeechMike queda mudo)
    for (const d of (() => { try { return g.getDevices(); } catch (_) { return []; } })()) {
      try { await d.shutdown(); } catch (_) {}
      try { if (d.hidDevice && d.hidDevice.opened) await d.hidDevice.close(); } catch (_) {}
    }
    try { await g.shutdown(); } catch (_) {}
  }

  // pedirPermiso: abre el selector de Edge si no hay ninguno autorizado · forzar: reconecta desde cero
  async function conectarSpeechMike(pedirPermiso, forzar = false) {
    if (!DS || !navigator.hid) { aviso("Este navegador no soporta WebHID. Usa Chrome o Edge."); return; }
    if (conectando) return;
    conectando = true;
    try {
      // el selector debe abrirse de inmediato tras el clic (Edge lo exige), antes de cualquier espera larga
      let elegidos = [];
      if (pedirPermiso && !(await navigator.hid.getDevices()).length) {
        elegidos = await navigator.hid.requestDevice({ filters: FILTROS_HID });
        if (!elegidos.length) { aviso("No se seleccionó ningún dispositivo."); return; }
      }
      if (forzar || elegidos.length) await cerrarGestor();
      if (!gestor) {
        const g = new DS.DictationDeviceManager();
        // los oyentes se registran ANTES de init(): init() ya abre el SpeechMike autorizado y la librería
        // solo le pasa los oyentes existentes en ese momento (si no, el SpeechMike queda "✓" pero mudo)
        g.addButtonEventListener(alBoton);
        g.addDeviceConnectedEventListener(async (d) => { estado.speechmike = d; mascaraPrevia = 0; await revisarModo(d); pintar(); actualizarLeds(); });
        g.addDeviceDisconnectedEventListener(() => { estado.speechmike = (gestor && gestor.getDevices()[0]) || null; pintar(); });
        await g.init();
        gestor = g;
      }
      mascaraPrevia = 0;
      estado.speechmike = gestor.getDevices()[0] || null;
      if (estado.speechmike) {
        await revisarModo(estado.speechmike);
        actualizarLeds();
        if (pedirPermiso) aviso("SpeechMike conectado ✓ (prueba un botón)", 4000);
      } else if (pedirPermiso) aviso("No encuentro el SpeechMike: revisa el cable USB y pulsa de nuevo.", 7000);
    } catch (e) { aviso("SpeechMike: " + e.message, 8000); }
    finally { conectando = false; pintar(); }
  }

  // Revisión periódica: si el SpeechMike quedó cerrado o desapareció, se reconecta solo.
  async function vigilarSpeechMike() {
    if (!DS || !navigator.hid || conectando) return;
    try {
      const d = estado.speechmike;
      const hid = d && d.hidDevice;
      if (hid && hid.opened) return;
      if (d || (await navigator.hid.getDevices()).length) await conectarSpeechMike(false, true);
    } catch (_) {}
  }

  // ------------------------------------------------------------------ aprender de tus correcciones
  // Al Guardar / Informar / Validar se guarda (en tu PC) lo dictado y cómo quedó finalmente.
  document.addEventListener("click", async (e) => {
    const b = e.target.closest && e.target.closest("#btnPendiente, #btnGuardar, #btnInformar");
    if (!b || !estado.insertados.length) return;
    try {
      const final = await pagina("textos", { campos: estado.campos });
      api("/aprender", { dictado: estado.insertados, final }).then((r) => {
        if (r && r.aprendidas && r.aprendidas.length) mostrarAprendido(r.aprendidas);
        setTimeout(revisarCalidad, 500);
      }).catch(() => {});
      estado.insertados = [];
    } catch (_) {}
  }, true);

  // ------------------------------------------------------------------ calidad: precisión y sugerencias
  let sugerencias = [];
  async function revisarCalidad() {
    try {
      const e = await api("/estadisticas");
      const t = e.total || {};
      $(".precision").textContent = t.palabras >= 50 ? `Precisión: ${String(t.precision).replace(".", ",")} % (${t.palabras} palabras)` : "";
    } catch (_) {}
    try {
      sugerencias = (await api("/sugerencias")).sugerencias || [];
      const b = $(".sug-btn");
      b.hidden = !sugerencias.length;
      b.textContent = `💡 ${sugerencias.length} sugerencia${sugerencias.length === 1 ? "" : "s"}`;
      if (!$(".sug-lista").hidden) pintarSugerencias();
    } catch (_) {}
  }
  function pintarSugerencias() {
    const l = $(".sug-lista");
    l.innerHTML = "";
    if (!sugerencias.length) { l.hidden = true; return; }
    const h = document.createElement("div");
    h.className = "sug-ayuda"; h.textContent = "Cambios que haces seguido. ✓ = corregir siempre así.";
    l.appendChild(h);
    for (const x of sugerencias.slice(0, 8)) {
      const f = document.createElement("div");
      f.className = "sug";
      const t = document.createElement("span");
      t.textContent = `«${x.de}» → «${x.a}» (${x.veces}×)`;
      t.title = "Ejemplo: " + x.ejemplo;
      const si = document.createElement("button"); si.textContent = "✓"; si.title = "Aceptar";
      const no = document.createElement("button"); no.textContent = "✗"; no.title = "No sugerir más";
      si.onclick = async () => { await api("/sugerencias/aceptar", { de: x.de, a: x.a }).catch(() => {}); revisarCalidad(); };
      no.onclick = async () => { await api("/sugerencias/rechazar", { de: x.de, a: x.a }).catch(() => {}); revisarCalidad(); };
      f.append(t, si, no);
      l.appendChild(f);
    }
  }
  $(".sug-btn").onclick = () => { const l = $(".sug-lista"); l.hidden = !l.hidden; if (!l.hidden) pintarSugerencias(); };

  // ------------------------------------------------------------------ lo que VozRad aprendió solo
  function mostrarAprendido(lista) {
    const c = $(".aprendi");
    c.innerHTML = "";
    const t = document.createElement("span");
    t.textContent = "Aprendí: " + lista.slice(0, 3).map((x) => `«${x.de}» → «${x.a}»`).join(", ") + (lista.length > 3 ? ` y ${lista.length - 3} más` : "");
    const b = document.createElement("button");
    b.textContent = "Deshacer";
    b.onclick = async () => { await api("/aprendizaje/deshacer", { lista }).catch(() => {}); c.hidden = true; aviso("Listo, no lo volveré a corregir así.", 4000); };
    c.append(t, b);
    c.hidden = false;
    clearTimeout(mostrarAprendido.t);
    mostrarAprendido.t = setTimeout(() => { c.hidden = true; }, 25000);
  }

  // ------------------------------------------------------------------ arranque
  async function revisarServidor() {
    try {
      const { servidor } = await chrome.storage.local.get("servidor");
      estado.remoto = !!(servidor && servidor.url);
      estado.urlMotor = estado.remoto ? servidor.url : "";
    } catch (_) {}
    try {
      const e = await api("/estado");
      if (!ACT.enCurso) pintarActualizacion(e && e.actualizacion);
      revisarVersionPanel(e && e.version);
      estado.equipo = (e && e.equipo || "").replace(/\.local$/, "");
      if (!estado.servidorOk) {
        const cfg = await api("/config");
        estado.campos = cfg.campos || {};
        estado.audioCfg = { ...estado.audioCfg, ...(cfg.audio || {}) };
        VIVO.activo = cfg.texto_en_vivo !== false;
        revisarCalidad();
        construirBotonesCampos();
        await pagina("preparar", { campos: estado.campos, nombresPropios: cfg.nombres_propios || [] });
        await activarCampo(estado.activo, true);   // reconexión: NO mover el cursor que dejaste en la plantilla
      }
      estado.servidorOk = true;
    } catch (_) { estado.servidorOk = false; }
    pintar();
  }

  // ------------------------------------------------------------------ actualizaciones con un clic
  const ACT = { version: null, enCurso: false, confirmar: false };
  // El panel (extensión) de ESTE computador no se actualiza solo cuando el motor es otro equipo.
  function revisarVersionPanel(vMotor) {
    const caja = $(".ext-vieja");
    const mia = chrome.runtime.getManifest().version;
    const num = (v) => String(v || "0").split(".").map((x) => parseInt(x, 10) || 0);
    const a = num(vMotor), b = num(mia);
    const atrasado = vMotor && (a[0] - b[0] || a[1] - b[1] || a[2] - b[2]) > 0;
    caja.hidden = !atrasado;
    if (!atrasado) return;
    caja.textContent = estado.remoto
      ? `Panel de este PC ${mia} · motor ${vMotor}: en este PC abre servidor\\actualizar_pc.bat y luego pulsa ↻ en edge://extensions.`
      : `Panel ${mia} · motor ${vMotor}: pulsa ↻ (Recargar) en edge://extensions y recarga esta página.`;
  }

  function pintarActualizacion(version) {
    ACT.version = version || null;
    const caja = $(".actualizar");
    caja.hidden = !ACT.version;
    if (!ACT.version) return;
    $(".act-txt").textContent = `★ Versión nueva ${ACT.version}`;
    $(".act-btn").textContent = ACT.confirmar ? "¿Ahora? Sí" : "Actualizar";
    $(".act-btn").disabled = false; $(".act-ver").hidden = false;
  }
  $(".act-ver").onclick = async () => {
    const n = $(".act-notas");
    if (!n.hidden) { n.hidden = true; return; }
    try { const r = await api("/actualizacion"); n.textContent = r.novedades || "Correcciones de errores y mejoras."; } catch (_) { n.textContent = "Correcciones de errores y mejoras."; }
    n.hidden = false;
  };
  $(".act-btn").onclick = async () => {
    if (estado.grabando || estado.pendientes > 0) { aviso("Termina de dictar (pausa el SpeechMike) y vuelve a pulsar Actualizar.", 6000); return; }
    if (!ACT.confirmar) { ACT.confirmar = true; pintarActualizacion(ACT.version); setTimeout(() => { ACT.confirmar = false; if (!ACT.enCurso) pintarActualizacion(ACT.version); }, 6000); return; }
    ACT.enCurso = true; ACT.confirmar = false;
    $(".act-btn").disabled = true; $(".act-ver").hidden = true; $(".act-notas").hidden = true;
    $(".act-txt").textContent = `Descargando e instalando ${ACT.version}…`;
    let r;
    try { r = await api("/actualizacion/aplicar", {}); } catch (e) { r = { ok: false, error: e.message }; }
    if (!r || !r.ok) {
      ACT.enCurso = false; pintarActualizacion(ACT.version);
      aviso("No se pudo actualizar: " + ((r && r.error) || "error desconocido") + ". Tu versión actual sigue funcionando.", 10000);
      return;
    }
    $(".act-txt").textContent = `Reiniciando el motor con ${r.hasta}…`;
    estado.servidorOk = false; pintar();
    for (let i = 0; i < 60; i++) {                     // hasta ~2 min (la primera carga del modelo tarda)
      await new Promise((ok) => setTimeout(ok, 2000));
      try {
        const e = await api("/estado");
        if (e && e.version === r.hasta && e.ok) {
          ACT.enCurso = false;
          await revisarServidor();
          $(".actualizar").hidden = true;
          const local = !estado.remoto;
          aviso(r.cambia_extension
            ? (local ? `✓ VozRad actualizado a ${r.hasta}. Esta versión también mejora el panel: recarga esta página (F5).`
                     : `✓ Motor actualizado a ${r.hasta}. Para el panel de este PC: abre servidor\\actualizar_pc.bat y pulsa ↻ en edge://extensions.`)
            : `✓ VozRad actualizado a ${r.hasta}.`, 12000);
          if (r.cambia_extension && local) chrome.runtime.sendMessage({ tipo: "recargar_extension" });
          return;
        }
      } catch (_) {}
    }
    ACT.enCurso = false;
    aviso("El motor tarda en volver. Revisa la ventana de VozRad en el computador del motor.", 10000);
  };

  // ------------------------------------------------------------------ prueba de calidad del micrófono
  const FRASE_PRUEBA = {
    leer: "El hígado es de tamaño normal, sin lesiones focales. La vía biliar no está dilatada y el conducto de Wirsung es de calibre normal. El riñón derecho mide once centímetros. No hay líquido libre.",
    esperado: "El hígado es de tamaño normal sin lesiones focales la vía biliar no está dilatada y el conducto de Wirsung es de calibre normal el riñón derecho mide 11 cm no hay líquido libre",
  };
  const MIC = { activo: false, fase: "", sil: [], voz: [], cancelar: null, boton: null };

  function micCaja(html) { const c = $(".mic-caja"); c.hidden = false; c.innerHTML = html; return c; }
  function cerrarMic() { if (MIC.cancelar) MIC.cancelar(); $(".mic-caja").hidden = true; }

  async function pruebaMicrofono() {
    if (MIC.activo) return;
    if (estado.grabando) detenerGrabacion();
    if (!estado.servidorOk) { await revisarServidor(); if (!estado.servidorOk) { aviso("El motor de voz no está encendido. Abre «iniciar» de VozRad (iniciar.bat en Windows, iniciar.command en Mac), o revisa ⚙ si usas un motor en red", 8000); return; } }
    MIC.activo = true; MIC.sil = []; MIC.voz = [];
    let flujoP, ctxP, procP, terminar;
    const fin = new Promise((r) => (terminar = r));
    MIC.cancelar = () => terminar("cancelado");
    try {
      const base = { channelCount: 1, echoCancellation: false, noiseSuppression: false, autoGainControl: false };
      let pref = {}; try { pref = await elegirMicrofono(); } catch (_) {}
      flujoP = await navigator.mediaDevices.getUserMedia({ audio: { ...base, ...pref } });
      if (!pref.deviceId) { const p2 = await elegirMicrofono().catch(() => ({})); if (p2.deviceId) { flujoP.getTracks().forEach((t) => t.stop()); flujoP = await navigator.mediaDevices.getUserMedia({ audio: { ...base, ...p2 } }); } }
    } catch (e) { MIC.activo = false; aviso("No pude abrir el micrófono: " + e.message, 8000); return; }
    const pista = flujoP.getAudioTracks()[0];
    const ajustes = (pista.getSettings && pista.getSettings()) || {};
    const nombreMic = pista.label || "predeterminado";

    const caja = micCaja(`
      <div class="caja-tit">Prueba de micrófono</div>
      <div class="mic-nombre">🎙 ${nombreMic.replace(/</g, "&lt;")}</div>
      <div class="mic-paso"></div>
      <div class="mic-medidor"><div class="mic-barra"></div><div class="mic-zona"></div></div>
      <div class="mic-frase" hidden></div>
      <div class="fila"><button class="mic-listo" hidden>Terminé de leer</button><button class="mic-cancelar">Cancelar</button></div>`);
    caja.querySelector(".mic-cancelar").onclick = cerrarMic;
    caja.querySelector(".mic-listo").onclick = () => terminar("listo");
    const paso = caja.querySelector(".mic-paso"), barra = caja.querySelector(".mic-barra");

    ctxP = new AudioContext({ sampleRate: 16000 });
    const fuente = ctxP.createMediaStreamSource(flujoP);
    procP = ctxP.createScriptProcessor(FRAME, 1, 1);
    let ruido = 0.003, vozMs = 0, silMs = 0;
    procP.onaudioprocess = (e) => {
      const f = new Float32Array(e.inputBuffer.getChannelData(0));
      let q = 0; for (let i = 0; i < f.length; i++) q += f[i] * f[i];
      const rms = Math.sqrt(q / f.length), db = 20 * Math.log10(Math.max(rms, 1e-6));
      barra.style.width = Math.max(0, Math.min(100, ((db + 70) / 70) * 100)) + "%";
      barra.className = "mic-barra " + (db > -8 ? "alto" : db > -40 ? "ok" : "bajo");
      if (MIC.fase === "silencio") { MIC.sil.push(f); return; }
      if (MIC.fase !== "voz") return;
      MIC.voz.push(f);
      const ms = (f.length / 16000) * 1000;
      if (rms > Math.max(ruido * 4, 0.004)) { vozMs += ms; silMs = 0; } else silMs += ms;
      const largo = (MIC.voz.length * ms) / 1000;
      if ((vozMs > 4000 && silMs > 1800) || largo > 30) terminar("listo");
    };
    fuente.connect(procP); procP.connect(ctxP.destination);
    const limpiar = () => {
      try { procP.disconnect(); ctxP.close(); } catch (_) {}
      flujoP.getTracks().forEach((t) => t.stop());
      MIC.fase = ""; MIC.activo = false; MIC.cancelar = null; MIC.boton = null;
      actualizarLeds();
      setTimeout(vigilarSpeechMike, 800);       // por si el SpeechMike se reinició al abrir/cerrar su micrófono
    };

    // paso 1: silencio
    MIC.fase = "silencio";
    paso.innerHTML = "<b>1 de 2.</b> Quédate en <b>silencio</b> 3 segundos (mide el ruido de fondo)…";
    const r1 = await Promise.race([fin, new Promise((r) => setTimeout(() => r("ok"), 3000))]);
    if (r1 === "cancelado") { limpiar(); return; }
    let q = 0, n = 0; MIC.sil.forEach((f) => { for (let i = 0; i < f.length; i++) q += f[i] * f[i]; n += f.length; });
    ruido = Math.sqrt(q / Math.max(n, 1));
    // paso 2: lectura
    MIC.fase = "voz";
    paso.innerHTML = "<b>2 de 2.</b> Lee en voz alta, como cuando dictas (sin decir «coma» ni «punto»). Al terminar pulsa «Terminé» o el botón Record del SpeechMike:";
    const fr = caja.querySelector(".mic-frase"); fr.hidden = false; fr.textContent = FRASE_PRUEBA.leer;
    caja.querySelector(".mic-listo").hidden = false;
    MIC.boton = () => { if (vozMs >= 1500) terminar("listo"); };   // pulsarlo al empezar a leer no corta la prueba
    actualizarLeds();
    const r2 = await fin;
    limpiar();
    if (r2 === "cancelado") return;

    micCaja(`<div class="caja-tit">Prueba de micrófono</div><div class="mic-paso">Analizando…</div>`);
    let res;
    try {
      res = await api("/calidad", {
        silencio: aBase64(aPCM(MIC.sil)), voz: aBase64(aPCM(MIC.voz)), esperado: FRASE_PRUEBA.esperado,
        microfono: nombreMic,
        procesamiento: { echoCancellation: !!ajustes.echoCancellation, noiseSuppression: !!ajustes.noiseSuppression, autoGainControl: !!ajustes.autoGainControl },
      });
    } catch (e) { micCaja(`<div class="caja-tit">Prueba de micrófono</div><div class="mic-paso">Error: ${e.message}</div><div class="fila"><button class="mic-cerrar">Cerrar</button></div>`).querySelector(".mic-cerrar").onclick = cerrarMic; return; }
    if (!res.ok) { micCaja(`<div class="caja-tit">Prueba de micrófono</div><div class="mic-paso">${res.motivo}</div><div class="fila"><button class="mic-otra">Repetir</button><button class="mic-cerrar">Cerrar</button></div>`); }
    else {
      const titulo = { bien: "✅ Tu micrófono está bien", regular: "⚠️ Se puede mejorar", mal: "❌ El audio está afectando el reconocimiento" }[res.general];
      const esc = (t) => String(t).replace(/</g, "&lt;");
      micCaja(`
        <div class="caja-tit">Prueba de micrófono</div>
        <div class="mic-general ${res.general}">${titulo}</div>
        <div class="mic-nombre">🎙 ${esc(res.microfono)}</div>
        <table class="mic-tabla">${res.items.map((i) => `<tr><td><span class="semaforo ${i.nota}"></span>${i.nombre}</td><td>${esc(i.valor)}</td></tr>`).join("")}</table>
        ${res.consejos.length ? `<ul class="mic-consejos">${res.consejos.map((c) => `<li>${esc(c)}</li>`).join("")}</ul>` : ""}
        <details class="mic-oido"><summary>Qué entendí</summary>${esc(res.obtenido || "(nada)")}</details>
        <div class="fila"><button class="mic-otra">Repetir prueba</button><button class="mic-cerrar">Cerrar</button></div>`);
    }
    $(".mic-caja .mic-cerrar").onclick = cerrarMic;
    $(".mic-caja .mic-otra").onclick = () => pruebaMicrofono();
  }
  $(".cfg-btn").onclick = () => chrome.runtime.sendMessage({ tipo: "abrir_opciones" });
  // si cambias de motor en ⚙, el panel se reconecta solo
  chrome.storage.onChanged.addListener((cambios) => {
    if (cambios.servidor) { estado.servidorOk = false; revisarServidor(); }
  });
  $(".mic-btn").onclick = () => ($(".mic-caja").hidden || MIC.activo ? pruebaMicrofono() : cerrarMic());

  async function arrancar() {
    // Solo en pantallas con el editor del informe
    let info = null;
    for (let i = 0; i < 20; i++) {
      info = await pagina("ping").catch(() => null);
      if (info && info.ckeditor && info.instancias.some((n) => n.startsWith("txtHal"))) break;
      info = null;
      await new Promise((r) => setTimeout(r, 500));
    }
    if (!info) return;

    const { posicion } = await chrome.storage.local.get("posicion");
    if (posicion && posicion.left) { host.style.left = posicion.left; host.style.top = posicion.top; host.style.right = "auto"; host.style.bottom = "auto"; }
    // ¿hay otra copia de VozRad (otra carpeta/versión) ya funcionando en esta página?
    const otra = document.documentElement.dataset.vozradExt;
    if (otra && otra !== chrome.runtime.id) {
      console.warn("[VozRad] otra copia de la extensión ya está activa en esta página:", otra);
      const aviso2 = document.createElement("div");
      aviso2.style.cssText = "position:fixed;left:20px;bottom:20px;z-index:2147483647;background:#e0533d;color:#fff;padding:10px 14px;border-radius:8px;font:13px system-ui;max-width:360px";
      aviso2.textContent = "VozRad está instalado DOS veces (por eso las frases pueden salir repetidas). Abre edge://extensions, quita la copia antigua y recarga esta página.";
      document.documentElement.appendChild(aviso2);
      return;
    }
    document.documentElement.dataset.vozradExt = chrome.runtime.id;
    document.documentElement.appendChild(host);
    pintar(); pintarInvox();
    await revisarServidor();
    setInterval(revisarServidor, 10000);
    setInterval(vigilarSpeechMike, 5000);
    conectarSpeechMike(false);   // si ya diste permiso antes, se conecta solo
  }

  arrancar();
})();

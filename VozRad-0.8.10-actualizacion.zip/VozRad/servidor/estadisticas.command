#!/bin/bash
# VozRad - precisión y sugerencias. Doble clic desde el Finder.
cd "$(dirname "$0")" || exit 1
printf '\033]0;VozRad - precisión y sugerencias\007'
if [ ! -x .venv/bin/python ]; then echo "Primero haz doble clic en instalar.command"; read -r -p "Enter para cerrar..." _; exit 1; fi
.venv/bin/python aprendizaje.py
read -r -p "Presiona Enter para cerrar..." _

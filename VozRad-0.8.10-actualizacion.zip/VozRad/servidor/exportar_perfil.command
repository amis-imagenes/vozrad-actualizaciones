#!/bin/bash
# VozRad - exportar tu perfil. Doble clic desde el Finder.
cd "$(dirname "$0")" || exit 1
if [ ! -x .venv/bin/python ]; then echo "Primero haz doble clic en instalar.command"; read -r -p "Enter para cerrar..." _; exit 1; fi
.venv/bin/python perfil_portatil.py exportar
echo
read -r -p "Presiona Enter para cerrar..." _

@echo off
chcp 65001 >nul
title VozRad - exportar perfil
cd /d "%~dp0"
.venv\Scripts\python.exe perfil_portatil.py exportar
pause

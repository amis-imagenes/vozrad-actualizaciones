#!/bin/bash
# VozRad - servidor de voz. Doble clic desde el Finder y deja esta ventana abierta.
cd "$(dirname "$0")" || exit 1
printf '\033]0;VozRad - servidor de voz\007'
if [ ! -x .venv/bin/python ]; then
  echo "Primero haz doble clic en instalar.command"
  read -r -p "Presiona Enter para cerrar..." _
  exit 1
fi
# que el Mac no se duerma mientras VozRad está abierto (solo mientras dure esta ventana)
if command -v caffeinate >/dev/null 2>&1; then
  caffeinate -i -w $$ &
fi
# código 3 = el motor se actualizó y pide reiniciarse: se vuelve a abrir solo
while true; do
  .venv/bin/python servidor.py
  [ $? -eq 3 ] || break
  echo; echo "[VozRad] Reiniciando con la versión nueva..."; echo
done
echo
read -r -p "VozRad se cerró. Presiona Enter para cerrar esta ventana..." _

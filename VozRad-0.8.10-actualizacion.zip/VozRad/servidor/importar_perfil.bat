@echo off
chcp 65001 >nul
title VozRad - importar perfil
cd /d "%~dp0"
.venv\Scripts\python.exe perfil_portatil.py importar
pause

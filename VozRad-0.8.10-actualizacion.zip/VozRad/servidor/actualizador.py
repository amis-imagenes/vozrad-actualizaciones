"""
VozRad - actualizaciones con un clic.

Las versiones nuevas se publican como  VozRad-X.Y.Z-actualizacion.zip  (+ VozRad-X.Y.Z-novedades.txt)
en la carpeta de Google Drive «VozRad actualizaciones». Este módulo:
  1. revisa esa carpeta (al iniciar y cada 6 horas) y avisa si hay una versión más nueva;
  2. cuando pulsas «Actualizar» en el panel: descarga el zip, lo valida, guarda un respaldo de los
     archivos del programa que va a reemplazar, los reemplaza (NUNCA toca tus datos: informes,
     historial, perfil, modelos, config, correcciones, plantillas, vocabulario) y reinicia el motor.

Fuentes de versiones (la primera que exista):
  - una carpeta local sincronizada con Drive (si instalas «Google Drive para escritorio»), o
  - la carpeta pública de Drive (config.json -> "canal_actualizaciones": {"carpeta_drive_id": "..."}).
"""
import datetime as dt
import io
import json
import re
import shutil
import threading
import time
import zipfile
from pathlib import Path

BASE = Path(__file__).resolve().parent          # .../VozRad/servidor
RAIZ = BASE.parent                              # .../VozRad
NOMBRE_CARPETA = "VozRad actualizaciones"
NO_TOCAR = ("servidor/informes/", "servidor/historial/", "servidor/perfil/", "servidor/modelos/",
            "servidor/.venv/", "servidor/venv/", "servidor/respaldos/")
ARCHIVOS_DE_USUARIO = {"servidor/config.json", "servidor/correcciones.json", "servidor/plantillas.json",
                       "servidor/vocabulario.txt", "servidor/terminos_prioritarios.txt", "servidor/nombres_propios.txt"}
PATRON = re.compile(r"VozRad-(\d+)\.(\d+)\.(\d+)-actualizacion\.zip$", re.I)

ESTADO = {"actual": "", "disponible": None, "novedades": "", "origen": None, "ultimo_chequeo": None,
          "error": "", "aplicando": False}


def version_actual() -> str:
    try:
        return json.loads((RAIZ / "extension" / "manifest.json").read_text(encoding="utf-8"))["version"]
    except Exception:  # noqa: BLE001
        return "0.0.0"


def _tupla(v: str):
    return tuple(int(x) for x in re.findall(r"\d+", v)[:3])


# ------------------------------------------------------------------ descarga
def _abrir(url: str, timeout=20) -> bytes:
    import urllib.request
    ctx = None
    try:
        import truststore                      # usa los certificados del sistema (Mac/Windows)
        ctx = truststore.SSLContext()
    except Exception:  # noqa: BLE001
        try:
            import ssl, certifi                # noqa: E401
            ctx = ssl.create_default_context(cafile=certifi.where())
        except Exception:  # noqa: BLE001
            ctx = None
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 VozRad"})
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return r.read()


def _listar_drive_publico(carpeta_id: str) -> dict:
    """{nombre: id} de los archivos de una carpeta de Drive compartida «con cualquier persona con el enlace»."""
    html = _abrir(f"https://drive.google.com/embeddedfolderview?id={carpeta_id}").decode("utf-8", "replace")
    archivos = {}
    for m in re.finditer(r'id="entry-([\w-]{10,})".*?flip-entry-title">([^<]+)<', html, re.S):
        archivos[m.group(2).strip()] = m.group(1)
    return archivos


def _bajar_drive(file_id: str) -> bytes:
    for url in (f"https://drive.usercontent.google.com/download?id={file_id}&export=download&confirm=t",
                f"https://drive.google.com/uc?export=download&id={file_id}"):
        try:
            datos = _abrir(url, timeout=60)
            if datos[:2] == b"PK" or url.endswith(".txt") or not datos.lstrip().startswith(b"<"):
                return datos
        except Exception:  # noqa: BLE001
            continue
    raise RuntimeError("no se pudo descargar desde Google Drive")


def _listar_github(repo: str) -> dict:
    """{nombre: url} de las versiones publicadas en un repositorio público de GitHub: archivos de la
    carpeta principal (VozRad-X.Y.Z-actualizacion.zip, -novedades.txt) y, si hay, de sus «releases»."""
    archivos = {}
    try:
        for a in json.loads(_abrir(f"https://api.github.com/repos/{repo}/contents/").decode("utf-8")):
            if a.get("type") == "file" and a.get("download_url"):
                archivos[a["name"]] = a["download_url"]
    except Exception:  # noqa: BLE001
        pass
    try:
        for rel in json.loads(_abrir(f"https://api.github.com/repos/{repo}/releases?per_page=10").decode("utf-8")):
            for a in rel.get("assets", []):
                archivos.setdefault(a["name"], a["browser_download_url"])
    except Exception:  # noqa: BLE001
        pass
    if not archivos:
        raise RuntimeError(f"no encontré versiones en github.com/{repo}")
    return archivos


def _carpetas_locales():
    """Carpeta «VozRad actualizaciones» sincronizada por Google Drive para escritorio (si existe)."""
    home = Path.home()
    candidatas = []
    for cs in (home / "Library" / "CloudStorage").glob("GoogleDrive-*"):          # Mac
        candidatas += [cs / "Mi unidad" / NOMBRE_CARPETA, cs / "My Drive" / NOMBRE_CARPETA]
    for letra in "GHIJKLM":                                                         # Windows
        candidatas += [Path(f"{letra}:/Mi unidad") / NOMBRE_CARPETA, Path(f"{letra}:/My Drive") / NOMBRE_CARPETA]
    candidatas += [home / "Google Drive" / NOMBRE_CARPETA, home / "Mi unidad" / NOMBRE_CARPETA]
    return [c for c in candidatas if c.is_dir()]


# ------------------------------------------------------------------ buscar
def _fuentes(cfg: dict):
    canal = cfg.get("canal_actualizaciones") or {}
    for carpeta in ([Path(canal["carpeta_local"])] if canal.get("carpeta_local") else []) + _carpetas_locales():
        if carpeta.is_dir():
            archivos = {p.name: p for p in carpeta.iterdir()}
            yield ("local", archivos, lambda ref: Path(ref).read_bytes())
            return
    if canal.get("github"):
        try:
            yield ("github", _listar_github(canal["github"]), lambda url: _abrir(url, timeout=60))
            return
        except Exception as e:  # noqa: BLE001
            ESTADO["error"] = f"GitHub: {str(e)[:100]}"
    if canal.get("carpeta_drive_id"):
        yield ("drive", _listar_drive_publico(canal["carpeta_drive_id"]), _bajar_drive)


def buscar(cfg: dict) -> dict:
    ESTADO["actual"] = version_actual()
    ESTADO["ultimo_chequeo"] = dt.datetime.now().isoformat(timespec="seconds")
    ESTADO["error"] = ""
    try:
        for origen, archivos, leer in _fuentes(cfg):
            versiones = []
            for nombre, ref in archivos.items():
                m = PATRON.match(nombre)
                if m:
                    versiones.append(((int(m.group(1)), int(m.group(2)), int(m.group(3))), nombre, ref))
            if not versiones:
                continue
            mejor = max(versiones)
            if mejor[0] > _tupla(ESTADO["actual"]):
                v = ".".join(map(str, mejor[0]))
                notas = ""
                ref_notas = archivos.get(f"VozRad-{v}-novedades.txt")
                if ref_notas is not None:
                    try:
                        notas = leer(ref_notas).decode("utf-8", "replace")[:3000]
                    except Exception:  # noqa: BLE001
                        notas = ""
                ESTADO.update(disponible=v, novedades=notas, origen=(origen, mejor[1], mejor[2], leer))
            else:
                ESTADO.update(disponible=None, novedades="", origen=None)
            return publico()
    except Exception as e:  # noqa: BLE001
        ESTADO["error"] = f"{type(e).__name__}: {str(e)[:150]}"
    return publico()


def publico() -> dict:
    ESTADO["actual"] = version_actual()
    return {k: ESTADO[k] for k in ("actual", "disponible", "novedades", "ultimo_chequeo", "error", "aplicando")}


def revisar_periodicamente(leer_cfg, cada_horas=6):
    def bucle():
        time.sleep(20)
        while True:
            antes = ESTADO["disponible"]
            buscar(leer_cfg())
            if ESTADO["disponible"] and ESTADO["disponible"] != antes:
                print(f"[VozRad] ★ Hay una versión nueva: {ESTADO['disponible']} (actual {ESTADO['actual']}). "
                      "Actualízala desde el panel cuando termines de dictar.", flush=True)
            time.sleep(cada_horas * 3600)
    threading.Thread(target=bucle, daemon=True).start()


# ------------------------------------------------------------------ aplicar
def _validar(z: zipfile.ZipFile) -> list:
    nombres = z.namelist()
    if "VozRad/extension/manifest.json" not in nombres:
        raise RuntimeError("el archivo no parece una actualización de VozRad")
    seguros = []
    for n in nombres:
        if not n.startswith("VozRad/") or ".." in n or n.endswith("/"):
            continue
        rel = n[len("VozRad/"):]
        if rel in ARCHIVOS_DE_USUARIO or rel.startswith(NO_TOCAR):
            continue                                    # tus datos nunca se reemplazan
        seguros.append((n, rel))
    return seguros


BAT_EN_USO = None      # None = todos los .bat podrían estar en uso (servidor); en modo «actualizar_pc» solo ese


def aplicar() -> dict:
    if not ESTADO["origen"]:
        raise RuntimeError("no hay ninguna actualización pendiente")
    ESTADO["aplicando"] = True
    try:
        _, nombre, ref, leer = ESTADO["origen"]
        datos = leer(ref)
        z = zipfile.ZipFile(io.BytesIO(datos))
        if z.testzip() is not None:
            raise RuntimeError("el archivo descargado está dañado")
        archivos = _validar(z)
        nueva = json.loads(z.read("VozRad/extension/manifest.json"))["version"]
        anterior = version_actual()
        # respaldo de lo que se va a reemplazar
        respaldo = BASE / "respaldos" / f"antes-de-{nueva}-{dt.datetime.now():%Y%m%d-%H%M%S}"
        req_antes = (BASE / "requirements.txt").read_bytes() if (BASE / "requirements.txt").exists() else b""
        for _, rel in archivos:
            destino = RAIZ / rel
            if destino.exists():
                (respaldo / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(destino, respaldo / rel)
        # reemplazo (archivo por archivo, de forma segura)
        bat_pendientes = []
        cambia_extension = any(rel.startswith("extension/") and (not (RAIZ / rel).exists() or (RAIZ / rel).read_bytes() != z.read(n))
                               for n, rel in archivos)
        for n, rel in archivos:
            destino = RAIZ / rel
            destino.parent.mkdir(parents=True, exist_ok=True)
            if rel.endswith(".bat") and destino.exists() and (BAT_EN_USO is None or destino.name in BAT_EN_USO):
                # Windows lee el .bat mientras lo ejecuta: reemplazarlo en uso lo desordena
                if destino.read_bytes() != z.read(n):
                    (destino.with_name(destino.name + ".nuevo")).write_bytes(z.read(n))
                    bat_pendientes.append(destino.name)
                continue
            tmp = destino.with_name(destino.name + ".nuevo")
            tmp.write_bytes(z.read(n))
            try:
                info = z.getinfo(n)
                modo = (info.external_attr >> 16) & 0o777
                if modo:
                    tmp.chmod(modo)                     # conserva permisos de los .command
            except Exception:  # noqa: BLE001
                pass
            tmp.replace(destino)
        # paquetes nuevos si cambió requirements.txt
        if (BASE / "requirements.txt").exists() and (BASE / "requirements.txt").read_bytes() != req_antes:
            import subprocess
            import sys
            print("[VozRad] Instalando paquetes nuevos de la actualización...", flush=True)
            subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-r", str(BASE / "requirements.txt")], check=False)
        (BASE / "respaldos").mkdir(exist_ok=True)
        (BASE / "respaldos" / "ultima_actualizacion.json").write_text(json.dumps({
            "desde": anterior, "hasta": nueva, "fecha": dt.datetime.now().isoformat(timespec="seconds"),
            "archivo": nombre, "respaldo": str(respaldo), "archivos": len(archivos)}, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[VozRad] ✓ Actualizado {anterior} -> {nueva} ({len(archivos)} archivos). Respaldo en {respaldo.name}. Reiniciando...", flush=True)
        if bat_pendientes:
            print(f"[VozRad]   Cierra esta ventana cuando puedas y renombra {', '.join(x + '.nuevo' for x in bat_pendientes)} "
                  "(quitando «.nuevo») para completar la actualización.", flush=True)
        ESTADO.update(disponible=None, origen=None)
        return {"ok": True, "desde": anterior, "hasta": nueva, "cambia_extension": cambia_extension}
    finally:
        ESTADO["aplicando"] = False


def principal():
    """actualizar_pc.bat / actualizar_pc.command: actualiza ESTE computador (útil en el PC que usa el motor
    de otro equipo y no abre iniciar.bat, así su extensión queda al día)."""
    global BAT_EN_USO
    BAT_EN_USO = {"actualizar_pc.bat"}
    try:
        cfg = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        cfg = {}
    if not cfg.get("canal_actualizaciones"):
        try:
            cfg["canal_actualizaciones"] = json.loads((BASE / "actualizacion_datos.json").read_text(encoding="utf-8"))["config"]["canal_actualizaciones"]
        except Exception:  # noqa: BLE001
            pass
    print(f"[VozRad] Versión instalada: {version_actual()}. Buscando una más nueva...", flush=True)
    e = buscar(cfg)
    if not e.get("disponible"):
        print(f"[VozRad] Ya tienes la última versión ({e.get('actual')})." + (f"  ({e['error']})" if e.get("error") else ""))
        return 0
    print(f"[VozRad] Versión nueva: {e['disponible']}\n{e.get('novedades', '')}\n", flush=True)
    r = aplicar()
    print(f"\n[VozRad] ✓ Listo: {r['desde']} -> {r['hasta']}.")
    print("[VozRad] Último paso: en Edge/Chrome abre  edge://extensions  (o chrome://extensions),")
    print("         pulsa ↻ (Recargar) en VozRad y recarga la página del RIS.")
    return 0


if __name__ == "__main__":
    raise SystemExit(principal())

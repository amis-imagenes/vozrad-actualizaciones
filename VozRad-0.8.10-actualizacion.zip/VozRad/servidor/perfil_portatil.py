"""
VozRad - llevar tu perfil a otro computador (Windows -> Mac, o a otro puesto).

  exportar:  crea  VozRad-perfil-AAAA-MM-DD.zip  en la carpeta del servidor con todo lo aprendido:
             tus informes importados, correcciones, vocabulario, plantillas, frases tipo y ajustes.
  importar:  en el otro computador, carga ese zip (lo busca en esta carpeta y en Descargas/Escritorio).
             Guarda un respaldo de lo que había antes en  perfil/respaldo_antes_de_importar.zip

Se copian también los audios de «Entrenar palabra» (pocos y livianos): el otro equipo vuelve a aprender
esas palabras solo al iniciar. No se copia el audio de los dictados (pesa mucho) ni ajustes propios de
cada equipo (núcleos del procesador).
"""
import datetime as dt
import json
import sys
import zipfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
ARCHIVOS = ["correcciones.json", "vocabulario.txt", "terminos_prioritarios.txt", "plantillas.json",
            "nombres_propios.txt", "config.json"]
CARPETAS = {"informes": ["informes.jsonl"],
            "historial": ["correcciones_manuales.jsonl", "aprendido.jsonl", "sugerencias_rechazadas.json"]}
PROPIO_DEL_EQUIPO = ["hilos_cpu", "dispositivo"]      # no se lleva de un computador a otro


def exportar() -> Path:
    destino = BASE / f"VozRad-perfil-{dt.date.today().isoformat()}.zip"
    n = 0
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
        for a in ARCHIVOS:
            p = BASE / a
            if p.exists():
                if a == "config.json":
                    cfg = json.loads(p.read_text(encoding="utf-8"))
                    for k in PROPIO_DEL_EQUIPO:
                        cfg.pop(k, None)
                    z.writestr(a, json.dumps(cfg, ensure_ascii=False, indent=2))
                else:
                    z.write(p, a)
                n += 1
        for carpeta, nombres in CARPETAS.items():
            for nombre in nombres:
                p = BASE / carpeta / nombre
                if p.exists():
                    z.write(p, f"{carpeta}/{nombre}")
                    n += 1
        for wav in sorted((BASE / "historial" / "entrenamiento").glob("*.wav")):    # para reentrenar en el otro equipo
            z.write(wav, f"historial/entrenamiento/{wav.name}")
            n += 1
        z.writestr("perfil_vozrad.json", json.dumps({"creado": dt.datetime.now().isoformat(timespec="seconds"),
                                                       "archivos": n}, ensure_ascii=False))
    informes = 0
    p = BASE / "informes" / "informes.jsonl"
    if p.exists():
        informes = sum(1 for _ in p.open(encoding="utf-8"))
    print(f"Perfil exportado: {destino}")
    print(f"  {n} archivos, {informes} informes, {destino.stat().st_size / 1e6:.1f} MB")
    print("Copia ese archivo al otro computador (pendrive, correo, Drive...) y allí abre «importar_perfil».")
    return destino


def _buscar_zip() -> Path | None:
    lugares = [BASE, Path.home() / "Downloads", Path.home() / "Descargas", Path.home() / "Desktop", Path.home() / "Escritorio"]
    candidatos = [p for d in lugares if d.exists() for p in d.glob("VozRad-perfil-*.zip")]
    return max(candidatos, key=lambda p: p.stat().st_mtime) if candidatos else None


def importar(ruta: Path | None = None):
    ruta = ruta or _buscar_zip()
    if not ruta or not ruta.exists():
        print("No encontré ningún archivo VozRad-perfil-....zip")
        print("Ponlo en la carpeta «servidor» de VozRad, en Descargas o en el Escritorio, y vuelve a intentar.")
        return False
    with zipfile.ZipFile(ruta) as z:
        if "perfil_vozrad.json" not in z.namelist():
            print(f"{ruta.name} no parece un perfil de VozRad.")
            return False
        # respaldo de lo actual
        (BASE / "perfil").mkdir(exist_ok=True)
        with zipfile.ZipFile(BASE / "perfil" / "respaldo_antes_de_importar.zip", "w", zipfile.ZIP_DEFLATED) as r:
            for a in ARCHIVOS:
                if (BASE / a).exists():
                    r.write(BASE / a, a)
            for carpeta, nombres in CARPETAS.items():
                for nombre in nombres:
                    if (BASE / carpeta / nombre).exists():
                        r.write(BASE / carpeta / nombre, f"{carpeta}/{nombre}")
        local = {}
        if (BASE / "config.json").exists():
            local = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
        for nombre in z.namelist():
            if nombre == "perfil_vozrad.json" or nombre.endswith("/") or ".." in nombre:
                continue
            destino = BASE / nombre
            destino.parent.mkdir(parents=True, exist_ok=True)
            datos = z.read(nombre)
            if nombre == "config.json":
                cfg = json.loads(datos.decode("utf-8"))
                for k in PROPIO_DEL_EQUIPO:          # se mantiene lo propio de ESTE equipo
                    cfg.pop(k, None)
                    if k in local:
                        cfg[k] = local[k]
                datos = json.dumps(cfg, ensure_ascii=False, indent=2).encode("utf-8")
            destino.write_bytes(datos)
            print(f"  ✓ {nombre}")
    print(f"\nPerfil importado desde {ruta.name}.")
    print("Respaldo de lo que había antes: perfil/respaldo_antes_de_importar.zip")
    print("Abre (o reinicia) «iniciar» para usarlo.")
    return True


if __name__ == "__main__":
    accion = sys.argv[1] if len(sys.argv) > 1 else ""
    if accion == "exportar":
        exportar()
    elif accion == "importar":
        importar(Path(sys.argv[2]) if len(sys.argv) > 2 else None)
    else:
        print("Uso: python perfil_portatil.py exportar | importar [archivo.zip]")

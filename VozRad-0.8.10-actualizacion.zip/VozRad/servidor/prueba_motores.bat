@echo off
chcp 65001 >nul
title VozRad - comparar motores
cd /d "%~dp0"
echo Cierra iniciar.bat antes de continuar (para no competir por la tarjeta grafica).
pause
.venv\Scripts\python.exe prueba_motores.py
pause

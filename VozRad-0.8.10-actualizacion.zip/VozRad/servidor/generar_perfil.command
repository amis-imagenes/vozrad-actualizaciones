#!/bin/bash
# VozRad - aprender de tus informes. Doble clic desde el Finder.
cd "$(dirname "$0")" || exit 1
printf '\033]0;VozRad - aprender de tus informes\007'
if [ ! -x .venv/bin/python ]; then echo "Primero haz doble clic en instalar.command"; read -r -p "Enter para cerrar..." _; exit 1; fi
.venv/bin/python generar_perfil.py
echo; echo "Listo. Los cambios se aplican desde el siguiente dictado."
read -r -p "Presiona Enter para cerrar..." _

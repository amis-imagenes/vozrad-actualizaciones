@echo off
chcp 65001 >nul
title VozRad - motor en red
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Primero ejecuta instalar.bat
  pause & exit /b 1
)
echo Si Windows pregunta por el Firewall: permite el acceso en redes PRIVADAS.
:motor
.venv\Scripts\python.exe servidor.py --red
if errorlevel 3 if not errorlevel 4 (
  echo.
  echo [VozRad] Reiniciando con la version nueva...
  goto motor
)
pause

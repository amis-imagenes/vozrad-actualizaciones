"""
VozRad - aprende tu vocabulario y tu estilo a partir de tus informes importados.

Lee  informes/informes.jsonl  (creado por el importador) y genera en  perfil/ :
  vocabulario_sugerido.txt   términos que usas, ordenados por relevancia
  frases_frecuentes.txt      tus frases más repetidas, por sección
  frases_sugeridas.json      frases normales listas para copiar a plantillas.json
  plantillas_sugeridas.json  plantillas "normales" por tipo de estudio
  resumen.txt                estadísticas

Además actualiza la sección automática de vocabulario.txt (tus términos manuales no se tocan)
y el "prompt_base" de config.json con frases típicas tuyas, para que Whisper imite tu estilo.

Uso:  generar_perfil.bat (Windows) / generar_perfil.command (Mac)   (o:  python generar_perfil.py)
"""
import collections
import json
import re
import sys
import unicodedata
from pathlib import Path

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import texto as txtmod  # noqa: E402
ENTRADA = BASE / "informes" / "informes.jsonl"
SALIDA = BASE / "perfil"
MARCA_AUTO = "# ---- automático (generar_perfil) : no edites debajo de esta línea ----"

PALABRAS_COMUNES = set("""
a al algo algún alguna algunas alguno algunos ante antes aquí así aun aún bajo bien cada casi como con contra cual cuales
cuando de del desde donde dos el ella ellas ellos en entre era es esa esas ese eso esos esta está están estas este esto
estos fue fueron ha había han hasta hay la las le les lo los más mas me menos mientras muy nada ni no nos o otra otras
otro otros para pero poco por porque que qué se sea según ser si sí sin sino sobre son su sus también tan tanto te tiene
tienen todo todos tras tu un una uno unos y ya ambos ambas cual cuya cuyo debe dentro durante forma general lado mismo
misma parte puede realizado realizada respecto vez caso nivel tipo región zona lado derecho derecha izquierdo izquierda
normal normales observa observan aspecto conservado conservada conservados conservadas tamaño morfología signos
evidencia evidencian evidencias aprecia aprecian identifica identifican existe existen presenta presentan estudio
estudios examen previo previa control anterior actual características significativo significativa
""".split())

SUFIJOS_MEDICOS = ("osis", "itis", "ectasia", "ectasias", "patía", "patías", "denso", "densa", "densos", "densas", "intenso",
                   "intensa", "ecogénico", "ecogénica", "grafía", "plasia", "trofia", "megalia", "algia", "ectomía", "stomía",
                   "plastia", "emia", "uria", "oma", "omas", "cele", "lisis", "ptosis", "estenosis", "litiasis", "fibrosis")


def sin_tildes(s):
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def cargar():
    if not ENTRADA.exists():
        raise SystemExit(f"No encontré {ENTRADA}. Primero importa informes desde la lista de MultiRisWeb.")
    out = []
    for l in ENTRADA.read_text(encoding="utf-8").splitlines():
        try:
            out.append(json.loads(l))
        except json.JSONDecodeError:
            pass
    return out


def frases_de(texto):
    for f in re.split(r"(?<=\.)\s+|\n", texto):
        f = re.sub(r"\s+", " ", f).strip()
        if len(f) >= 12 and "[" not in f:      # sin datos anonimizados
            yield f


def nombre_corto(frase, usados):
    palabras = [w for w in re.findall(r"[a-záéíóúñü]+", frase.lower()) if w not in PALABRAS_COMUNES and len(w) > 2]
    base = sin_tildes(" ".join(palabras[:2]) or frase.lower()[:20])
    nombre, i = base, 2
    while nombre in usados:
        nombre, i = f"{base} {i}", i + 1
    usados.add(nombre)
    return nombre


def main():
    informes = cargar()
    n = len(informes)
    SALIDA.mkdir(exist_ok=True)

    # ---------------- vocabulario
    conteo, formas = collections.Counter(), {}
    for inf in informes:
        for texto in inf["secciones"].values():
            for m in re.finditer(r"[A-Za-zÁÉÍÓÚÑáéíóúñü][\wÁÉÍÓÚÑáéíóúñü-]*", texto):
                w = m.group(0)
                clave = w.lower()
                # al inicio de oración la mayúscula es por posición ("Vesícula ..."): no cuenta como forma propia
                if re.fullmatch(r"[A-ZÁÉÍÓÚÑ][a-záéíóúñü]+", w) and re.search(r"(^|[.:\n]\s*)$", texto[:m.start()][-3:] or ""):
                    w = clave
                if clave in PALABRAS_COMUNES or (len(w) < 7 and not re.fullmatch(r"[A-Z0-9-]{2,}", w)):
                    continue
                conteo[clave] += 1
                formas.setdefault(clave, collections.Counter())[w] += 1
    def puntaje(item):
        w, c = item
        bonus = 3 if w.endswith(SUFIJOS_MEDICOS) else 1
        bonus *= 2 if re.search(r"[A-Z0-9-]", formas[w].most_common(1)[0][0]) else 1
        return c * bonus
    vocab = [(formas[w].most_common(1)[0][0], c) for w, c in sorted(conteo.items(), key=puntaje, reverse=True) if c >= 3]
    (SALIDA / "vocabulario_sugerido.txt").write_text(
        "\n".join(f"{w}\t{c}" for w, c in vocab[:400]), encoding="utf-8")

    # actualizar la parte automática de vocabulario.txt
    ruta_v = BASE / "vocabulario.txt"
    actual = ruta_v.read_text(encoding="utf-8") if ruta_v.exists() else ""
    manual = actual.split(MARCA_AUTO)[0].rstrip()
    manuales = {l.strip().lower() for l in manual.splitlines() if l.strip() and not l.startswith("#")}
    auto = [w for w, _ in vocab if w.lower() not in manuales][:150]
    ruta_v.write_text(manual + "\n\n" + MARCA_AUTO + "\n" + "\n".join(auto) + "\n", encoding="utf-8")

    # ---------------- frases frecuentes por sección
    por_seccion = collections.defaultdict(collections.Counter)
    for inf in informes:
        for sec, texto in inf["secciones"].items():
            por_seccion[sec].update(frases_de(texto))
    minimo = max(5, n // 200)
    with open(SALIDA / "frases_frecuentes.txt", "w", encoding="utf-8") as f:
        for sec, c in por_seccion.items():
            f.write(f"===== {sec.upper()} =====\n")
            for frase, k in c.most_common(80):
                if k >= minimo:
                    f.write(f"{k:5d}  {frase}\n")
            f.write("\n")

    usados = set()
    frases = {nombre_corto(fr, usados): fr for fr, k in por_seccion["hallazgos"].most_common(60) if k >= max(10, n // 100)}
    (SALIDA / "frases_sugeridas.json").write_text(json.dumps({"frases": frases}, ensure_ascii=False, indent=2), encoding="utf-8")

    # ---------------- plantillas normales por tipo de estudio
    # Para cada tipo de estudio se arma la plantilla con las frases que repites en muchos de esos
    # informes (sin números ni datos), en el orden en que sueles escribirlas.
    def norm_titulo(t):
        t = sin_tildes(re.sub(r"\s+", " ", t or "").strip().lower())
        t = re.sub(r"[^a-z0-9]+", " ", t)          # "AP/LATERAL" -> "ap lateral" (no pegar palabras)
        return re.sub(r"\s+", " ", t).strip()

    grupos = collections.defaultdict(list)
    for inf in informes:
        grupos[norm_titulo(inf.get("titulo", ""))].append(inf)

    def frases_seccion(texto_sec):
        return [f for f in frases_de(texto_sec) if not re.search(r"\d|\[", f)]

    plantillas, legible = {}, []
    for titulo, lista in sorted(grupos.items(), key=lambda kv: -len(kv[1])):
        n_tipo = len(lista)
        if not titulo or n_tipo < 5:
            continue
        plantilla = {}
        for sec in ("tecnica", "hallazgos", "impresion"):
            df, pos, forma = collections.Counter(), collections.defaultdict(list), {}
            for inf in lista:
                frs = frases_seccion(inf["secciones"].get(sec, ""))
                vistas = set()
                for i, f in enumerate(frs):
                    k = txtmod.normalizar(f)
                    if k in vistas:
                        continue
                    vistas.add(k)
                    df[k] += 1
                    pos[k].append(i / max(1, len(frs) - 1))
                    forma.setdefault(k, collections.Counter())[f] += 1
            umbral = max(3, int(0.30 * n_tipo))
            elegidas = [k for k, c in df.items() if c >= umbral]
            if sec == "impresion" and elegidas:
                elegidas = [max(elegidas, key=lambda k: df[k])]      # una sola impresión "normal"
            elegidas.sort(key=lambda k: sum(pos[k]) / len(pos[k]))
            if elegidas:
                plantilla[sec] = ("\n" if sec == "hallazgos" else " ").join(forma[k].most_common(1)[0][0] for k in elegidas)
        if "hallazgos" in plantilla:
            nombre = titulo + " normal"
            plantillas[nombre] = {**plantilla, "_auto": n_tipo}
            legible.append(f"=== {nombre}  ({n_tipo} informes) ===\n" + "\n".join(f"[{k}]\n{v}" for k, v in plantilla.items()) + "\n")
        if len(plantillas) >= 40:
            break
    (SALIDA / "plantillas_sugeridas.json").write_text(json.dumps({"plantillas": plantillas}, ensure_ascii=False, indent=2), encoding="utf-8")
    (SALIDA / "plantillas_sugeridas.txt").write_text("\n".join(legible), encoding="utf-8")

    # agregar a plantillas.json las nuevas (no se tocan las que ya tienes; se guarda respaldo)
    ruta_p = BASE / "plantillas.json"
    actuales = json.loads(ruta_p.read_text(encoding="utf-8")) if ruta_p.exists() else {"plantillas": {}, "frases": {}}
    (SALIDA / "plantillas_respaldo.json").write_text(json.dumps(actuales, ensure_ascii=False, indent=2), encoding="utf-8")
    actuales.setdefault("plantillas", {})
    compacto = lambda k: re.sub(r"\s+", "", k)  # noqa: E731
    nuevas_compactas = {compacto(k) for k in plantillas}
    # se reemplazan las generadas automáticamente antes (y las de nombre con palabras pegadas);
    # las tuyas y las importadas del RIS no se tocan
    for k in list(actuales["plantillas"]):
        v = actuales["plantillas"][k]
        if isinstance(v, dict) and not v.get("_ris") and (v.get("_auto") or (compacto(k) in nuevas_compactas and k not in plantillas)):
            del actuales["plantillas"][k]
    for k, v in plantillas.items():
        if k not in actuales["plantillas"]:
            actuales["plantillas"][k] = v
    ruta_p.write_text(json.dumps(actuales, ensure_ascii=False, indent=2), encoding="utf-8")

    # ---------------- estilo: prompt_base con tus frases típicas
    ruta_c = BASE / "config.json"
    cfg = json.loads(ruta_c.read_text(encoding="utf-8"))
    tipicas = [fr for fr, _ in por_seccion["hallazgos"].most_common(3)] + [fr for fr, _ in por_seccion["impresion"].most_common(1)]
    if tipicas:
        cfg["prompt_base"] = ("Informe radiológico. " + " ".join(tipicas))[:350]
        ruta_c.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")

    # ---------------- resumen
    tipos = collections.Counter(t for t in (inf.get("titulo", "").lower() for inf in informes) if t)
    resumen = [f"Informes analizados: {n}", f"Términos de vocabulario detectados: {len(vocab)} ({len(auto)} agregados a vocabulario.txt)",
               f"Frases normales sugeridas: {len(frases)}", f"Plantillas sugeridas: {len(plantillas)}", "",
               "Estudios más frecuentes:"] + [f"  {c:5d}  {t}" for t, c in tipos.most_common(25)]
    (SALIDA / "resumen.txt").write_text("\n".join(resumen), encoding="utf-8")
    print("\n".join(resumen[:5]))
    if plantillas:
        print("\nPlantillas disponibles por voz (di «plantilla ...»):")
        for k in list(plantillas)[:25]:
            print(f"   plantilla {k}")
    print(f"\nResultados en: {SALIDA}")
    print("Las plantillas nuevas ya quedaron en plantillas.json (respaldo del anterior en perfil/plantillas_respaldo.json).")
    print("Para leerlas con calma: perfil/plantillas_sugeridas.txt")


if __name__ == "__main__":
    main()

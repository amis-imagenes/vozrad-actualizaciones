#!/bin/bash
# VozRad - actualiza ESTE computador desde el canal de actualizaciones (sin abrir el motor). Doble clic.
cd "$(dirname "$0")" || exit 1
if [ ! -x .venv/bin/python ]; then echo "Primero haz doble clic en instalar.command"; read -r -p "Enter para cerrar..." _; exit 1; fi
.venv/bin/python actualizador.py
echo
read -r -p "Presiona Enter para cerrar..." _

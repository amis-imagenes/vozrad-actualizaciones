#!/bin/bash
# VozRad - crea en el Escritorio el registro de lo dictado (para enviarlo a revisión). Doble clic.
cd "$(dirname "$0")" || exit 1
if [ ! -x .venv/bin/python ]; then echo "Primero haz doble clic en instalar.command"; read -r -p "Enter para cerrar..." _; exit 1; fi
.venv/bin/python registro.py
open ~/Desktop 2>/dev/null
echo
read -r -p "Presiona Enter para cerrar..." _

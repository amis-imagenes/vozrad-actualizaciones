@echo off
chcp 65001 >nul
title VozRad - precision y sugerencias
cd /d "%~dp0"
.venv\Scripts\python.exe aprendizaje.py
pause

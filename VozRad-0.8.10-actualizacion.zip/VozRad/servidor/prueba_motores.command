#!/bin/bash
# VozRad - comparar motores. Doble clic desde el Finder.
cd "$(dirname "$0")" || exit 1
printf '\033]0;VozRad - comparar motores\007'
if [ ! -x .venv/bin/python ]; then echo "Primero haz doble clic en instalar.command"; read -r -p "Enter para cerrar..." _; exit 1; fi
echo "Cierra la ventana de iniciar antes de continuar (para no competir por el procesador)."; read -r -p "Enter para seguir..." _
.venv/bin/python prueba_motores.py
read -r -p "Presiona Enter para cerrar..." _

#!/bin/bash
# VozRad - instalación en Mac (solo la primera vez). Doble clic desde el Finder.
cd "$(dirname "$0")" || exit 1
printf '\033]0;VozRad - instalación\007'
echo
echo "=== Instalando VozRad (solo la primera vez) ==="
echo

# Buscar Python 3.12 / 3.11 / 3.10 (el del sistema no sirve)
PY=""
for v in 3.12 3.11 3.10; do
  for c in "python$v" "/Library/Frameworks/Python.framework/Versions/$v/bin/python$v" \
           "/opt/homebrew/bin/python$v" "/usr/local/bin/python$v"; do
    if command -v "$c" >/dev/null 2>&1; then PY="$c"; break 2; fi
  done
done
if [ -z "$PY" ]; then
  echo "No encontré Python 3.12 (ni 3.11 / 3.10)."
  echo
  echo "1) Descárgalo de https://www.python.org/downloads/macos/"
  echo "   (elige «Python 3.12.x», «macOS 64-bit universal2 installer») e instálalo."
  echo "2) Luego vuelve a hacer doble clic en instalar.command"
  echo
  open "https://www.python.org/downloads/macos/" 2>/dev/null
  read -r -p "Presiona Enter para cerrar..." _
  exit 1
fi
echo "Usando: $PY ($("$PY" -V 2>&1))"
echo "Procesador: $(uname -m)  (arm64 = Apple M1/M2/M3/M4, x86_64 = Intel)"
echo

# Certificados de seguridad del Python de python.org (para poder descargar el modelo de voz)
[ -f "/Applications/Python ${PY##*python}/Install Certificates.command" ] && \
  "/Applications/Python ${PY##*python}/Install Certificates.command" >/dev/null 2>&1

"$PY" -m venv .venv || { echo "Error creando el entorno de Python"; read -r -p "Enter para cerrar..." _; exit 1; }
# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt || { echo; echo "Error instalando paquetes (revisa tu conexión a internet)."; read -r -p "Enter para cerrar..." _; exit 1; }

chmod +x ./*.command 2>/dev/null
echo
echo "Instalación lista. Ahora haz doble clic en iniciar.command"
echo "(la primera vez descargará el modelo de voz, ~1,6 GB)"
read -r -p "Presiona Enter para cerrar..." _

"""
VozRad - compara motores de reconocimiento con TUS frases grabadas (historial/audio).

Para cada frase muestra cuánto tardó cada motor y qué escribió, para que elijas
por velocidad y aciertos. Uso: prueba_motores.bat / .command  (con iniciar CERRADO, para no
competir por la tarjeta gráfica).
"""
import gc
import sys
import time
import wave
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import motores
import json as _json
from pathlib import Path as _P
try:
    H = _json.loads((_P(__file__).resolve().parent / "config.json").read_text(encoding="utf-8")).get("hilos_cpu")
except Exception:  # noqa: BLE001
    H = None
 # noqa: E402
import texto  # noqa: E402

AUDIO = BASE / "historial" / "audio"
SALIDA = BASE / "perfil" / "comparacion_motores.txt"
MAX_FRASES = 25


def leer_wav(p: Path) -> np.ndarray:
    with wave.open(str(p), "rb") as w:
        return np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0


def main():
    archivos = sorted(AUDIO.glob("*/*.wav"))[-MAX_FRASES:]
    if not archivos:
        print("No hay frases grabadas todavía. Dicta unas cuantas con VozRad 0.4 o superior y vuelve a ejecutar.")
        return
    audios = [(a, leer_wav(a)) for a in archivos]
    print(f"Comparando con {len(audios)} frases tuyas ({sum(len(x) for _, x in audios) / 16000:.0f} s de audio)\n")

    candidatos = [
        ("Parakeet v3 (procesador)", lambda: motores.MotorParakeet(H)),
        ("Canary 1B v2 (procesador)", lambda: motores.MotorCanary(H)),
        ("Híbrido Parakeet+Canary", lambda: motores.MotorHibrido(H)),
        ("Whisper large-v3-turbo (tarjeta)", lambda: motores.MotorWhisper("large-v3-turbo")),
        ("Whisper small (tarjeta)", lambda: motores.MotorWhisper("small")),
    ]
    resultados = {}
    for nombre, crear in candidatos:
        print(f"== Cargando {nombre} ...")
        try:
            m = crear()
        except Exception as e:  # noqa: BLE001
            print(f"   no disponible: {type(e).__name__}: {str(e)[:150]}\n")
            continue
        filas = []
        for archivo, pcm in audios:
            t0 = time.perf_counter()
            crudo = m.reconocer(pcm, prompt=texto.prompt_inicial(""), beam=1)
            ms = (time.perf_counter() - t0) * 1000
            final = texto.procesar(crudo).get("texto") or crudo
            filas.append((archivo.name, len(pcm) / 16000, ms, final))
            print(f"   {ms:6.0f} ms | {len(pcm) / 16000:4.1f} s | {final}")
        resultados[nombre] = filas
        prom = sum(f[2] for f in filas) / len(filas)
        print(f"   PROMEDIO: {prom:.0f} ms por frase\n")
        del m
        gc.collect()

    SALIDA.parent.mkdir(exist_ok=True)
    with open(SALIDA, "w", encoding="utf-8") as f:
        f.write("RESUMEN (promedio por frase)\n")
        for nombre, filas in resultados.items():
            f.write(f"  {nombre:36s} {sum(x[2] for x in filas) / len(filas):6.0f} ms\n")
        f.write("\nDETALLE POR FRASE\n")
        for i, (archivo, _) in enumerate(audios):
            f.write(f"\n[{archivo.name}]\n")
            for nombre, filas in resultados.items():
                f.write(f"  {nombre:36s} {filas[i][2]:6.0f} ms  {filas[i][3]}\n")
    print("=" * 70)
    print("RESUMEN (promedio por frase):")
    for nombre, filas in resultados.items():
        print(f"  {nombre:36s} {sum(x[2] for x in filas) / len(filas):6.0f} ms")
    print(f"\nDetalle guardado en: {SALIDA}")
    print('Para cambiar de motor: config.json -> "motor": "hibrido", "parakeet", "canary" o "whisper"')


if __name__ == "__main__":
    main()

@echo off
chcp 65001 >nul
title VozRad - registro de dictado
cd /d "%~dp0"
.venv\Scripts\python.exe registro.py
pause

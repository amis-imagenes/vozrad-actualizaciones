@echo off
chcp 65001 >nul
title VozRad - servidor de voz
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Primero ejecuta instalar.bat
  pause & exit /b 1
)
:motor
.venv\Scripts\python.exe servidor.py
if errorlevel 3 if not errorlevel 4 (
  echo.
  echo [VozRad] Reiniciando con la version nueva...
  goto motor
)
pause

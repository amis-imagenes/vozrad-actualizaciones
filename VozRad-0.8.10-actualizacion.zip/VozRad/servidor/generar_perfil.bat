@echo off
chcp 65001 >nul
title VozRad - aprender de tus informes
cd /d "%~dp0"
.venv\Scripts\python.exe generar_perfil.py
echo.
echo Listo. Los cambios se aplican desde el siguiente dictado.
pause

@echo off
chcp 65001 >nul
title VozRad - instalacion
cd /d "%~dp0"
echo.
echo === Instalando VozRad (solo la primera vez) ===
echo.
set PY=
where py >nul 2>nul && (py -3.12 -V >nul 2>nul && set PY=py -3.12)
if not defined PY (where py >nul 2>nul && (py -3.11 -V >nul 2>nul && set PY=py -3.11))
if not defined PY (where python >nul 2>nul && set PY=python)
if not defined PY (
  echo No encontre Python. Instala Python 3.12 desde https://www.python.org/downloads/
  echo y marca la casilla "Add python.exe to PATH". Luego vuelve a ejecutar este archivo.
  pause & exit /b 1
)
echo Usando: %PY%
%PY% -m venv .venv || (echo Error creando el entorno & pause & exit /b 1)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt || (echo Error instalando paquetes & pause & exit /b 1)
echo.
echo Instalacion lista. Ahora ejecuta iniciar.bat
echo (la primera vez descargara el modelo de voz, ~1,6 GB)
pause

"""
VozRad - usar la tarjeta gráfica NVIDIA para reconocer (Windows / Linux).

  python gpu.py activar      instala onnxruntime-gpu + librerías CUDA, prueba la tarjeta y deja
                             "dispositivo": "cuda" en config.json (si la prueba falla, no cambia nada)
  python gpu.py desactivar   vuelve al procesador
  python gpu.py estado       muestra qué está instalado
"""
import json
import subprocess
import sys
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent
CFG = BASE / "config.json"
PAQUETES_GPU = ["onnxruntime-gpu>=1.20", "nvidia-cuda-runtime-cu12", "nvidia-cublas-cu12", "nvidia-cudnn-cu12==9.*",
                "nvidia-cufft-cu12", "nvidia-curand-cu12", "nvidia-cuda-nvrtc-cu12"]


def pip(*args):
    return subprocess.run([sys.executable, "-m", "pip", *args], check=False).returncode


def instalado(nombre):
    from importlib import metadata
    try:
        return metadata.version(nombre)
    except metadata.PackageNotFoundError:
        return None


def leer_cfg():
    try:
        return json.loads(CFG.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def guardar_cfg(cfg):
    CFG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def asegurar_gpu():
    """Deja onnxruntime-gpu como único onnxruntime (el normal y el de GPU no pueden convivir).
    Lo llama también el actualizador si config.json dice "dispositivo": "cuda"."""
    if instalado("onnxruntime"):
        # comparten la carpeta onnxruntime/: al quitar el normal se rompe el de GPU, hay que reinstalarlo
        pip("uninstall", "-y", "-q", "onnxruntime", "onnxruntime-gpu")
    if not instalado("onnxruntime-gpu"):
        pip("install", "-q", *PAQUETES_GPU)
    else:
        pip("install", "-q", *PAQUETES_GPU[1:])


def probar():
    """Carga Parakeet en la tarjeta y reconoce 3 s de silencio + un tono: devuelve (ok, detalle)."""
    import numpy as np
    sys.path.insert(0, str(BASE))
    import motores
    try:
        import onnxruntime as ort
        if hasattr(ort, "preload_dlls"):
            ort.preload_dlls()
        prov = ort.get_available_providers()
        if "CUDAExecutionProvider" not in prov:
            return False, f"onnxruntime no ve la tarjeta (proveedores: {prov})"
        t0 = time.perf_counter()
        m = motores.MotorParakeet(None, "cuda")
        carga = time.perf_counter() - t0
        if "cuda" not in str(getattr(m, "descripcion", "")):
            return False, f"Parakeet se cargó en el procesador ({getattr(m, 'descripcion', '')}), no en la tarjeta"
        x = (0.05 * np.sin(np.linspace(0, 3 * 440 * 2 * np.pi, 48000))).astype(np.float32)
        m.reconocer(x)                       # la primera vez prepara la tarjeta
        t1 = time.perf_counter()
        for _ in range(3):
            m.reconocer(x)
        ms = (time.perf_counter() - t1) / 3 * 1000
        return True, f"modelo cargado en {carga:.0f} s · {ms:.0f} ms por frase de 3 s"
    except Exception as e:  # noqa: BLE001
        return False, str(e)[:300]


def main():
    accion = sys.argv[1] if len(sys.argv) > 1 else "estado"
    if accion == "estado":
        print("onnxruntime:", instalado("onnxruntime"), "· onnxruntime-gpu:", instalado("onnxruntime-gpu"),
              "· dispositivo en config:", leer_cfg().get("dispositivo", "cpu"))
        return 0
    if accion == "desactivar":
        cfg = leer_cfg(); cfg["dispositivo"] = "cpu"; guardar_cfg(cfg)
        if instalado("onnxruntime-gpu"):
            pip("uninstall", "-y", "-q", "onnxruntime-gpu")
        pip("install", "-q", "onnxruntime>=1.18")
        print("[VozRad] Listo: VozRad vuelve a reconocer con el procesador.")
        return 0
    print("[VozRad] Instalando el soporte para la tarjeta gráfica (~2 GB, 5-15 minutos)...")
    asegurar_gpu()
    print("[VozRad] Probando la tarjeta (la primera vez descarga el modelo completo, ~2,5 GB)...")
    ok, detalle = probar()
    if not ok:
        print(f"[VozRad] La tarjeta no funcionó: {detalle}")
        print("[VozRad] No cambié nada: VozRad sigue con el procesador. Envía este mensaje a Álvaro/Claude.")
        return 1
    cfg = leer_cfg(); cfg["dispositivo"] = "cuda"; guardar_cfg(cfg)
    print(f"[VozRad] Tarjeta OK: {detalle}")
    print("[VozRad] Listo. Cierra la ventana del motor y vuelve a abrir iniciar (debe decir «Listo: cuda/...»).")
    return 0


if __name__ == "__main__":
    sys.exit(main())

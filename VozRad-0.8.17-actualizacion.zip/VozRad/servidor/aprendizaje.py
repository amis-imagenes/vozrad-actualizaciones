"""
VozRad - aprendizaje a partir de tus correcciones y medición de precisión.

Fuente: historial/correcciones_manuales.jsonl  (la extensión guarda, al Guardar/Informar,
lo que VozRad escribió y cómo quedó el campo después de que lo corregiste).

  sugerencias()   -> cambios que haces una y otra vez ("hipo denso" -> "hipodenso")
  estadisticas()  -> % de palabras dictadas que tuviste que corregir, por día
"""
import collections
import difflib
import json
import re
from pathlib import Path

import texto

BASE = Path(__file__).resolve().parent
HIST = BASE / "historial"
ARCH_CORR = HIST / "correcciones_manuales.jsonl"
ARCH_RECH = HIST / "sugerencias_rechazadas.json"


def _palabras(t: str):
    return re.findall(r"[\wÁÉÍÓÚÑáéíóúñü/%-]+|[.,;:()]", t or "")


def _norm(w: str) -> str:
    return texto.normalizar(w) or w


def _registros():
    if not ARCH_CORR.exists():
        return []
    out = []
    for l in ARCH_CORR.read_text(encoding="utf-8").splitlines():
        try:
            out.append(json.loads(l))
        except json.JSONDecodeError:
            pass
    return out


def comparar(dictado: str, final_campo: str):
    """
    Busca en el texto final del campo el trozo que corresponde a la frase dictada y devuelve
    (palabras_dictadas, palabras_cambiadas, [(de, a), ...]).  None si la frase ya no está (la borraste).
    """
    d = _palabras(dictado)
    f = _palabras(final_campo)
    dn, fn = [_norm(w) for w in d], [_norm(w) for w in f]
    if not d or not f:
        return None
    sm = difflib.SequenceMatcher(None, dn, fn, autojunk=False)
    bloques = [b for b in sm.get_matching_blocks() if b.size]
    if not bloques or sum(b.size for b in bloques) / len(d) < 0.5:
        return None
    ini = max(0, bloques[0].b - bloques[0].a)
    fin = min(len(f), bloques[-1].b + bloques[-1].size + (len(d) - bloques[-1].a - bloques[-1].size))
    fseg, fsegn = f[ini:fin], fn[ini:fin]
    sm2 = difflib.SequenceMatcher(None, dn, fsegn, autojunk=False)
    cambiadas, pares = 0, []
    for op, i1, i2, j1, j2 in sm2.get_opcodes():
        if op == "equal":
            continue
        cambiadas += max(i2 - i1, j2 - j1)
        if op == "replace" and (i2 - i1) <= 3 and (j2 - j1) <= 3:
            de = " ".join(d[i1:i2])
            a = " ".join(fseg[j1:j2])
            if re.search(r"\w", de) and re.search(r"\w", a) and _norm(de) != _norm(a):
                pares.append((de, a))
    return len(d), cambiadas, pares


def _rechazadas():
    try:
        return set(tuple(x) for x in json.loads(ARCH_RECH.read_text(encoding="utf-8")))
    except Exception:  # noqa: BLE001
        return set()


def sugerencias(minimo: int = 2):
    conteo = collections.Counter()
    ejemplo = {}
    for r in _registros():
        final = r.get("final", {})
        for it in r.get("dictado", []):
            res = comparar(it.get("texto", ""), final.get(it.get("campo"), ""))
            if not res:
                continue
            for de, a in res[2]:
                clave = (de.lower(), a)
                conteo[clave] += 1
                ejemplo.setdefault(clave, it.get("texto", "")[:120])
    ya = {k.lower() for k in texto.CORRECCIONES.datos().get("palabras", {})}
    rech = _rechazadas()
    out = [{"de": de, "a": a, "veces": n, "ejemplo": ejemplo[(de, a)]}
           for (de, a), n in conteo.most_common() if n >= minimo and de not in ya and (de, a) not in rech]
    return out[:50]


def _todas_las_correcciones():
    """Todas las correcciones observadas (aunque sea una vez): {(de, a): veces}."""
    conteo, ejemplo = collections.Counter(), {}
    for r in _registros():
        final = r.get("final", {})
        for it in r.get("dictado", []):
            res = comparar(it.get("texto", ""), final.get(it.get("campo"), ""))
            if not res:
                continue
            for de, a in res[2]:
                clave = (de.lower(), a)
                conteo[clave] += 1
                ejemplo.setdefault(clave, it.get("texto", "")[:120])
    return conteo, ejemplo


def _palabra_de_mas(nd: str, na: str) -> bool:
    """True si la corrección trae una palabra de más al inicio o al final que no se dictó
    («tobill» -> «del tobillo», «pseudo nodular» -> «pseudonodular descrita»)."""
    pa = na.split()
    if len(pa) < 2:
        return False
    junta = lambda x: x.replace(" ", "")  # noqa: E731
    r = difflib.SequenceMatcher(None, junta(nd), junta(na)).ratio()
    for resto in (pa[1:], pa[:-1]):
        if difflib.SequenceMatcher(None, junta(nd), "".join(resto)).ratio() >= r + 0.12:
            return True
    return False


def auto_aprender(veces_para_aprender: int = 2):
    """
    Aprende sola las correcciones que haces:
      - palabra que NO existe en español corregida por otra parecida -> a la primera
      - cualquier otra corrección parecida (plural, palabra cercana)  -> cuando la repites N veces
    Cambios de contenido (p.ej. derecho -> izquierdo) nunca se aprenden solos.
    """
    conteo, ejemplo = _todas_las_correcciones()
    ya = {k.lower() for k in texto.CORRECCIONES.datos().get("palabras", {})}
    rech = _rechazadas()
    texto._cargar_vocabulario()
    aprendidas = []
    for (de, a), n in conteo.items():
        if de in ya or (de, a) in rech or len(de) < 3:
            continue
        nd, na = _norm(de), _norm(a)
        parecidas = difflib.SequenceMatcher(None, nd, na).ratio() >= 0.55
        if not parecidas:
            continue
        if re.search(r"\d", de + a) or nd in texto._U or na in texto._U:
            continue                  # números y niveles («L1-L2» -> «L1», «1» -> «un»): dependen de la frase
        if _palabra_de_mas(nd, na):
            continue                  # «pseudo nodular» -> «pseudonodular descrita»: se pegó una palabra vecina
        una = len(de.split()) == 1
        real = (texto._frecuencia_es(de) > 1.0) or (nd in texto._VOC["por_norm"]) or not una
        flexion = una and texto._solo_flexion(nd, na)
        if real and flexion:
            continue
        if una and real:
            try:
                import contexto
                if contexto.MODELO.uni.get(nd.replace(" ", ""), 0) >= 20:
                    continue          # «uterino» es palabra tuya (cérvix uterino): no se cambia en todas partes
            except Exception:  # noqa: BLE001
                pass                  # signo/signos, anexo/anexos: depende de la frase, nunca como regla general
        pegada = nd.replace(" ", "")
        if una and len(pegada) > len(na.replace(" ", "")) + 2 and " " not in na and \
                (pegada.endswith(na.replace(" ", "")[-5:]) or pegada.startswith(na.replace(" ", "")[:5])):
            continue                  # «levediscopatía» -> «discopatía»: se vio solo media palabra pegada
        if (not real and not flexion) or n >= veces_para_aprender:
            aceptar(de, a)
            aprendidas.append({"de": de, "a": a, "veces": n, "ejemplo": ejemplo.get((de, a), "")})
            ya.add(de)
    if aprendidas:
        HIST.mkdir(exist_ok=True)
        with open(HIST / "aprendido.jsonl", "a", encoding="utf-8") as f:
            for x in aprendidas:
                f.write(json.dumps(x, ensure_ascii=False) + "\n")
    return aprendidas


def deshacer(de: str, a: str):
    """Quita una corrección aprendida y no la vuelve a aprender."""
    ruta = texto.CORRECCIONES.ruta
    datos = json.loads(ruta.read_text(encoding="utf-8"))
    datos.get("palabras", {}).pop(de.lower(), None)
    ruta.write_text(json.dumps(datos, ensure_ascii=False, indent=2), encoding="utf-8")
    rechazar(de, a)


def _forma(a: str) -> str:
    """«Tubo» corregido al inicio de una oración se guarda «tubo» (salvo nombres propios y siglas)."""
    if len(a) > 1 and a[0].isupper() and a[1:2].islower():
        try:
            propias = texto._palabras_con_mayuscula()
        except Exception:  # noqa: BLE001
            propias = set()
        if a.split()[0].lower() not in propias:
            return a[0].lower() + a[1:]
    return a


def aceptar(de: str, a: str):
    a = _forma(re.sub(r"[\s.,;:]+$", "", a).strip())           # «bronquiectasias .» -> «bronquiectasias»
    ruta = texto.CORRECCIONES.ruta
    datos = json.loads(ruta.read_text(encoding="utf-8"))
    datos.setdefault("palabras", {})[de.lower()] = a
    ruta.write_text(json.dumps(datos, ensure_ascii=False, indent=2), encoding="utf-8")


def rechazar(de: str, a: str):
    HIST.mkdir(exist_ok=True)
    rech = _rechazadas()
    rech.add((de.lower(), a))
    ARCH_RECH.write_text(json.dumps(sorted(rech), ensure_ascii=False), encoding="utf-8")


def estadisticas():
    """Tasa de corrección por día: palabras que cambiaste / palabras que VozRad escribió."""
    dias = collections.defaultdict(lambda: [0, 0, 0])  # palabras, cambiadas, frases
    for r in _registros():
        dia = r.get("hora", "")[:10]
        final = r.get("final", {})
        for it in r.get("dictado", []):
            res = comparar(it.get("texto", ""), final.get(it.get("campo"), ""))
            if not res:
                continue
            dias[dia][0] += res[0]
            dias[dia][1] += res[1]
            dias[dia][2] += 1
    filas = [{"dia": d, "palabras": p, "corregidas": c, "frases": n,
              "tasa_correccion": round(100 * c / p, 1) if p else 0.0}
             for d, (p, c, n) in sorted(dias.items())]
    tot_p = sum(f["palabras"] for f in filas)
    tot_c = sum(f["corregidas"] for f in filas)
    return {"dias": filas, "total": {"palabras": tot_p, "corregidas": tot_c,
                                     "tasa_correccion": round(100 * tot_c / tot_p, 1) if tot_p else 0.0,
                                     "precision": round(100 - 100 * tot_c / tot_p, 1) if tot_p else None}}


if __name__ == "__main__":
    e = estadisticas()
    print("Día         Frases  Palabras  Corregidas  Precisión")
    for f in e["dias"]:
        print(f"{f['dia']}  {f['frases']:6d}  {f['palabras']:8d}  {f['corregidas']:10d}  {100 - f['tasa_correccion']:8.1f} %")
    t = e["total"]
    if t["palabras"]:
        print(f"\nTOTAL: {t['palabras']} palabras, precisión {t['precision']} % (corregiste {t['tasa_correccion']} %)")
    s = sugerencias()
    if s:
        print("\nCorrecciones que repites (puedes aceptarlas desde el panel):")
        for x in s[:20]:
            print(f"  {x['veces']:3d}x  «{x['de']}» -> «{x['a']}»")

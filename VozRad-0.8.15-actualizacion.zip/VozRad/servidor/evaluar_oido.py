"""
VozRad - mide si la predicción por contexto (y antes el «oído radiológico») mejora el reconocimiento CON TUS DICTADOS.

Toma las frases que dictaste y que después quedaron en un informe guardado (historial/correcciones_manuales
+ los audios de historial/audio), las vuelve a reconocer:
  - como hoy (sin modelo de lenguaje)
  - con el modelo de lenguaje, probando varias intensidades
y compara cada resultado con cómo quedó el informe final. Imprime el % de palabras erradas de cada forma
y guarda el detalle en el Escritorio (VozRad-evaluacion-prediccion.txt) para enviarlo a revisión.

No cambia nada de tu configuración.
"""
import datetime as dt
import difflib
import json
import re
import sys
import time
import unicodedata
import wave
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
HIST = BASE / "historial"
MAX_FRASES = 300
CONFIGS = [(0.3, 0.5), (0.3, 1.5), (0.6, 0.5), (0.6, 1.5), (1.0, 0.5), (1.0, 1.5)]   # (alfa, beta)


def norm_palabras(t: str):
    t = "".join(c for c in unicodedata.normalize("NFD", (t or "").lower()) if unicodedata.category(c) != "Mn")
    return re.findall(r"[a-zñ]+|\d+(?:,\d+)?", t)


def distancia(a, b):
    d = list(range(len(b) + 1))
    for i, x in enumerate(a, 1):
        prev, d[0] = d[0], i
        for j, y in enumerate(b, 1):
            prev, d[j] = d[j], min(d[j] + 1, d[j - 1] + 1, prev + (x != y))
    return d[len(b)]


def referencia(dictado: str, final: str):
    """Trozo del informe final que corresponde a la frase dictada (o None si ya no está)."""
    d, f = norm_palabras(dictado), norm_palabras(final)
    if len(d) < 3 or not f:
        return None
    sm = difflib.SequenceMatcher(None, d, f, autojunk=False)
    bloques = [b for b in sm.get_matching_blocks() if b.size]
    if not bloques or sum(b.size for b in bloques) / len(d) < 0.5:
        return None
    ini = max(0, bloques[0].b - bloques[0].a)
    fin = min(len(f), bloques[-1].b + bloques[-1].size + (len(d) - bloques[-1].a - bloques[-1].size))
    ref = f[ini:fin]
    if not (0.6 * len(d) <= len(ref) <= 1.6 * len(d)) or difflib.SequenceMatcher(None, d, ref).ratio() < 0.6:
        return None
    return ref


def muestras():
    audios = {}
    for arch in sorted(HIST.glob("20??-??-??.jsonl")):
        for l in arch.read_text(encoding="utf-8", errors="ignore").splitlines():
            try:
                r = json.loads(l)
            except json.JSONDecodeError:
                continue
            if r.get("audio") and r.get("crudo") and not r.get("respaldo"):
                audios[r["crudo"].strip()] = r
    out, vistos = [], set()
    ruta = HIST / "correcciones_manuales.jsonl"
    if not ruta.exists():
        return []
    for l in reversed(ruta.read_text(encoding="utf-8", errors="ignore").splitlines()):
        try:
            r = json.loads(l)
        except json.JSONDecodeError:
            continue
        for it in r.get("dictado", []):
            crudo = (it.get("crudo") or "").strip()
            if not crudo or crudo in vistos or crudo not in audios:
                continue
            ref = referencia(it.get("texto", ""), (r.get("final") or {}).get(it.get("campo"), "") or "")
            wav = HIST / audios[crudo]["audio"]
            if ref and wav.exists():
                vistos.add(crudo)
                out.append({"crudo": crudo, "ref": ref, "wav": wav, "seg": audios[crudo].get("segundos_audio", 0)})
        if len(out) >= MAX_FRASES:
            break
    return out[:MAX_FRASES]


def leer_wav(ruta: Path):
    with wave.open(str(ruta)) as w:
        x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
    return x


UMBRALES = [-0.5, -1.0, -2.0]


def main():
    import motores
    import texto
    import lenguaje
    import prediccion
    cfg = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
    print("[VozRad] Buscando frases dictadas que quedaron en informes guardados...", flush=True)
    M = muestras()
    if len(M) < 20:
        print(f"Solo encontré {len(M)} frases con audio y su informe final. Dicta y guarda más informes en ESTE equipo (el que hace de motor) y vuelve a probar.")
        return
    print(f"[VozRad] {len(M)} frases. Armando el modelo de lenguaje con tus informes (sin las respuestas de la prueba)...", flush=True)
    prueba = BASE / "perfil" / "lenguaje-prueba.json.gz"
    lenguaje.construir(prueba, incluir_correcciones=False)
    lenguaje.MODELO.cargar(prueba)
    print("[VozRad] Cargando Parakeet...", flush=True)
    hilos = cfg.get("hilos_cpu") if isinstance(cfg.get("hilos_cpu"), int) else cfg.get("hilos_cpu_medidos")
    motor = motores.MotorParakeet(hilos if isinstance(hilos, int) else None, cfg.get("dispositivo", "cpu"))
    ts = motor.modelo.with_timestamps()
    nombres = ["actual"] + [f"predicción si duda < {u}" for u in UMBRALES]
    errores = {n: 0 for n in nombres}
    cambiadas = {n: 0 for n in nombres}
    total_ref = 0
    detalle = []
    for i, m in enumerate(M, 1):
        x = motores.preparar(leer_wav(m["wav"]))
        ref = m["ref"]
        total_ref += len(ref)
        r = ts.recognize(x, sample_rate=16000)
        base_txt = (r.text or "").strip()
        conf = motores.confianza_por_palabra(base_txt, list(r.tokens or []), list(r.logprobs or []))
        fila = {"ref": " ".join(ref), "conf": conf, "oido": base_txt}
        for nombre, u in zip(nombres, [None] + UMBRALES):
            txt, cambios = (base_txt, [])
            if u is not None and conf:
                txt, cambios = prediccion.predecir(base_txt, conf, umbral_conf=u)
            res = texto._procesar(txt, m["seg"])
            hyp = norm_palabras(res.get("texto", "") if res.get("tipo") == "texto" else "")
            e = distancia(hyp, ref)
            errores[nombre] += e
            cambiadas[nombre] += len(cambios)
            fila[nombre] = (e, " ".join(hyp), cambios)
        detalle.append(fila)
        if i % 25 == 0:
            print(f"  {i}/{len(M)}  " + "  ".join(f"{n}: {100 * errores[n] / max(1, total_ref):.2f}%" for n in nombres), flush=True)

    lineas = [f"# VozRad · evaluación de la predicción por contexto · {dt.datetime.now():%Y-%m-%d %H:%M} · {len(M)} frases, {total_ref} palabras", ""]
    for n in nombres:
        lineas.append(f"{n:26} palabras erradas: {100 * errores[n] / max(1, total_ref):5.2f}%   ({errores[n]})   palabras cambiadas: {cambiadas[n]}")
    mejor = min(nombres[1:], key=lambda n: errores[n])
    lineas += ["", f"Mejor: {mejor}", "", "== Frases donde la predicción cambia algo (umbral -2.0, el más amplio) ==", ""]
    ancho = nombres[-1]
    for f in detalle:
        e0, h0, _ = f["actual"]
        e1, h1, cambios = f[ancho]
        if cambios:
            signo = "✓" if e1 < e0 else ("✗" if e1 > e0 else "=")
            lineas += [f"{signo} {', '.join(f'{a}→{b}' for a, b in cambios)}", f"   informe: {f['ref']}", f"   actual : {h0}", f"   predic.: {h1}", ""]
    lineas += ["", "== Confianza del motor en palabras que quedaron mal (para calibrar) ==", ""]
    for f in detalle:
        e0, h0, _ = f["actual"]
        if e0 and f["conf"]:
            pares = " ".join(f"{w}({c:.1f})" for w, c in zip(f["oido"].split(), f["conf"]))
            lineas += [f"   informe: {f['ref']}", f"   motor  : {pares}", ""]
    informe = "\n".join(lineas)
    print("\n" + "\n".join(lineas[:len(nombres) + 4]))
    escritorio = next((p for p in (Path.home() / "Desktop", Path.home() / "Escritorio") if p.exists()), BASE)
    destino = escritorio / "VozRad-evaluacion-prediccion.txt"
    destino.write_text(informe, encoding="utf-8")
    print(f"\n[VozRad] Detalle guardado en {destino}. Arrástralo al chat.")


if __name__ == "__main__":
    main()

"""
VozRad - reconocimiento «con oído radiológico».

En vez de quedarse con la primera opción que el motor (Parakeet) cree oír, se mantienen varias opciones
a la vez (búsqueda en haz) y cada palabra completa suma puntos según el modelo de lenguaje radiológico
(lenguaje.py). Así, entre dos opciones que suenan parecido gana la que es propia de un informe.

  puntaje = lo que dice el oído del motor + alfa * modelo de lenguaje + beta * nº de palabras

Usa las piezas internas de onnx-asr (encoder y decoder_joint de Parakeet TDT). Si algo no calza (otra
versión de onnx-asr), se devuelve None y el motor sigue con su forma normal de reconocer.
"""
import math

import numpy as np

import lenguaje


def _log_softmax(x):
    m = float(np.max(x))
    e = np.exp(x - m)
    return x - m - math.log(float(np.sum(e)))


class _Hipotesis:
    __slots__ = ("tokens", "tiempos", "estado", "t", "emitidos", "ac", "lm", "palabras", "actual", "n")

    def __init__(self, estado):
        self.tokens, self.tiempos, self.estado = [], [], estado
        self.t, self.emitidos = 0, 0
        self.ac, self.lm = 0.0, 0.0
        self.palabras, self.actual, self.n = [], "", 0

    def copia(self):
        h = _Hipotesis(self.estado)
        h.tokens, h.tiempos = list(self.tokens), list(self.tiempos)
        h.t, h.emitidos, h.ac, h.lm = self.t, self.emitidos, self.ac, self.lm
        h.palabras, h.actual, h.n = list(self.palabras), self.actual, self.n
        return h


def _cerrar_palabra(h, lm):
    """Termina la palabra en curso: suma su puntaje del modelo de lenguaje."""
    w = lenguaje.normalizar(h.actual) if h.actual else None
    h.actual = ""
    if w:
        h.lm += lm.logp(w, h.palabras[-2:])
        h.palabras.append(w)
        h.n += 1


def encodificar(asr, x: np.ndarray):
    ondas = x[None, :].astype(np.float32)
    largos = np.array([x.size], dtype=np.int64)
    enc, enc_lens = asr._encode(*asr._preprocessor(ondas, largos))
    return enc[0], int(enc_lens[0])


def buscar(asr, enc, largo: int, lm, haz: int = 4, ramas: int = 4, alfa: float = 0.5, beta: float = 1.0,
           poda: float = 8.0):
    """Búsqueda en haz para TDT. Devuelve (tokens, tiempos) de la mejor hipótesis."""
    blank = asr._blank_idx
    vocab = asr._vocab
    max_por_paso = getattr(asr, "_max_tokens_per_step", 10)
    total = lambda h: h.ac + alfa * h.lm + beta * h.n  # noqa: E731
    vivas = [_Hipotesis(asr._create_state())]
    terminadas = []
    pasos = 0
    while vivas and pasos < 6 * largo + 50:
        pasos += 1
        nuevas = []
        for h in vivas:
            logits, paso, estado = asr._decode(h.tokens, h.estado, enc[h.t])
            lp = _log_softmax(np.asarray(logits, dtype=np.float32))
            orden = np.argpartition(-lp, min(ramas, lp.size - 1))[:ramas]
            candidatos = set(int(i) for i in orden) | {blank}
            mejor = float(lp.max())
            for k in candidatos:
                if lp[k] < mejor - poda:
                    continue
                n = h.copia()
                n.ac += float(lp[k])
                if k == blank:
                    n.t += paso if paso > 0 else 1
                    n.emitidos = 0
                else:
                    n.tokens.append(k)
                    n.tiempos.append(h.t)
                    n.estado = estado
                    tok = vocab.get(k, "")
                    if tok.startswith(" "):
                        _cerrar_palabra(n, lm)
                        n.actual = tok[1:]
                    else:
                        n.actual += tok
                    n.emitidos += 1
                    if paso > 0:
                        n.t += paso
                        n.emitidos = 0
                    elif n.emitidos >= max_por_paso:
                        n.t += 1
                        n.emitidos = 0
                (terminadas if n.t >= largo else nuevas).append(n)
        # una sola hipótesis por secuencia de tokens (la de mejor puntaje)
        unicas = {}
        for n in nuevas:
            clave = (tuple(n.tokens), n.t)
            if clave not in unicas or total(n) > total(unicas[clave]):
                unicas[clave] = n
        vivas = sorted(unicas.values(), key=total, reverse=True)[:haz]
        if terminadas and vivas:
            # si ya hay terminadas mucho mejores que todas las vivas, no vale la pena seguir
            mejor_term = max(total(x) for x in terminadas)
            vivas = [v for v in vivas if total(v) > mejor_term - 2 * poda]
    for h in terminadas:
        _cerrar_palabra(h, lm)
    if not terminadas:
        return None
    mejor = max(terminadas, key=total)
    return mejor.tokens, mejor.tiempos


def reconocer(adaptador, x: np.ndarray, lm=None, **opciones):
    """Texto, tokens y tiempos (en segundos) usando el modelo de lenguaje. None si no se puede."""
    lm = lm or lenguaje.MODELO
    if not lm.listo:
        return None
    asr = getattr(adaptador, "asr", None)
    if asr is None or not all(hasattr(asr, a) for a in ("_encode", "_preprocessor", "_decode", "_create_state", "_vocab", "_blank_idx")):
        return None
    enc, largo = encodificar(asr, x)
    r = buscar(asr, enc, largo, lm, **opciones)
    if r is None:
        return None
    tokens, tiempos = r
    res = asr._decode_tokens(tokens, tiempos, None)
    return res.text, list(res.tokens or []), list(res.timestamps or [])

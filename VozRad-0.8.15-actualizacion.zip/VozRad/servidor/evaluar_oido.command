#!/bin/bash
# VozRad - mide si el «oído radiológico» mejora el reconocimiento con tus propios dictados. Doble clic.
cd "$(dirname "$0")" || exit 1
if [ ! -x .venv/bin/python ]; then echo "Primero haz doble clic en instalar.command"; read -r -p "Enter para cerrar..." _; exit 1; fi
echo "Puede quedar abierto iniciar_en_red (no se usa). Tarda 5-15 minutos."
caffeinate -i .venv/bin/python evaluar_oido.py
open ~/Desktop 2>/dev/null
echo
read -r -p "Presiona Enter para cerrar..." _

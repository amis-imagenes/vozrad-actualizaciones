"""
VozRad - lectura de los PDF de informes de MultiRisWeb.

Formato del PDF (observado): encabezado con RUT / Paciente / Edad / fechas, luego el
título del estudio, luego secciones con títulos "Antecedentes:", "Técnica:",
"Hallazgos:", "Impresión:", y al pie de cada hoja "Página n de m ...".

Se guarda SOLO: título del estudio + texto de cada sección, con RUT, fechas y nombres
reemplazados. El encabezado y los pies de página se descartan.
"""
import io
import json
import re
from pathlib import Path

BASE = Path(__file__).resolve().parent
CARPETA = BASE / "informes"
ARCHIVO = CARPETA / "informes.jsonl"

SECCIONES = [
    ("tecnica", r"t[ée]cnica(?: de examen| del examen| utilizada)?"),
    ("antecedentes", r"antecedentes(?: cl[ií]nicos)?|indicaci[óo]n(?:es)?(?: cl[ií]nica)?|motivo(?: del examen)?|diagn[óo]stico de ingreso"),
    ("hallazgos", r"hallazgos?|descripci[óo]n|informe"),
    ("impresion", r"impresi[óo]n(?: diagn[óo]stica)?|conclusi[óo]n(?:es)?|diagn[óo]stico|comentarios?|sugerencias?|recomendaci[óo]n(?:es)?"),
]
RE_TITULO_SECCION = re.compile(r"^\s*(" + "|".join(p for _, p in SECCIONES) + r")\s*:\s*(.*)$", re.I)
RE_PIE = re.compile(r"^\s*p[áa]gina\s+\d+\s+de\s+\d+", re.I)
RE_FIRMA = re.compile(r"^\s*(dra?\.?\s|doctora?\s|m[ée]dico\b|radi[óo]log|firma|validado|r\.?c\.?m\.?|rut\b)", re.I)
RE_ENCABEZADO = re.compile(r"^\s*(rut|paciente|nombre|edad|sexo|fecha|n[°º]|acceso|procedencia|m[ée]dico solicitante|solicitante|instituci[óo]n|prevision|previsi[óo]n)\b[^:]{0,25}:", re.I)


def clave_seccion(titulo: str) -> str:
    for clave, patron in SECCIONES:
        if re.fullmatch(patron, titulo.strip(), flags=re.I):
            return clave
    return "otros"


def anonimizar(t: str) -> str:
    t = re.sub(r"\b\d{1,2}\.?\d{3}\.?\d{3}\s*-\s*[\dkK]\b", "[RUT]", t)
    t = re.sub(r"\b\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}\b", "[FECHA]", t)
    t = re.sub(r"\b\d{1,2}:\d{2}(:\d{2})?\s*(hrs?\.?|h)?\b", "[HORA]", t)
    t = re.sub(r"\b(Sr|Sra|Srta|Don|Doña|paciente)\.?\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+){0,3}", r"\1 [NOMBRE]", t)
    t = re.sub(r"\b[\w.+-]+@[\w-]+\.[\w.]+\b", "[CORREO]", t)
    try:
        import texto
        t = texto.limpiar_informe(t)            # nombre del paciente, médico, OT, pie del PDF
    except Exception:  # noqa: BLE001
        pass
    t = re.sub(r"\+?56\s?9\s?\d{4}\s?\d{4}\b", "[TELEFONO]", t)
    return t


def unir_lineas(lineas: list[str]) -> str:
    """El PDF corta las frases por el ancho de la hoja; aquí se rearman los párrafos."""
    parrafos, actual = [], ""
    for l in lineas:
        l = l.strip()
        if not l:
            if actual:
                parrafos.append(actual); actual = ""
            continue
        if actual and not re.search(r"[.:;]$", actual) and not re.match(r"^[-•*·]|\d+[.)]\s", l):
            actual += ("" if actual.endswith("-") else " ") + l
        else:
            if actual:
                parrafos.append(actual)
            actual = l
    if actual:
        parrafos.append(actual)
    return "\n".join(p.strip() for p in parrafos if p.strip())


def parsear(texto: str) -> dict | None:
    lineas = [l.rstrip() for l in texto.replace("\r", "").split("\n")]
    lineas = [l for l in lineas if not RE_PIE.match(l)]
    inicio = next((i for i, l in enumerate(lineas) if RE_TITULO_SECCION.match(l)), None)
    if inicio is None:
        return None

    # título del estudio: última línea con texto antes de la primera sección que no sea encabezado
    titulo = ""
    for l in reversed(lineas[:inicio]):
        if l.strip() and not RE_ENCABEZADO.match(l) and ":" not in l and re.search(r"[A-Za-zÁÉÍÓÚÑ]{3}", l):
            titulo = l.strip()
            break

    secciones, actual, buffer = {}, None, []

    def cerrar():
        if actual is not None:
            previo = secciones.get(actual, "")
            nuevo = unir_lineas(buffer)
            secciones[actual] = (previo + "\n" + nuevo).strip() if previo else nuevo

    for l in lineas[inicio:]:
        m = RE_TITULO_SECCION.match(l)
        if m:
            cerrar()
            actual, buffer = clave_seccion(m.group(1)), []
            if m.group(2).strip():
                buffer.append(m.group(2))
        else:
            buffer.append(l)
    cerrar()

    # firma al final de la última sección: se corta desde la primera línea con forma de firma
    if secciones:
        ultima = list(secciones)[-1]
        partes = secciones[ultima].split("\n")
        corte = next((i for i, p in enumerate(partes) if RE_FIRMA.match(p)), None)
        if corte is not None:
            secciones[ultima] = "\n".join(partes[:corte]).strip()

    secciones = {k: anonimizar(v) for k, v in secciones.items() if v.strip()}
    if not secciones:
        return None
    return {"titulo": anonimizar(titulo), "secciones": secciones}


def texto_pdf(datos: bytes) -> str:
    from pypdf import PdfReader
    lector = PdfReader(io.BytesIO(datos))
    return "\n".join((p.extract_text() or "") for p in lector.pages)


# ------------------------------------------------------------ almacenamiento
_ids = None


def _ids_guardados():
    global _ids
    if _ids is None:
        _ids = set()
        if ARCHIVO.exists():
            for linea in ARCHIVO.read_text(encoding="utf-8").splitlines():
                try:
                    _ids.add(json.loads(linea)["id"])
                except Exception:  # noqa: BLE001
                    pass
    return _ids


def importar(id_informe: str, pdf: bytes) -> dict:
    ids = _ids_guardados()
    if id_informe and id_informe in ids:
        return {"guardado": False, "motivo": "ya importado"}
    informe = parsear(texto_pdf(pdf))
    if not informe:
        return {"guardado": False, "motivo": "no se reconocieron secciones"}
    CARPETA.mkdir(exist_ok=True)
    informe = {"id": id_informe, **informe}
    with open(ARCHIVO, "a", encoding="utf-8") as f:
        f.write(json.dumps(informe, ensure_ascii=False) + "\n")
    ids.add(id_informe)
    return {"guardado": True, "secciones": list(informe["secciones"])}

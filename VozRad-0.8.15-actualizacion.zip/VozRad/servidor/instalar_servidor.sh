#!/bin/bash
# VozRad - instalación en un servidor Linux (Ubuntu 22.04 / 24.04) para el piloto en IRAD.
#
#   sudo bash instalar_servidor.sh <nombre-del-servidor> <radiologo1> [<radiologo2> ...]
#   ej.: sudo bash instalar_servidor.sh vozrad.irad.cl alvaro marcelo
#
# Deja:
#   /opt/vozrad/venv              Python compartido
#   /opt/vozrad/modelos           modelos de voz compartidos (~2 GB, se descargan una vez)
#   /opt/vozrad/<radiologo>/      una copia de VozRad por radiólogo (su perfil, su clave, sus actualizaciones)
#   servicio vozrad@<radiologo>   se inicia solo y se reinicia solo (también tras actualizar)
#   Caddy (HTTPS)                 https://<nombre>/<radiologo>  ->  127.0.0.1:<puerto de ese radiólogo>
#
# Certificado: si el servidor es alcanzable desde internet en el puerto 80/443 con ese nombre, Caddy obtiene
# uno solo (Let's Encrypt). Si IRAD entrega su propio certificado, antes de correr esto:
#   export VOZRAD_CERT=/ruta/cert.pem VOZRAD_KEY=/ruta/clave.pem
set -euo pipefail

if [ "$(id -u)" != "0" ]; then echo "Ejecuta con sudo."; exit 1; fi
if [ $# -lt 2 ]; then
  echo "Uso: sudo bash instalar_servidor.sh <nombre-del-servidor> <radiologo1> [<radiologo2> ...]"; exit 1
fi
NOMBRE="$1"; shift
ORIGEN="$(cd "$(dirname "$0")/.." && pwd)"          # la carpeta VozRad que trae este script
DESTINO="${VOZRAD_DESTINO:-/opt/vozrad}"
PUERTO_BASE=8765

echo "=== VozRad · servidor ${NOMBRE} · radiólogos: $* ==="

# 1) paquetes del sistema
apt-get update -q
apt-get install -y -q python3 python3-venv python3-pip rsync curl caddy
PY=$(command -v python3.12 || command -v python3.11 || command -v python3)
echo "Python: $($PY -V)"

# 2) usuario de servicio y carpetas
id vozrad >/dev/null 2>&1 || useradd --system --home "$DESTINO" --shell /usr/sbin/nologin vozrad
mkdir -p "$DESTINO/modelos"

# 3) Python compartido
if [ ! -x "$DESTINO/venv/bin/python" ]; then
  "$PY" -m venv "$DESTINO/venv"
fi
"$DESTINO/venv/bin/pip" install -q --upgrade pip
"$DESTINO/venv/bin/pip" install -q -r "$ORIGEN/servidor/requirements.txt"

# 4) una copia por radiólogo (sin pisar su perfil si ya existe)
i=0
SITIOS=""
for R in "$@"; do
  if ! [[ "$R" =~ ^[a-z0-9_-]+$ ]]; then echo "Nombre inválido: $R (usa minúsculas, números, - o _)"; exit 1; fi
  PUERTO=$((PUERTO_BASE + i)); i=$((i + 1))
  D="$DESTINO/$R"
  mkdir -p "$D"
  rsync -a --exclude 'config.json' --exclude 'correcciones.json' --exclude 'plantillas.json' \
        --exclude 'vocabulario.txt' --exclude 'terminos_prioritarios.txt' --exclude 'nombres_propios.txt' \
        --exclude 'informes/' --exclude 'historial/' --exclude 'perfil/' --exclude 'respaldos/' \
        --exclude 'modelos/' --exclude '.venv/' --exclude '__pycache__/' "$ORIGEN/" "$D/"
  ln -sfn "$DESTINO/modelos" "$D/servidor/modelos"
  ln -sfn "$DESTINO/venv" "$D/servidor/.venv"
  echo "PUERTO=$PUERTO" > "$D/vozrad.env"
  SITIOS="${SITIOS}
	handle_path /${R}/* {
		reverse_proxy 127.0.0.1:${PUERTO}
	}"
  echo "  ${R}: puerto interno ${PUERTO}"
done
chown -R vozrad:vozrad "$DESTINO"
chmod 750 "$DESTINO"

# 5) servicio (uno por radiólogo)
cat > "${VOZRAD_ETC:-/etc}/systemd/system/vozrad@.service" <<EOF
[Unit]
Description=VozRad (%i)
After=network-online.target
Wants=network-online.target

[Service]
User=vozrad
Group=vozrad
WorkingDirectory=${DESTINO}/%i/servidor
EnvironmentFile=${DESTINO}/%i/vozrad.env
Environment=HF_HOME=${DESTINO}/modelos/hf
Environment=PYTHONUNBUFFERED=1
ExecStart=${DESTINO}/venv/bin/python servidor.py --servidor --puerto \${PUERTO}
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

# 6) HTTPS con Caddy
TLS=""
if [ -n "${VOZRAD_CERT:-}" ] && [ -n "${VOZRAD_KEY:-}" ]; then TLS="	tls ${VOZRAD_CERT} ${VOZRAD_KEY}"; fi
cat > "${VOZRAD_ETC:-/etc}/caddy/Caddyfile" <<EOF
${NOMBRE} {
${TLS}
	encode gzip
	request_body {
		max_size 20MB
	}${SITIOS}
	respond / "VozRad" 200
}
EOF
systemctl daemon-reload
systemctl enable --now caddy
systemctl reload caddy || systemctl restart caddy

for R in "$@"; do systemctl enable --now "vozrad@${R}"; done

# 7) esperar a que cada motor genere su clave (la primera vez descarga los modelos: varios minutos)
echo
echo "Arrancando los motores (la primera vez descargan el modelo de voz; puede tardar 5-10 minutos)..."
for R in "$@"; do
  for _ in $(seq 1 120); do
    CLAVE=$("$DESTINO/venv/bin/python" -c "import json;print(json.load(open('$DESTINO/$R/servidor/config.json')).get('clave_red',''))" 2>/dev/null || true)
    [ -n "$CLAVE" ] && break; sleep 5
  done
  echo "  ${R}:  dirección https://${NOMBRE}/${R}   clave ${CLAVE:-<ver: journalctl -u vozrad@${R}>}"
done
echo
echo "En el panel de VozRad de cada radiólogo: ⚙ -> «Motor en red» -> su dirección y su clave -> Probar -> Guardar."
echo "Registros:   journalctl -u vozrad@<radiologo> -f      Estado:  systemctl status vozrad@<radiologo>"
echo "Salud:       curl https://${NOMBRE}/<radiologo>/salud"

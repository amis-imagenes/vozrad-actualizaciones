"""
VozRad - motores de reconocimiento.

  parakeet : NVIDIA Parakeet TDT 0.6B v3 (ONNX, int8, en el procesador).
             Procesa solo lo que dura la frase -> muy rápido incluso sin tarjeta gráfica.
             No acepta vocabulario como pista: tus términos se corrigen después (correcciones.json).
  whisper  : Whisper large-v3-turbo (faster-whisper). Acepta vocabulario y términos prioritarios,
             pero procesa siempre una ventana de 30 s: en tarjetas débiles es lento.

Cada motor expone:  reconocer(pcm_float32_16k, prompt:str, hotwords:str, beam:int) -> str
"""
import os
import re
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent
MODELOS = BASE / "modelos"


def _registrar_dll_cuda():
    """En Windows, las librerías CUDA (cublas/cudnn) vienen como paquetes pip: hay que registrarlas."""
    if os.name != "nt":
        return
    import site
    rutas = []
    for sp in site.getsitepackages() + [site.getusersitepackages()]:
        for sub in ("nvidia/cublas/bin", "nvidia/cudnn/bin", "nvidia/cuda_nvrtc/bin"):
            p = Path(sp) / sub
            if p.is_dir():
                rutas.append(str(p))
    for r in rutas:
        try:
            os.add_dll_directory(r)
        except OSError:
            pass
    os.environ["PATH"] = os.pathsep.join(rutas + [os.environ.get("PATH", "")])


_registrar_dll_cuda()


def preparar(pcm: np.ndarray) -> np.ndarray:
    """Quita la componente continua, sube el volumen si la frase vino baja y agrega un poco de
    silencio al inicio y al final (los modelos NVIDIA reconocen mejor así)."""
    x = pcm.astype(np.float32)
    if x.size == 0:
        return x
    x = x - float(np.mean(x))
    pico = float(np.max(np.abs(x))) or 1e-6
    ganancia = min(0.9 / pico, 20.0)
    if ganancia > 1.0:
        x = x * ganancia
    relleno = np.zeros(4000, dtype=np.float32)      # 0,25 s
    return np.concatenate([relleno, x, relleno])


def _cargar_onnx(nombre_modelo: str, hilos, dispositivo: str):
    """Carga un modelo NVIDIA en ONNX. dispositivo "cuda" usa la tarjeta gráfica si onnxruntime-gpu
    está instalado y hay memoria (tarjetas de 6 GB o más); si no, el procesador."""
    os.environ.setdefault("HF_HOME", str(MODELOS / "hf"))
    os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
    import onnx_asr
    import onnxruntime as ort
    opciones = ort.SessionOptions()
    opciones.intra_op_num_threads = hilos or max(1, (os.cpu_count() or 4))
    if dispositivo == "cuda" and "CUDAExecutionProvider" in ort.get_available_providers():
        try:
            m = onnx_asr.load_model(nombre_modelo, providers=["CUDAExecutionProvider", "CPUExecutionProvider"],
                                    sess_options=opciones)
            return m, "cuda/fp32"
        except Exception as e:  # noqa: BLE001
            print(f"[VozRad]   tarjeta gráfica no disponible para {nombre_modelo} ({str(e)[:120]}); uso el procesador")
    m = onnx_asr.load_model(nombre_modelo, quantization="int8", providers=["CPUExecutionProvider"], sess_options=opciones)
    return m, f"cpu/int8/{opciones.intra_op_num_threads}h"


def _nucleos_rendimiento() -> int | None:
    """En Mac con chip Apple: cuántos núcleos de RENDIMIENTO tiene (los de eficiencia son lentos)."""
    import sys
    if sys.platform != "darwin":
        return None
    try:
        import subprocess
        n = int(subprocess.run(["sysctl", "-n", "hw.perflevel0.physicalcpu"], capture_output=True, text=True, timeout=5).stdout.strip())
        return n if n > 0 else None
    except Exception:  # noqa: BLE001
        return None


def medir_hilos() -> int:
    """Prueba cuántos núcleos del procesador conviene usar (con hyperthreading, usar todos a veces es MÁS lento).
    Se hace una sola vez; el resultado queda en config.json ("hilos_cpu")."""
    import time
    logicos = os.cpu_count() or 4
    opciones = {logicos, max(1, logicos // 2), max(1, (logicos * 3) // 4)}
    rendimiento = _nucleos_rendimiento()
    if rendimiento:
        opciones.add(rendimiento)          # Mac con chip Apple: solo los núcleos rápidos (p. ej. 8 en un M1 Pro)
    opciones = sorted(opciones, reverse=True)
    if len(opciones) == 1:
        return logicos
    rng = np.random.default_rng(0)
    prueba = (rng.standard_normal(16000 * 4) * 0.05).astype(np.float32)
    tiempos = {}
    for h in opciones:
        m = MotorParakeet(h)
        m.reconocer(prueba)
        t0 = time.perf_counter()
        for _ in range(3):
            m.reconocer(prueba)
        tiempos[h] = (time.perf_counter() - t0) / 3
        print(f"[VozRad]   {h:2d} hilos: {tiempos[h] * 1000:.0f} ms por frase de 4 s")
        del m
    return min(tiempos, key=tiempos.get)


class MotorParakeet:
    nombre = "parakeet"

    def __init__(self, hilos: int | None = None, dispositivo: str = "cpu"):
        self.modelo, modo = _cargar_onnx("nemo-parakeet-tdt-0.6b-v3", hilos, dispositivo)
        self.descripcion = f"{modo}/parakeet-tdt-0.6b-v3"
        self.reconocer(np.zeros(16000, dtype=np.float32))   # calentar

    punto_por_tiempo = True          # se puede apagar con "punto_por_tiempo": false en config.json
    confianzas = True                # entregar la confianza de cada palabra (para la predicción por contexto)
    ultimas_confianzas = None
    lenguaje = None                  # config "modelo_lenguaje": {"activo": true, "alfa": .., "beta": .., "haz": ..}
    punto_inferido = False

    def reconocer(self, pcm, prompt: str = "", hotwords: str = "", beam: int = 1) -> str:
        self.punto_inferido = False
        self.ultimas_confianzas = None
        if pcm.size < 1600:
            return ""
        x = preparar(pcm)
        cfg_lm = self.lenguaje
        if cfg_lm and cfg_lm.get("activo"):
            try:
                import decodificador
                r = decodificador.reconocer(self.modelo, x, alfa=float(cfg_lm.get("alfa", 0.5)),
                                            beta=float(cfg_lm.get("beta", 1.0)), haz=int(cfg_lm.get("haz", 4)))
                if r is not None:
                    t, tokens, tiempos = r
                    t = (t or "").strip()
                    if self.punto_por_tiempo:
                        nuevo = punto_oculto(t, tokens, tiempos, x)
                        self.punto_inferido = nuevo != t
                        return nuevo
                    return t
            except Exception as e:  # noqa: BLE001
                print(f"[VozRad] aviso: modelo de lenguaje desactivado por un error ({e})", flush=True)
                cfg_lm["activo"] = False
        if self.punto_por_tiempo or self.confianzas:
            if getattr(self, "_ts", None) is None:
                try:
                    self._ts = self.modelo.with_timestamps()
                except Exception:  # noqa: BLE001
                    self._ts = False
            if self._ts:
                try:
                    r = self._ts.recognize(x, sample_rate=16000)
                    t = (r.text or "").strip()
                    self.ultimas_confianzas = confianza_por_palabra(t, list(r.tokens or []), list(r.logprobs or []))
                    if not self.punto_por_tiempo:
                        return t
                    nuevo = punto_oculto(t, list(r.tokens or []), list(r.timestamps or []), x)
                    self.punto_inferido = nuevo != t
                    if self.punto_inferido and self.ultimas_confianzas:
                        self.ultimas_confianzas = self.ultimas_confianzas + [0.0]   # la palabra «punto» agregada
                    return nuevo
                except Exception:  # noqa: BLE001
                    self._ts = False
        r = self.modelo.recognize(x, sample_rate=16000)
        return (r if isinstance(r, str) else getattr(r, "text", str(r))).strip()


def confianza_por_palabra(texto: str, tokens: list, logprobs: list):
    """Log-probabilidad mínima de los trozos de cada palabra de texto.split() (None si no calza)."""
    if not tokens or len(tokens) != len(logprobs):
        return None
    palabras, actual = [], None
    for tk, lp in zip(tokens, logprobs):
        nueva = tk.startswith(" ") or tk.startswith("\u2581") or actual is None
        if nueva and tk.strip(" \u2581"):
            if actual is not None:
                palabras.append(actual)
            actual = float(lp)
        elif actual is not None:
            actual = min(actual, float(lp))
        elif tk.strip(" \u2581"):
            actual = float(lp)
    if actual is not None:
        palabras.append(actual)
    return palabras if len(palabras) == len(texto.split()) else None


ULTIMO_PUNTO = None     # diagnóstico de la última frase que terminó en «.» del motor (sin «punto» dicho)


def punto_oculto(texto: str, tokens: list, tiempos: list, x: np.ndarray, sr: int = 16000) -> str:
    """Parakeet a veces convierte el «punto» que dictas al final en un simple «.» (y ese punto del motor
    se descarta, porque la puntuación la dictas tú). Se reconoce porque el «.» llega bastante después de la
    última palabra y en ese tramo hay voz: entonces se devuelve la palabra «punto»."""
    global ULTIMO_PUNTO
    ULTIMO_PUNTO = None
    if not texto.endswith(".") or re.search(r"\bpunto\W*$", texto, re.I) or len(tokens) != len(tiempos) or len(tokens) < 2:
        return texto
    k = max((i for i, tk in enumerate(tokens) if tk.strip()), default=-1)
    if k < 1 or tokens[k].strip().lstrip("\u2581") != ".":
        return texto
    j = max((i for i in range(k) if re.search(r"[A-Za-zÁÉÍÓÚÑáéíóúñü0-9]", tokens[i])), default=-1)
    if j < 0:
        return texto
    hueco = tiempos[k] - tiempos[j]
    ULTIMO_PUNTO = {"hueco": round(hueco, 2), "voz": None}
    if hueco < 0.32:
        return texto
    trozo = 320                                            # 20 ms
    ini = int((tiempos[j] + 0.3) * sr)
    if ini >= x.size:
        return texto
    energia = np.array([np.sqrt(np.mean(x[i:i + trozo] ** 2)) + 1e-9 for i in range(0, x.size - trozo, trozo)])
    if energia.size == 0:
        return texto
    db = 20 * np.log10(energia)
    umbral = float(np.max(db)) - 30
    voz_despues = float(np.sum(db[ini // trozo:] > umbral)) * trozo / sr
    ULTIMO_PUNTO["voz"] = round(voz_despues, 2)
    if voz_despues < 0.2:
        return texto
    return texto[:-1].rstrip() + " punto"


class MotorCanary(MotorParakeet):
    """NVIDIA Canary 1B v2: más grande que Parakeet (suele ser más preciso), algo más lento."""
    nombre = "canary"

    def __init__(self, hilos: int | None = None, dispositivo: str = "cpu"):
        self.modelo, modo = _cargar_onnx("nemo-canary-1b-v2", hilos, dispositivo)
        self.descripcion = f"{modo}/canary-1b-v2"
        self.reconocer(np.zeros(16000, dtype=np.float32))

    def reconocer(self, pcm, prompt: str = "", hotwords: str = "", beam: int = 1) -> str:
        if pcm.size < 1600:
            return ""
        try:
            r = self.modelo.recognize(preparar(pcm), sample_rate=16000, language="es")
        except TypeError:
            r = self.modelo.recognize(preparar(pcm), sample_rate=16000)
        return (r if isinstance(r, str) else getattr(r, "text", str(r))).strip()


class MotorHibrido:
    """Parakeet (rápido) para todo; si deja la frase vacía o demasiado corta para lo que duró
    el audio, la repite con Canary (más lento, más robusto)."""
    nombre = "hibrido"

    def __init__(self, hilos: int | None = None, dispositivo: str = "cpu"):
        self.rapido = MotorParakeet(hilos, dispositivo)
        self.respaldo = MotorCanary(hilos, dispositivo)
        self.descripcion = self.rapido.descripcion.rsplit("/", 1)[0] + "/parakeet+canary"
        self.ultimo_respaldo = False

    def reconocer(self, pcm, prompt: str = "", hotwords: str = "", beam: int = 1) -> str:
        t = self.rapido.reconocer(pcm)
        if re.search(r"[^\x00-\u024F\u2010-\u2027\u00B2\u00B3\s]", t):
            t = ""                                   # salió en otro alfabeto (p.ej. ruso): repetir con Canary en español
        segundos = pcm.size / 16000
        palabras = len(t.split())
        # Canary solo para frases normales: en 25 s de ruido de fondo tardaría ~6 s y bloquearía el dictado
        sospechoso = segundos <= 12 and ((not t and segundos >= 1.2) or (segundos >= 2.5 and palabras < segundos * 0.6))
        self.ultimo_respaldo = False
        if sospechoso:
            t2 = self.respaldo.reconocer(pcm)
            if len(t2.split()) > palabras:
                self.ultimo_respaldo = True
                return t2
        return t


class MotorWhisper:
    nombre = "whisper"

    def __init__(self, modelo="large-v3-turbo", respaldo_cpu="small"):
        from faster_whisper import WhisperModel
        intentos = [("cuda", "int8", modelo), ("cuda", "float32", modelo), ("cpu", "int8", respaldo_cpu)]
        ultimo = None
        for dispositivo, tipo, nombre in intentos:
            try:
                print(f"[VozRad] Cargando Whisper {nombre} en {dispositivo} ({tipo})...")
                m = WhisperModel(nombre, device=dispositivo, compute_type=tipo,
                                 download_root=str(MODELOS), cpu_threads=4)
                m.transcribe(np.zeros(16000, dtype=np.float32), language="es", beam_size=1)
                self.modelo, self.descripcion = m, f"{dispositivo}/{tipo}/{nombre}"
                return
            except Exception as e:  # noqa: BLE001
                ultimo = e
                print(f"[VozRad]   no se pudo ({type(e).__name__}: {str(e)[:200]})")
        raise RuntimeError(f"Whisper no cargó: {ultimo}")

    def reconocer(self, pcm, prompt: str = "", hotwords: str = "", beam: int = 1) -> str:
        opciones = dict(language="es", beam_size=beam, temperature=0.0, condition_on_previous_text=False,
                        initial_prompt=prompt or None, no_speech_threshold=0.6, vad_filter=False,
                        without_timestamps=True)
        if hotwords:
            opciones["hotwords"] = hotwords
        try:
            segs, _ = self.modelo.transcribe(pcm, **opciones)
        except TypeError:
            opciones.pop("hotwords", None)
            segs, _ = self.modelo.transcribe(pcm, **opciones)
        partes = [s.text for s in segs if not (s.no_speech_prob > 0.6 and s.avg_logprob < -1.0)]
        return " ".join(p.strip() for p in partes).strip()


def cargar(cfg: dict):
    """Carga el motor elegido en config.json ("motor": "parakeet" | "canary" | "whisper"); si falla, el otro."""
    preferido = cfg.get("motor", "parakeet")
    hilos = cfg.get("hilos_cpu")
    disp = cfg.get("dispositivo", "cpu")
    if preferido in ("hibrido", "parakeet", "canary") and not isinstance(hilos, int):
        print("[VozRad] Primera vez: mido cuántos núcleos del procesador conviene usar (~30 s, solo esta vez)...")
        try:
            hilos = medir_hilos()
            cfg["hilos_cpu_medidos"] = hilos
            print(f"[VozRad]   -> uso {hilos} hilos")
        except Exception as e:  # noqa: BLE001
            print(f"[VozRad]   no pude medir ({str(e)[:120]}); uso todos")
            hilos = None
    orden = [preferido] + [m for m in ("parakeet", "whisper") if m != preferido]
    for nombre in orden:
        try:
            if nombre == "hibrido":
                print("[VozRad] Cargando Parakeet + Canary (modo híbrido)...")
                return MotorHibrido(hilos, disp)
            if nombre == "canary":
                print("[VozRad] Cargando Canary 1B v2 (la primera vez se descarga ~1 GB)...")
                return MotorCanary(hilos, disp)
            if nombre == "parakeet":
                print("[VozRad] Cargando Parakeet v3 (la primera vez se descarga ~670 MB)...")
                return MotorParakeet(hilos, disp)
            return MotorWhisper(cfg.get("modelo", "large-v3-turbo"), cfg.get("modelo_respaldo_cpu", "small"))
        except Exception as e:  # noqa: BLE001
            print(f"[VozRad]   motor {nombre} no disponible ({type(e).__name__}: {str(e)[:200]})")
    raise RuntimeError("No se pudo cargar ningún motor de voz.")

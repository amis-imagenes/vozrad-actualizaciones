"""
VozRad - predicción por contexto (propuesta del Dr. Otárola, 28-10-2026).

Cuando el motor DUDA de una palabra (baja confianza), se busca en tus informes qué palabra suele ir entre
lo que viene antes y lo que viene después («placas de ateroma a nivel de su ___ y porción descendente»),
y entre esas se elige la que además SUENA parecido a lo que el motor oyó. Si el motor estaba seguro, no se
toca nada.

Nunca se predicen palabras donde el historial puede tener razón «en promedio» y estar equivocado para ESTE
paciente: lateralidad, ubicación, negaciones, grados de severidad, números y medidas. Ahí se deja lo oído.
"""
import difflib
import math
import re

import lenguaje

# palabras que el historial NUNCA decide (ni se cambian ni se ponen)
PROTEGIDAS = re.compile(
    r"^(?:derech[oa]s?|izquierd[oa]s?|bilateral(?:es)?|unilateral(?:es)?|ambos|ambas|"
    r"superior(?:es)?|inferior(?:es)?|anterior(?:es)?|posterior(?:es)?|medial(?:es)?|lateral(?:es)?|"
    r"proximal(?:es)?|distal(?:es)?|central(?:es)?|periferic[oa]s?|"
    r"no|sin|ni|nunca|tampoco|normal(?:es)?|anormal(?:es)?|"
    r"leve(?:s)?|moderad[oa]s?|sever[oa]s?|marcad[oa]s?|discret[oa]s?|"
    r"aumentad[oa]s?|disminuid[oa]s?|mayor(?:es)?|menor(?:es)?|"
    r"agud[oa]s?|cronic[oa]s?|nuev[oa]s?|antigu[oa]s?|"
    r"grado|tipo|estadio|segmento|nivel|barra|romano|<n>|[ivx]+|[a-z]\d+)$")

ESPACIO = re.compile(r"\S+")


def _norm(w):
    return lenguaje.normalizar(w)


def protegida(n: str) -> bool:
    return bool(n) and (bool(PROTEGIDAS.match(n)) or n in lenguaje.NUMEROS)


class Indice:
    """Para cada palabra: qué palabras la siguen y cuáles la preceden en tus informes."""

    def __init__(self, lm):
        self.lm = lm
        self.siguen, self.preceden = {}, {}
        for clave, c in lm.bi.items():
            a, b = clave.split(" ", 1)
            self.siguen.setdefault(a, {})[b] = c
            self.preceden.setdefault(b, {})[a] = c

    def bi(self, a, b):
        return self.lm.bi.get(f"{a} {b}", 0)

    def tri(self, a, b, c):
        return self.lm.tri.get(f"{a} {b} {c}", 0)


_INDICE = {"lm": None, "idx": None}


def indice():
    lm = lenguaje.MODELO
    if not lm.listo:
        return None
    if _INDICE["lm"] is not lm.uni:
        _INDICE["lm"], _INDICE["idx"] = lm.uni, Indice(lm)
    return _INDICE["idx"]


def _apoyo(idx, w, izq, der):
    """Log-probabilidad de que «w» vaya entre «izq» (2 palabras) y «der» (1-2 palabras) en tus informes."""
    lm = idx.lm
    s = 0.0
    if izq:
        a = izq[-1]
        c_ab = idx.bi(a, w)
        base = lm.ctx.get(a) or lm.uni.get(a) or 1
        p = (c_ab + 0.05) / (base + 1)
        if len(izq) >= 2 and c_ab:
            c3 = idx.tri(izq[-2], a, w)
            c2 = idx.bi(izq[-2], a)
            if c3 and c2:
                p = max(p, c3 / c2)
        s += math.log(p)
    if der:
        b = der[0]
        c_wb = idx.bi(w, b)
        p = (c_wb + 0.05) / ((lm.uni.get(w) or 0) + 1)
        if len(der) >= 2 and c_wb:
            c3 = idx.tri(w, b, der[1])
            if c3:
                p = max(p, c3 / c_wb)
        s += math.log(p)
    return s


def _parecido(a: str, b: str) -> float:
    try:
        import contexto
        fa, fb = contexto.fonetica(a), contexto.fonetica(b)
    except Exception:  # noqa: BLE001
        fa, fb = a, b
    son = difflib.SequenceMatcher(None, fa or a, fb or b).ratio()
    letras = difflib.SequenceMatcher(None, a, b).ratio()
    return 0.6 * son + 0.4 * letras


def _misma_palabra(a: str, b: str) -> bool:
    """«determinan»/«determina», «definidas»/«definidos»: la misma palabra con otra terminación."""
    try:
        import texto
        if texto._solo_flexion(a, b):
            return True
    except Exception:  # noqa: BLE001
        pass
    raiz = lambda w: re.sub(r"(?:es|s|n|a|o|as|os|an|en)$", "", w)  # noqa: E731
    return raiz(a) == raiz(b) or a.rstrip("s") == b.rstrip("s")


def _forma_escrita(n: str) -> str:
    try:
        import contexto
        if contexto.MODELO.firma is None:
            contexto.MODELO.cargar()
        return contexto.MODELO.forma.get(n, n)
    except Exception:  # noqa: BLE001
        return n


def predecir(texto: str, confianzas=None, umbral_conf: float = -0.7, margen: float = 3.0,
             parecido_min: float = 0.62, todas: bool = False, frecuente: int = 5):
    """
    Devuelve (texto_corregido, cambios). `confianzas` = lista paralela a texto.split() con la
    log-probabilidad mínima de cada palabra según el motor (None = desconocida). Sin confianzas solo
    actúa si todas=True (para pruebas).
    """
    idx = indice()
    if idx is None or not texto:
        return texto, []
    piezas = [(m.start(), m.end(), m.group(0)) for m in ESPACIO.finditer(texto)]
    norm = [_norm(p[2]) for p in piezas]
    usar_conf = confianzas is not None and len(confianzas) == len(piezas)
    if not usar_conf and not todas:
        return texto, []
    cambios = []
    nuevas = list(norm)
    for i, (a, b, w) in enumerate(piezas):
        n = norm[i]
        if not n or len(n) < 4 or protegida(n):
            continue
        if usar_conf and (confianzas[i] is None or confianzas[i] > umbral_conf):
            continue                                     # el motor está seguro: no se toca
        muy_dudosa = usar_conf and confianzas[i] < umbral_conf - 2.0
        if idx.lm.uni.get(n, 0) >= frecuente and not muy_dudosa:
            continue                                     # palabra que usas seguido: solo si el motor dudó mucho
        izq = [x for x in nuevas[max(0, i - 6):i] if x][-2:]
        der = [x for x in norm[i + 1:i + 7] if x][:2]
        if not izq and not der:
            continue
        actual = _apoyo(idx, n, izq, der)
        minimo = parecido_min
        try:
            import contexto
            if contexto._zipf(n) >= 3.0:
                minimo = max(minimo, 0.8)                # palabra real del español («evento», «color»): solo si suena casi igual
        except Exception:  # noqa: BLE001
            pass
        candidatos = set()
        if izq:
            candidatos |= set(idx.siguen.get(izq[-1], {}))
        if der:
            candidatos |= set(idx.preceden.get(der[0], {}))
        mejor, mejor_s = None, actual + margen
        for c in candidatos:
            if c == n or len(c) < 3 or c.startswith("<") or protegida(c):
                continue
            if abs(len(c) - len(n)) > max(3, len(n) // 2):
                continue
            if _misma_palabra(n, c):
                continue                                 # singular/plural, masculino/femenino: lo decide la frase, no el historial
            dos_lados = not (izq and der) or (idx.bi(izq[-1], c) and idx.bi(c, der[0]))
            if n.startswith(c) and len(n) - len(c) >= 3:
                continue                                 # «lesionosa»: son DOS palabras pegadas, no una mal oída
            par = _parecido(n, c)
            if c.endswith(n) or c.startswith(n):
                par = max(par, 0.9)                      # «podensas» = el final de «hipodensas»
            if par < minimo or (not dos_lados and par < 0.85):
                continue                                 # debe calzar por los dos lados (o sonar casi igual)
            s = _apoyo(idx, c, izq, der) + 10.0 * (par - minimo)
            if s > mejor_s:
                mejor, mejor_s = c, s
        if mejor:
            nueva = _forma_escrita(mejor)
            if w[:1].isupper():
                nueva = nueva[:1].upper() + nueva[1:]
            cola = re.search(r"[^\wáéíóúüñÁÉÍÓÚÜÑ]*$", w).group(0)
            cambios.append((a, b, nueva + cola, w))
            nuevas[i] = mejor
    for a, b, nuevo, _ in reversed(cambios):
        texto = texto[:a] + nuevo + texto[b:]
    return texto, [(viejo, nuevo) for _, _, nuevo, viejo in cambios]

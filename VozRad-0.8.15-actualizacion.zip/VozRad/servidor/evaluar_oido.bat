@echo off
chcp 65001 >nul
title VozRad - evaluar oido radiologico
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Primero ejecuta instalar.bat
  pause & exit /b 1
)
echo Cierra iniciar.bat antes (usa el mismo motor). Tarda 5-15 minutos.
.venv\Scripts\python.exe evaluar_oido.py
echo.
pause

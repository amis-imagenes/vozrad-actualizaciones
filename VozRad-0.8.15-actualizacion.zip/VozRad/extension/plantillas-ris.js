// VozRad - importa tus plantillas de MultiRisWeb (pantalla Plantillas) a VozRad.
// Lee cada plantilla del RIS (EditarPlantilla.aspx?id=...) y la envía SOLO a tu servidor local.
// Después quedan disponibles por voz: "plantilla <nombre>".
(() => {
  "use strict";
  if (window.__vozradPlantillasRis) return;
  window.__vozradPlantillasRis = true;

  const dormir = (ms) => new Promise((r) => setTimeout(r, ms));
  const MODALIDAD_VOZ = { CT: "tac", MR: "resonancia", US: "eco", MG: "mamografia", CR: "rx", DX: "rx", RF: "fluoroscopia", XA: "angiografia", OT: "otro" };

  function api(ruta, cuerpo) {
    return new Promise((ok, ko) => {
      chrome.runtime.sendMessage({ tipo: "api", ruta, cuerpo }, (r) => {
        if (chrome.runtime.lastError) return ko(new Error(chrome.runtime.lastError.message));
        r && r.ok ? ok(r.datos) : ko(new Error((r && r.error) || "sin respuesta"));
      });
    });
  }

  // HTML del editor -> texto con saltos de línea
  function aTexto(html) {
    const d = document.createElement("div");
    d.innerHTML = (html || "").replace(/<br\s*\/?>/gi, "\n").replace(/<\/(p|div|li|h\d)>/gi, "\n");
    return (d.textContent || "").replace(/ /g, " ").replace(/[ \t]+/g, " ").replace(/ *\n */g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }

  function listar() {
    const t = document.getElementById("gvDatos");
    if (!t) return [];
    return [...t.rows].slice(1).map((r) => {
      const c = [...r.cells].map((x) => x.innerText.trim());
      return { id: c[0], nombre: c[1], modalidad: c[2] };
    }).filter((x) => /^\d+$/.test(x.id));
  }

  async function leer(p) {
    const html = await fetch("EditarPlantilla.aspx?id=" + encodeURIComponent(p.id), { credentials: "include" }).then((r) => {
      if (!r.ok) throw new Error("RIS respondió " + r.status);
      return r.text();
    });
    const d = new DOMParser().parseFromString(html, "text/html");
    const val = (id) => { const e = d.getElementById(id); return e ? (e.value !== undefined && e.tagName !== "TEXTAREA" ? e.value : e.textContent) : ""; };
    const contenido = {};
    const titulo = (val("txtTitulo") || "").trim();
    if (titulo) contenido.titulo = /<[a-z]/i.test(titulo) ? { texto: aTexto(titulo), html: titulo } : { texto: titulo };
    for (const [campo, id] of [["tecnica", "txtTecnica"], ["antecedentes", "txtAntecedentes"], ["hallazgos", "txtHallazgos"], ["impresion", "txtImpresion"]]) {
      const h = (val(id) || "").trim();
      const t = aTexto(h);
      if (t) contenido[campo] = { texto: t, html: /<[a-z]/i.test(h) ? h : "" };
    }
    return { id: p.id, nombre: (val("txtNombre") || p.nombre).trim(), modalidad: p.modalidad, contenido };
  }

  // ------------------------------------------------------------ panel
  const host = document.createElement("div");
  host.style.cssText = "position:fixed;right:20px;bottom:20px;z-index:2147483647;";
  const raiz = host.attachShadow({ mode: "open" });
  raiz.innerHTML = `
    <link rel="stylesheet" href="${chrome.runtime.getURL("panel.css")}">
    <div class="panel">
      <header><span class="marca">VozRad · plantillas del RIS</span><span class="servidor"></span><button class="min">–</button></header>
      <div class="cuerpo">
        <div class="ultimo suave estado"></div>
        <button class="dictar importar"><span class="punto"></span><span class="lbl">Importar mis plantillas</span></button>
        <div class="sug-lista lista" hidden></div>
        <div class="aviso"></div>
      </div>
    </div>`;
  const $ = (s) => raiz.querySelector(s);

  // ---- mover el panel arrastrando su encabezado (recuerda dónde lo dejaste)
  (() => {
    const CLAVE = "posicion_plantillas";
    let dx = 0, dy = 0, mov = false;
    const dentro = () => {                            // que nunca quede fuera de la pantalla
      const r = host.getBoundingClientRect();
      if (!host.style.top || host.style.top === "auto") return;
      host.style.left = Math.min(Math.max(0, r.left), Math.max(0, window.innerWidth - r.width)) + "px";
      host.style.top = Math.min(Math.max(0, r.top), Math.max(0, window.innerHeight - r.height)) + "px";
    };
    raiz.addEventListener("mousedown", (e) => {
      const h = e.composedPath().find((n) => n.tagName === "HEADER");
      if (!h || e.target.closest("button")) return;
      mov = true; const r = host.getBoundingClientRect(); dx = e.clientX - r.left; dy = e.clientY - r.top; e.preventDefault();
    });
    window.addEventListener("mousemove", (e) => {
      if (!mov) return;
      host.style.left = Math.max(0, e.clientX - dx) + "px"; host.style.top = Math.max(0, e.clientY - dy) + "px";
      host.style.right = "auto"; host.style.bottom = "auto";
    });
    window.addEventListener("mouseup", () => {
      if (!mov) return; mov = false; dentro();
      chrome.storage.local.set({ [CLAVE]: { left: host.style.left, top: host.style.top } });
    });
    window.addEventListener("resize", dentro);
    chrome.storage.local.get(CLAVE).then((d) => {
      const p = d && d[CLAVE];
      if (p && p.left) { host.style.left = p.left; host.style.top = p.top; host.style.right = "auto"; host.style.bottom = "auto"; setTimeout(dentro, 100); }
    }).catch(() => {});
  })();
  $(".min").onclick = () => $(".panel").classList.toggle("minimizado");

  async function importar() {
    const lista = listar();
    if (!lista.length) { $(".aviso").textContent = "No encontré plantillas en esta pantalla."; return; }
    try { await api("/estado"); } catch (_) { $(".aviso").textContent = "El servidor VozRad no está encendido (abre «iniciar» de VozRad)."; return; }
    $(".panel").classList.add("grabando");
    const leidas = [];
    let errores = 0;
    for (const [i, p] of lista.entries()) {
      $(".estado").textContent = `Leyendo ${i + 1} de ${lista.length}: ${p.nombre}`;
      try { leidas.push(await leer(p)); } catch (_) { errores++; }
      await dormir(250);
    }
    try {
      const r = await api("/plantillas/importar", { plantillas: leidas, voz_modalidad: MODALIDAD_VOZ });
      $(".estado").textContent = `${r.importadas} plantillas listas para dictar` + (errores ? ` · ${errores} no se pudieron leer` : "");
      const l = $(".sug-lista");
      l.hidden = false;
      l.innerHTML = "";
      const h = document.createElement("div");
      h.className = "sug-ayuda";
      h.textContent = "Di «plantilla» + el nombre:";
      l.appendChild(h);
      for (const n of r.nombres) { const f = document.createElement("div"); f.className = "sug"; f.textContent = "plantilla " + n; l.appendChild(f); }
    } catch (e) {
      $(".aviso").textContent = "Error al guardar: " + e.message;
    }
    $(".panel").classList.remove("grabando");
  }
  $(".importar").onclick = importar;

  (async () => {
    for (let i = 0; i < 20 && !document.getElementById("gvDatos"); i++) await dormir(500);
    if (!document.getElementById("gvDatos")) return;
    document.documentElement.appendChild(host);
    $(".estado").textContent = `${listar().length} plantillas en esta pantalla.`;
    try { await api("/estado"); $(".servidor").classList.add("ok"); $(".servidor").textContent = "motor listo"; }
    catch (_) { $(".servidor").textContent = "motor apagado"; }
  })();
})();

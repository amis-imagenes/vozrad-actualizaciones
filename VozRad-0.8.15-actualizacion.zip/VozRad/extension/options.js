// VozRad - configuración del motor de voz (este computador o motor en red).
const $ = (s) => document.querySelector(s);
const LOCAL = "http://127.0.0.1:8765";

function normalizar(dir) {
  let d = (dir || "").trim().replace(/\/+$/, "");
  if (!d) return "";
  if (!/^https?:\/\//i.test(d)) d = "http://" + d;
  const u = new URL(d);
  if (!u.port && u.protocol === "http:") u.port = "8765";     // https (servidor de IRAD) usa su puerto normal
  return u.origin + u.pathname.replace(/\/+$/, "");           // https://vozrad.irad.cl/alvaro
}
function modo() { return document.querySelector('input[name=modo]:checked').value; }
function pintarModo() { $("#campos-red").style.opacity = modo() === "red" ? "1" : ".45"; }
function mostrar(txt, clase) { const r = $("#resultado"); r.textContent = txt; r.className = clase || ""; }

async function permiso(url) {
  // permiso para hablar con ese computador (Chrome/Edge lo pide una vez)
  const origen = new URL(url).protocol + "//" + new URL(url).hostname + "/*";
  if (await chrome.permissions.contains({ origins: [origen] })) return true;
  return chrome.permissions.request({ origins: [origen] });
}

async function probar(url, clave) {
  const t0 = performance.now();
  const ctl = new AbortController(); setTimeout(() => ctl.abort(), 5000);
  const r = await fetch(url + "/estado", { headers: clave ? { "X-VozRad-Clave": clave } : {}, signal: ctl.signal });
  if (r.status === 401) throw new Error("la clave no es correcta");
  if (r.status === 403) throw new Error("ese computador no está en modo red (ábrelo con «iniciar_en_red»)");
  if (!r.ok) throw new Error("respondió " + r.status);
  const d = await r.json();
  return { ...d, ms: Math.round(performance.now() - t0) };
}

async function leerFormulario() {
  if (modo() === "local") return { url: LOCAL, clave: "" };
  const url = normalizar($("#direccion").value);
  if (!url) throw new Error("escribe la dirección del otro computador");
  const clave = $("#clave").value.trim().toUpperCase();
  if (!clave) throw new Error("escribe la clave que muestra el otro computador");
  if (!(await permiso(url))) throw new Error("sin permiso para conectar con ese computador");
  return { url, clave };
}

$("#probar").onclick = async () => {
  mostrar("Probando…");
  try {
    const d = await leerFormulario();
    const r = await probar(d.url, d.clave);
    mostrar(`✓ Conectado con «${r.equipo || "?"}» · ${r.motor || ""} · respondió en ${r.ms} ms`, "ok");
  } catch (e) {
    mostrar("✗ " + (e.name === "AbortError" ? "no responde (¿está abierto? ¿misma red?)" : e.message === "Failed to fetch" ? "no se pudo conectar (¿está abierto? ¿misma red? ¿firewall?)" : e.message), "mal");
  }
};

$("#guardar").onclick = async () => {
  try {
    const d = await leerFormulario();
    await chrome.storage.local.set({ servidor: d.url === LOCAL ? null : d });
    mostrar(d.url === LOCAL ? "✓ Guardado: este computador." : `✓ Guardado: motor en red ${d.url}.`, "ok");
  } catch (e) { mostrar("✗ " + e.message, "mal"); }
};

document.querySelectorAll('input[name=modo]').forEach((r) => (r.onchange = pintarModo));
(async () => {
  const { servidor } = await chrome.storage.local.get("servidor");
  const red = servidor && servidor.url && servidor.url !== LOCAL;
  document.querySelector(`input[value=${red ? "red" : "local"}]`).checked = true;
  if (red) { $("#direccion").value = servidor.url.replace(/^http:\/\//, "").replace(/:8765$/, ""); $("#clave").value = servidor.clave || ""; }
  pintarModo();
})();

// ---- actualizaciones: buscar ahora (la instalación se hace con el botón «Actualizar» del panel)
function api(ruta, cuerpo) {
  return new Promise((ok, ko) => chrome.runtime.sendMessage({ tipo: "api", ruta, cuerpo },
    (r) => (r && r.ok ? ok(r.datos) : ko(new Error((r && r.error) || "sin respuesta del motor")))));
}
async function pintarVersion() {
  try {
    const r = await api("/actualizacion");
    $("#version-txt").textContent = `Versión del motor: ${r.actual || "?"}` + (r.ultimo_chequeo ? ` · última revisión: ${r.ultimo_chequeo.replace("T", " ")}` : "") + ". Revisa sola cada hora.";
  } catch (_) {}
}
$("#buscar-act").onclick = async () => {
  const out = $("#act-resultado");
  out.textContent = "Buscando…"; out.className = "";
  try {
    const r = await api("/actualizacion/buscar", {});
    if (r.error) { out.textContent = "✗ No pude revisar: " + r.error; out.className = "mal"; }
    else if (r.disponible) { out.textContent = `★ Hay una versión nueva: ${r.disponible}. Vuelve al informe y pulsa «Actualizar» en el panel de VozRad.`; out.className = "ok"; }
    else { out.textContent = `✓ Ya tienes la última versión (${r.actual}).`; out.className = "ok"; }
  } catch (e) { out.textContent = "✗ " + e.message; out.className = "mal"; }
  pintarVersion();
};
pintarVersion();

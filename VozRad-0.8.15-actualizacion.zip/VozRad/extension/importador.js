// VozRad - importador de tus informes validados (corre en la lista de exámenes de MultiRisWeb).
// Recorre el listado que tengas filtrado en pantalla, en lotes, con pausas entre estudios.
// Cada PDF se envía SOLO a tu servidor local (127.0.0.1), que saca el texto, quita los datos
// del paciente y guarda Técnica / Antecedentes / Hallazgos / Impresión en tu PC.
(() => {
  "use strict";
  if (window.__vozradImportador) return;
  window.__vozradImportador = true;

  const PAUSA_MS = 1500;          // entre estudios en lotes de 100
  const PAUSA_TODOS_MS = 600;     // entre estudios al importar todo (horario de baja carga)
  const TAM_LOTE = 100;
  const TODOS = -1;               // "sin límite"
  const dormir = (ms) => new Promise((r) => setTimeout(r, ms));
  // Pausa medida por el motor local: Edge no la frena aunque la pestaña quede en segundo plano.
  async function pausa(ms) {
    try { await api("/esperar", { ms }); } catch (_) { await dormir(ms); }
  }

  function api(ruta, cuerpo) {
    return new Promise((ok, ko) => {
      chrome.runtime.sendMessage({ tipo: "api", ruta, cuerpo }, (r) => {
        if (chrome.runtime.lastError) return ko(new Error(chrome.runtime.lastError.message));
        r && r.ok ? ok(r.datos) : ko(new Error((r && r.error) || "sin respuesta"));
      });
    });
  }
  const leer = async () => (await chrome.storage.local.get("importacion")).importacion || { hechos: {}, informes: 0, errores: 0, pendienteLote: 0 };
  const guardar = (s) => chrome.storage.local.set({ importacion: s });

  // ------------------------------------------------------------ panel
  const host = document.createElement("div");
  host.style.cssText = "position:fixed;right:20px;bottom:20px;z-index:2147483647;";
  const raiz = host.attachShadow({ mode: "open" });
  raiz.innerHTML = `
    <link rel="stylesheet" href="${chrome.runtime.getURL("panel.css")}">
    <div class="panel minimizado">
      <header><span class="marca">VozRad · importar informes</span><span class="servidor"></span><button class="min">–</button></header>
      <div class="cuerpo">
        <div class="ultimo suave estado">Filtra el listado (tus estudios validados) y pulsa el botón.</div>
        <button class="dictar iniciar"><span class="punto"></span><span class="lbl">Importar lote de ${TAM_LOTE}</span></button>
        <button class="todos" title="Recorre todo el listado filtrado, sin límite">Importar todos</button>
        <div class="fila"><button class="detener">Detener</button><button class="reiniciar" title="Olvida qué estudios ya se importaron">Reiniciar contador</button></div>
        <div class="aviso"></div>
      </div>
    </div>`;
  const $ = (s) => raiz.querySelector(s);

  // ---- mover el panel arrastrando su encabezado (recuerda dónde lo dejaste)
  (() => {
    const CLAVE = "posicion_importador";
    let dx = 0, dy = 0, mov = false;
    const dentro = () => {                            // que nunca quede fuera de la pantalla
      const r = host.getBoundingClientRect();
      if (!host.style.top || host.style.top === "auto") return;
      host.style.left = Math.min(Math.max(0, r.left), Math.max(0, window.innerWidth - r.width)) + "px";
      host.style.top = Math.min(Math.max(0, r.top), Math.max(0, window.innerHeight - r.height)) + "px";
    };
    raiz.addEventListener("mousedown", (e) => {
      const h = e.composedPath().find((n) => n.tagName === "HEADER");
      if (!h || e.target.closest("button")) return;
      mov = true; const r = host.getBoundingClientRect(); dx = e.clientX - r.left; dy = e.clientY - r.top; e.preventDefault();
    });
    window.addEventListener("mousemove", (e) => {
      if (!mov) return;
      host.style.left = Math.max(0, e.clientX - dx) + "px"; host.style.top = Math.max(0, e.clientY - dy) + "px";
      host.style.right = "auto"; host.style.bottom = "auto";
    });
    window.addEventListener("mouseup", () => {
      if (!mov) return; mov = false; dentro();
      chrome.storage.local.set({ [CLAVE]: { left: host.style.left, top: host.style.top } });
    });
    window.addEventListener("resize", dentro);
    chrome.storage.local.get(CLAVE).then((d) => {
      const p = d && d[CLAVE];
      if (p && p.left) { host.style.left = p.left; host.style.top = p.top; host.style.right = "auto"; host.style.bottom = "auto"; setTimeout(dentro, 100); }
    }).catch(() => {});
  })();
  $(".min").onclick = () => $(".panel").classList.toggle("minimizado");

  let corriendo = false;
  async function pintar(msg) {
    const s = await leer();
    const n = Object.keys(s.hechos).length;
    $(".estado").textContent = (msg ? msg + " · " : "") + `${n} estudios revisados · ${s.informes} informes guardados` + (s.errores ? ` · ${s.errores} errores` : "") + (s.sinTexto ? ` · ${s.sinTexto} PDF sin secciones reconocidas` : "");
    $(".panel").classList.toggle("grabando", corriendo);
    $(".iniciar .lbl").textContent = corriendo ? "Importando…" : `Importar lote de ${TAM_LOTE}`;
    $(".todos").disabled = corriendo;
  }
  const aviso = (t) => { $(".aviso").textContent = t || ""; };

  // ------------------------------------------------------------ lectura del listado
  function filasPagina() {
    const t = document.getElementById("gData");
    if (!t) return [];
    let nodos;
    try { nodos = new window.DataTable("#gData").rows().nodes().toArray(); } catch (_) { nodos = [...t.tBodies[0].rows]; }
    return nodos.map((tr) => {
      const b = tr.querySelector("td b[id]");
      const td = tr.querySelectorAll("td");
      const id = b && b.id.split("-")[1];
      const acceso = td[4] && td[4].innerText.trim();
      return id && acceso ? { id, acceso } : null;
    }).filter(Boolean);
  }
  const primeraFila = () => (filasPagina()[0] || {}).id || "";

  async function siguientePagina() {
    const btn = document.getElementById("siguiente");
    if (!btn || /disabled/.test(btn.className)) return false;
    const antes = primeraFila();
    btn.click();
    for (let i = 0; i < 60; i++) {          // hasta 30 s
      await pausa(500);
      const ahora = primeraFila();
      if (ahora && ahora !== antes) return true;
    }
    return false;
  }

  // ------------------------------------------------------------ un estudio
  function aBase64(buf) {
    const bytes = new Uint8Array(buf); let bin = "";
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(bin);
  }

  async function procesar(f, s) {
    const url = "ListaExamen.aspx/InformarResumido?id_ris_examen=" + encodeURIComponent(f.id) +
      "&numeroacceso=" + encodeURIComponent('"' + f.acceso + '"');
    const r = await fetch(url, { credentials: "include", headers: { "Content-Type": "application/json; charset=utf-8" } });
    if (!r.ok) throw new Error("RIS respondió " + r.status);
    const j = await r.json();
    const lista = Array.isArray(j.d) ? j.d : [j.d];
    const div = document.createElement("div");
    div.innerHTML = lista.map((o) => (o && o.tablaInformes) || "").join("");
    const enlaces = [...new Set([...div.querySelectorAll('a[href*="VerInforme.aspx"]')].map((a) => a.getAttribute("href").replace(/&amp;/g, "&")))];
    for (const href of enlaces) {
      const pdf = await fetch(new URL(href, location.href), { credentials: "include" });
      if (!pdf.ok || !/pdf/i.test(pdf.headers.get("content-type") || "")) continue;
      const idInforme = (href.match(/idinforme=(\d+)/i) || [])[1] || "";
      const res = await api("/importar", { id_informe: idInforme, pdf: aBase64(await pdf.arrayBuffer()) });
      if (res && res.guardado) s.informes++;
      else if (res && res.motivo !== "ya importado") { s.sinTexto = (s.sinTexto || 0) + 1; console.log("[VozRad] informe no leído:", res.motivo); }
      await pausa(150);
    }
  }

  // ------------------------------------------------------------ lote
  function totalEstimado() {
    const e = document.getElementById("hddTotalRegister");
    const n = e ? parseInt(e.value, 10) : NaN;
    return Number.isFinite(n) && n > 0 ? n : null;
  }
  const fmtTiempo = (seg) => seg >= 3600 ? `${Math.floor(seg / 3600)} h ${Math.round((seg % 3600) / 60)} min` : `${Math.max(1, Math.round(seg / 60))} min`;

  async function lote(cantidad) {
    if (corriendo) return;
    try { await api("/estado"); } catch (_) { aviso("El servidor VozRad no está encendido (abre «iniciar» de VozRad)."); return; }
    corriendo = true; aviso("");
    const todos = cantidad === TODOS;
    const limite = todos ? Infinity : cantidad;
    const pausaMs = todos ? PAUSA_TODOS_MS : PAUSA_MS;
    const s = await leer();
    s.pendienteLote = cantidad; await guardar(s);
    let hechos = 0, final = "", seguidos = 0;
    const t0 = Date.now();
    try {
      while (corriendo && hechos < limite) {
        const filas = filasPagina().filter((f) => !s.hechos[f.id]);
        for (const f of filas) {
          if (!corriendo || hechos >= limite) break;
          try { await procesar(f, s); s.hechos[f.id] = 1; seguidos = 0; }
          catch (e) {
            s.errores++; seguidos++;
            aviso("Error en un estudio: " + e.message);
            if (/40[13]/.test(e.message) || seguidos >= 5) {
              corriendo = false;
              final = "Me detuve: varios errores seguidos (¿se venció la sesión del RIS?). Vuelve a entrar y pulsa de nuevo; sigo donde quedé";
            }
          }
          hechos++;
          if (!todos) s.pendienteLote = cantidad - hechos;
          await guardar(s);
          const total = totalEstimado();
          const revisados = Object.keys(s.hechos).length;
          let progreso = todos ? `importando todo: ${revisados}${total ? " de ~" + total : ""}` : `lote ${hechos}/${cantidad}`;
          if (todos && total && hechos >= 5) {
            const porEstudio = (Date.now() - t0) / 1000 / hechos;
            progreso += ` · faltan ~${fmtTiempo(Math.max(0, total - revisados) * porEstudio)}`;
          }
          await pintar(progreso);
          await pausa(pausaMs);
        }
        if (!corriendo || hechos >= limite) break;
        if (!(await siguientePagina())) { final = todos ? "¡Listo! Se recorrió todo el listado ✓" : "Llegaste al final del listado (o no pude pasar de página)"; break; }
      }
    } finally {
      corriendo = false;
      s.pendienteLote = 0; await guardar(s);
      await pintar(final || (hechos >= limite ? "Lote terminado ✓" : "Detenido"));
      if (todos && /Listo/.test(final)) aviso("Ahora ejecuta generar_perfil y reinicia «iniciar» para usar todos tus informes.");
    }
  }

  $(".iniciar").onclick = () => lote(TAM_LOTE);
  $(".todos").onclick = () => lote(TODOS);
  $(".detener").onclick = () => { corriendo = false; aviso("Se detiene al terminar el estudio actual."); };
  $(".reiniciar").onclick = async () => {
    if (corriendo) return;
    const b = $(".reiniciar");
    if (!b.dataset.ok) { b.dataset.ok = "1"; b.textContent = "¿Seguro? clic otra vez"; setTimeout(() => { delete b.dataset.ok; b.textContent = "Reiniciar contador"; }, 4000); return; }
    await guardar({ hechos: {}, informes: 0, errores: 0, pendienteLote: 0 }); delete b.dataset.ok; b.textContent = "Reiniciar contador"; pintar();
  };

  async function arrancar() {
    for (let i = 0; i < 30 && !document.getElementById("gData"); i++) await dormir(500);
    if (!document.getElementById("gData")) return;
    document.documentElement.appendChild(host);
    try { await api("/estado"); $(".servidor").classList.add("ok"); $(".servidor").textContent = "motor listo"; }
    catch (_) { $(".servidor").textContent = "motor apagado"; }
    await pintar();
    // si la página se recargó a mitad de un lote, continúa sola
    const s = await leer();
    if (s.pendienteLote > 0 || s.pendienteLote === TODOS) { $(".panel").classList.remove("minimizado"); aviso("Continuando la importación interrumpida…"); await dormir(2000); lote(s.pendienteLote); }
  }
  arrancar();
})();

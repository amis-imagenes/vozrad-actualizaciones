// VozRad - puente con la página de MultiRisWeb (corre en el contexto de la página, "MAIN world").
// Es la única parte que toca el editor CKEditor del RIS. Recibe órdenes de content.js
// por window.postMessage y responde por el mismo canal.
(() => {
  "use strict";
  if (window.__vozradBridge) return;
  window.__vozradBridge = true;

  const TAG = "__vozrad";
  let cursorManual = {};
  let rangoGuardado = {};    // campo -> último cursor dentro del editor (por si el foco se va a otro lado)
  let ultimaSeleccion = { texto: "", campo: "", t: 0 };
  let ultimaInsercion = { campo: "", texto: "", t: 0, origen: "" };   // para "Entrenar palabra" y "Frase tipo"
  let propios = new Set();   // epónimos que siempre van con mayúscula (desde nombres_propios.txt)   // campo -> true si el usuario hizo clic dentro (inserta en el cursor, no al final)

  const editores = () => (window.CKEDITOR && window.CKEDITOR.instances) ? window.CKEDITOR.instances : {};
  const porPrefijo = (prefijo) => {
    const inst = editores();
    const nombre = Object.keys(inst).find((k) => k.startsWith(prefijo));
    return nombre ? inst[nombre] : null;
  };
  const textoDe = (ed) => {
    try { return (ed.editable().$.innerText || "").replace(/ /g, " ").replace(/​/g, ""); }
    catch (_) { return ""; }
  };

  // Texto de un rango del editor, con los <br> (salto de línea simple) convertidos en "\n".
  // Sin esto, tras un salto de línea simple el texto anterior parecía continuar en la misma línea
  // y se agregaba un espacio al inicio de la línea nueva.
  function textoDeRango(rr) {
    const div = document.createElement("div");
    div.appendChild(rr.cloneContents().$);
    div.querySelectorAll("br").forEach((b) => b.replaceWith("\n"));
    return (div.textContent || "").replace(/\u00a0/g, " ").replace(/\u200b/g, "");
  }

  // Texto del mismo párrafo que está justo antes del cursor.
  function antesDelCursor(ed) {
    try {
      const r = ed.getSelection().getRanges()[0];
      const path = new CKEDITOR.dom.elementPath(r.startContainer, ed.editable());
      const bloque = path.block || path.blockLimit || ed.editable();
      const rr = ed.createRange();
      rr.setStartAt(bloque, CKEDITOR.POSITION_AFTER_START);
      rr.setEnd(r.startContainer, r.startOffset);
      return textoDeRango(rr);
    } catch (_) {
      return textoDe(ed);
    }
  }

  // Texto del mismo párrafo justo DESPUÉS del cursor (para no dejar palabras pegadas al insertar en medio).
  function despuesDelCursor(ed) {
    try {
      const r = ed.getSelection().getRanges()[0];
      const path = new CKEDITOR.dom.elementPath(r.endContainer, ed.editable());
      const bloque = path.block || path.blockLimit || ed.editable();
      const rr = ed.createRange();
      rr.setStart(r.endContainer, r.endOffset);
      rr.setEndAt(bloque, CKEDITOR.POSITION_BEFORE_END);
      return textoDeRango(rr).replace(/\n$/, "");          // el <br> de relleno del final no cuenta
    } catch (_) {
      return "";
    }
  }

  // Ajusta espacio inicial y mayúscula según el texto que hay justo antes del punto de inserción.
  function prepararCon(previoCrudo, t) {
    const previo = previoCrudo.replace(/\s+$/, (m) => (m.includes("\n") ? "\n" : m ? " " : ""));
    const vacio = previo.trim() === "";
    const abreviatura = /\b(?:vs|aprox|dr|dra|sr|sra|ej|cf)\.\s*$/i.test(previo);   // «hemangioma vs.» + «metástasis»
    const finFrase = vacio || (/[.?!:]\s*$/.test(previo) && !abreviatura) || /\n$/.test(previo);
    if (t.startsWith("\n")) return t;
    t = t.replace(/^\s+/, "");
    if (finFrase && !/^[,.;:)]/.test(t)) t = t.charAt(0).toUpperCase() + t.slice(1);
    else if (!finFrase) {
      // continúa una frase (p.ej. después de una coma): el motor puso mayúscula, se quita
      // incluye palabras de una letra ("Y", "A", "O"), pero no siglas (TC) ni niveles (L4, C5)
      const m = t.match(/^([A-ZÁÉÍÓÚÑ])([a-záéíóúñü]*)(?=$|[\s,.;:)])/);
      const palabra = m ? (m[1] + m[2]) : "";
      const letraSuelta = palabra.length === 1 && !"YAOEU".includes(palabra);
      if (m && !letraSuelta && !propios.has(palabra.toLowerCase())) t = m[1].toLowerCase() + t.slice(1);
    }
    if (!vacio && !/[\s(\n]$/.test(previo) && !/^[,.;:)\s]/.test(t)) t = " " + t;
    return t;
  }
  function prepararTexto(ed, t) { return prepararCon(antesDelCursor(ed), t); }

  // Texto de un rango nativo del DOM, con <br> como "\n".
  function textoNativo(rango) {
    const div = rango.startContainer.ownerDocument.createElement("div");
    div.appendChild(rango.cloneContents());
    div.querySelectorAll("br").forEach((b) => b.replaceWith("\n"));
    return (div.textContent || "").replace(/\u00a0/g, " ").replace(/\u200b/g, "");
  }
  const BLOQUES = /^(P|DIV|LI|TD|TH|H[1-6]|BLOCKQUOTE|PRE|BODY)$/;

  // Escribe una parte en el punto REAL de inserción: primero se inserta una marca invisible donde
  // el editor va a escribir y se mira el texto alrededor de ESA marca (la selección del editor puede
  // estar desactualizada si el foco se fue a otra ventana), y luego se reemplaza la marca por el texto.
  const MARCA = "\u2063";
  function escribirParte(ed, parte, ultima) {
    ed.insertText(MARCA);
    const raiz = ed.editable().$;
    const doc = raiz.ownerDocument;
    const tw = doc.createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
    let nodo = null, idx = -1;
    for (let n = tw.nextNode(); n; n = tw.nextNode()) { const k = n.data.indexOf(MARCA); if (k >= 0) { nodo = n; idx = k; } }
    if (!nodo) { const listo = prepararTexto(ed, parte); ed.insertText(listo); return { previo: "", listo }; }   // por si acaso
    let bloque = nodo.parentNode;
    while (bloque && bloque !== raiz && !BLOQUES.test(bloque.nodeName)) bloque = bloque.parentNode;
    bloque = bloque || raiz;
    const r1 = doc.createRange(); r1.setStart(bloque, 0); r1.setEnd(nodo, idx);
    const previo = textoNativo(r1);
    const r2 = doc.createRange(); r2.setStart(nodo, idx + 1); r2.setEnd(bloque, bloque.childNodes.length);
    const despues = textoNativo(r2).replace(/\n$/, "");
    let listo = prepararCon(previo, parte);
    if (ultima && !/\s$/.test(listo) && /^[A-Za-zÁÉÍÓÚÑáéíóúñü0-9(]/.test(despues)) listo += " ";
    // un espacio al inicio/fin de un trozo de texto se vería pegado: va como espacio duro
    const visible = listo.replace(/^ /, /\S$/.test(nodo.data.slice(0, idx)) ? " " : "\u00a0").replace(/ $/, "\u00a0");
    nodo.data = nodo.data.slice(0, idx) + visible + nodo.data.slice(idx + 1);
    // quitar marcas que hubieran quedado de antes
    const tw2 = doc.createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
    for (let n = tw2.nextNode(); n; n = tw2.nextNode()) if (n !== nodo && n.data.includes(MARCA)) n.data = n.data.split(MARCA).join("");
    try {
      const r = ed.createRange();
      r.setStart(new CKEDITOR.dom.text(nodo), Math.min(idx + visible.length, nodo.data.length));
      r.collapse(true);
      ed.getSelection().selectRanges([r]);
    } catch (_) {}
    return { previo, listo };
  }

  // ¿el cursor actual está dentro de este editor?
  function rangoValido(ed) {
    try {
      const r = ed.getSelection() && ed.getSelection().getRanges()[0];
      if (!r) return null;
      const ed0 = ed.editable();
      return (ed0.equals(r.startContainer) || ed0.contains(r.startContainer)) ? r : null;
    } catch (_) { return null; }
  }
  function guardarRango(ed, campo) {
    const r = rangoValido(ed);
    if (r) rangoGuardado[campo] = r.clone();
  }

  function alFinal(ed, campo) {
    if (cursorManual[campo]) {
      // hiciste clic en la plantilla: escribir AHÍ aunque el foco esté ahora en otra parte (panel, otro campo, otra ventana)
      if (!ed.focusManager.hasFocus) { try { ed.focus(); } catch (_) {} }
      if (!rangoValido(ed) && rangoGuardado[campo]) {
        try { ed.getSelection().selectRanges([rangoGuardado[campo]]); } catch (_) {}
      }
    }
    const sel = ed.getSelection();
    if (!cursorManual[campo] || !sel || !sel.getRanges().length || !rangoValido(ed)) {
      const r = ed.createRange();
      r.moveToElementEditEnd(ed.editable());
      ed.getSelection().selectRanges([r]);
    }
  }

  // Salto de línea real del editor (igual que apretar Enter), no un "\n" dentro del texto.
  function salto(ed) {
    try { ed.execCommand("enter"); } catch (_) { ed.insertHtml("<br>"); }
  }

  function insertar(ed, campo, t) {
    if (!t) return null;
    let diag = null;
    ed.fire("saveSnapshot");                       // un "deshacer" = una frase dictada
    alFinal(ed, campo);
    const partes = t.split("\n");
    partes.forEach((parte, i) => {
      if (i > 0) salto(ed);
      if (!parte.trim()) return;
      const visto = antesDelCursor(ed);            // lo que el editor DICE que hay antes del cursor (solo para el diagnóstico)
      const { previo, listo } = escribirParte(ed, parte, i === partes.length - 1);
      if (i === 0 && visto.replace(/\s+/g, " ").trim().slice(-25) !== previo.replace(/\s+/g, " ").trim().slice(-25)) {
        diag = { previo: visto.slice(-40), listo: listo.slice(0, 40), real: previo.slice(-60), manual: !!cursorManual[campo], ok: false, corregido: true };
      }
    });
    guardarRango(ed, campo);                       // la próxima frase sigue desde aquí
    ed.fire("saveSnapshot");
    ed.fire("change");
    return diag;
  }

  function resaltar(prefijoActivo) {
    const inst = editores();
    for (const k of Object.keys(inst)) {
      const c = inst[k].container && inst[k].container.$;
      if (!c) continue;
      const activo = prefijoActivo && k.startsWith(prefijoActivo);
      c.style.outline = activo ? "3px solid #e0533d" : "";
      c.style.outlineOffset = activo ? "1px" : "";
      c.style.transition = "outline-color .2s";
    }
  }

  function engancharFoco(campos) {
    // Si haces clic en un campo, ese pasa a ser el campo activo del dictado.
    for (const [clave, info] of Object.entries(campos)) {
      const ed = porPrefijo(info.prefijo);
      if (!ed || ed.__vozrad) continue;
      ed.__vozrad = true;
      const guardarSel = () => {
        try {
          const t = (ed.getSelection() && ed.getSelection().getSelectedText() || "").replace(/\u00a0/g, " ").trim();
          if (t) ultimaSeleccion = { texto: t, campo: clave, t: Date.now() };
        } catch (_) {}
      };
      ed.on("selectionChange", guardarSel);
      // hiciste clic o te moviste con el teclado dentro del campo: el dictado va donde dejaste el cursor
      const alUsar = () => { cursorManual[clave] = true; setTimeout(() => { guardarSel(); guardarRango(ed, clave); }, 0); };
      const enganchar = () => { ed.editable().attachListener(ed.document, "mouseup", alUsar); ed.editable().attachListener(ed.document, "keyup", alUsar); };
      ed.on("contentDom", enganchar);
      try { enganchar(); } catch (_) {}
      ed.on("focus", () => {
        cursorManual[clave] = true;
        window.postMessage({ [TAG]: "evento", tipo: "foco", campo: clave }, location.origin);
      });
    }
  }

  const ops = {
    seleccion: () => (Date.now() - ultimaSeleccion.t < 5 * 60 * 1000 ? ultimaSeleccion : { texto: "", campo: "" }),

    ping: () => ({ ckeditor: !!window.CKEDITOR, instancias: Object.keys(editores()) }),

    preparar: ({ campos, nombresPropios }) => {
      engancharFoco(campos);
      propios = new Set((nombresPropios || []).map((w) => w.toLowerCase()));
      return true;
    },

    activar: ({ campo, prefijo, desdeClic }) => {
      if (!desdeClic) { cursorManual = {}; rangoGuardado = {}; }   // cambiar de campo por voz/botón: escribe al final
      resaltar(prefijo);
      return true;
    },

    contexto: ({ prefijo }) => { const ed = porPrefijo(prefijo); return ed ? textoDe(ed).slice(-250) : ""; },

    insertar: ({ campo, prefijo, texto, origen }) => {
      const ed = porPrefijo(prefijo);
      if (!ed) return { error: "campo no encontrado" };
      if (ed.readOnly) return { error: "el campo está bloqueado (solo lectura)" };
      // la misma frase al mismo campo dos veces en < 3 s: se escribe una sola vez
      const ahora = Date.now();
      if (ultimaInsercion.campo === campo && ultimaInsercion.texto === texto && texto.length > 25 && ahora - ultimaInsercion.t < 3000) {
        return { repetida: true, antes: ultimaInsercion.origen, ahora: origen || "" };
      }
      ultimaInsercion = { campo, texto, t: ahora, origen: origen || "" };
      const diag = insertar(ed, campo, texto);
      return diag ? { ok: true, diag } : true;
    },

    // Plantilla: llena varios campos. Si el campo está vacío lo llena; si tiene texto, agrega al final.
    // contenido[campo] puede ser texto, o {texto, html} (plantillas importadas del RIS, con su formato)
    plantilla: ({ contenido, campos }) => {
      for (const [clave, v] of Object.entries(contenido)) {
        if (!campos[clave]) continue;
        const ed = porPrefijo(campos[clave].prefijo);
        if (!ed || ed.readOnly) continue;
        const t = typeof v === "string" ? v : (v && v.texto) || "";
        const html = typeof v === "object" && v ? v.html : "";
        const vacio = textoDe(ed).trim() === "";
        if (clave === "titulo" && !vacio) continue;        // no duplicar el título que ya trae el RIS
        if (html) {
          ed.fire("saveSnapshot");
          alFinal(ed, clave);
          if (!vacio) salto(ed);
          ed.insertHtml(html);
          ed.fire("saveSnapshot"); ed.fire("change");
        } else if (t) {
          insertar(ed, clave, vacio ? t : "\n" + t);
        }
      }
      return true;
    },

    salto: ({ campo, prefijo, punto }) => {
      const ed = porPrefijo(prefijo);
      if (!ed || ed.readOnly) return { error: "campo no disponible" };
      ed.fire("saveSnapshot");
      alFinal(ed, campo);
      if (punto && /[^\s.:;?!]\s*$/.test(antesDelCursor(ed))) ed.insertText(".");
      salto(ed);
      ed.fire("saveSnapshot"); ed.fire("change");
      return true;
    },

    deshacer: ({ prefijo }) => {
      const ed = porPrefijo(prefijo);
      if (ed) ed.execCommand("undo");
      return true;
    },

    textos: ({ campos }) => {
      const out = {};
      for (const [clave, info] of Object.entries(campos)) {
        const ed = porPrefijo(info.prefijo);
        if (ed) out[clave] = textoDe(ed);
      }
      return out;
    },
  };

  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data || e.data[TAG] !== "req") return;
    const { id, op, args } = e.data;
    let resultado, error;
    try { resultado = ops[op] ? ops[op](args || {}) : undefined; if (!ops[op]) error = "op desconocida"; }
    catch (err) { error = String(err && err.message || err); }
    window.postMessage({ [TAG]: "res", id, resultado, error }, location.origin);
  });
})();

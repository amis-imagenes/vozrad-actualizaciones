"""
VozRad - modelo de lenguaje radiológico.

Cuenta qué palabras (y pares y tríos de palabras) aparecen en TUS informes, plantillas, frases tipo y
correcciones. El motor de voz lo consulta MIENTRAS reconoce: entre varias opciones que suenan parecido,
prefiere la que es más probable en un informe radiológico («lobulado» antes que «López»).

  python lenguaje.py            -> construye perfil/lenguaje.json.gz
  lenguaje.MODELO.logp(palabra, contexto) -> log-probabilidad (natural)

Solo guarda conteos de palabras; los informes se limpian antes (sin nombres, RUT, fechas ni pie del PDF).
Las palabras de comando dictadas (punto, coma, nueva línea…) no cuentan: el motor las oye pero no
son parte del texto del informe.
"""
import collections
import gzip
import json
import math
import re
import time
import unicodedata
from pathlib import Path

BASE = Path(__file__).resolve().parent
ARCHIVO = BASE / "perfil" / "lenguaje.json.gz"
VERSION = 1

NUMEROS = {"cero", "un", "uno", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez",
           "once", "doce", "trece", "catorce", "quince", "dieciseis", "diecisiete", "dieciocho", "diecinueve",
           "veinte", "veintiun", "veintiuno", "veintiuna", "veintidos", "veintitres", "veinticuatro", "veinticinco",
           "veintiseis", "veintisiete", "veintiocho", "veintinueve", "treinta", "cuarenta", "cincuenta", "sesenta",
           "setenta", "ochenta", "noventa", "cien", "ciento", "doscientos", "trescientos", "cuatrocientos",
           "quinientos", "mil"}
ROMANOS = {"i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x", "xi", "xii"}
COMANDOS = {"punto", "coma", "nueva", "linea", "aparte", "parrafo", "seguido", "abre", "cierra", "abrir", "cerrar",
            "parentesis", "comillas", "comilla", "guion", "puntos"}
UNIDADES = {"mm": "milimetros", "cm": "centimetros", "ml": "mililitros", "cc": "cc", "uh": "uh", "x": "por"}


def _sin_tildes(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def normalizar(palabra: str):
    """Palabra tal como la usa el modelo (minúscula, sin tildes; números -> <n>). None = no cuenta."""
    w = _sin_tildes(palabra.lower()).strip(".,;:()\"'¿?¡!-")
    if not w:
        return None
    if w.isdigit() or re.fullmatch(r"\d+[.,]?\d*", w) or w in NUMEROS:
        return "<n>"
    if w in COMANDOS:
        return None
    if w in UNIDADES:
        return UNIDADES[w]
    if not re.fullmatch(r"[a-zñ]+", w):
        return None
    return w


def palabras(texto: str):
    out = []
    for tok in re.findall(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+|\d+(?:[.,]\d+)?", texto or ""):
        w = normalizar(tok)
        if w:
            out.append(w)
    return out


def _textos():
    """(texto, peso) de todo lo que es «tu forma de informar»."""
    import texto as txt
    inf = BASE / "informes" / "informes.jsonl"
    if inf.exists():
        for l in inf.read_text(encoding="utf-8", errors="ignore").splitlines():
            try:
                for v in json.loads(l).get("secciones", {}).values():
                    yield txt.limpiar_informe(v), 1
            except json.JSONDecodeError:
                pass
    corr = BASE / "historial" / "correcciones_manuales.jsonl"
    if corr.exists():
        for l in corr.read_text(encoding="utf-8", errors="ignore").splitlines():
            try:
                for v in json.loads(l).get("final", {}).values():
                    yield txt.limpiar_informe(v or ""), 2
            except json.JSONDecodeError:
                pass
    pl = BASE / "plantillas.json"
    if pl.exists():
        try:
            d = json.loads(pl.read_text(encoding="utf-8"))
            for p in d.get("plantillas", {}).values():
                for v in txt.limpiar_plantilla({k: x for k, x in p.items() if not k.startswith("_")}).values():
                    yield (v.get("texto", "") if isinstance(v, dict) else v), 2
            for v in d.get("frases", {}).values():
                yield (v.get("texto", "") if isinstance(v, dict) else v), 3
        except Exception:  # noqa: BLE001
            pass
    for nombre in ("vocabulario.txt", "terminos_prioritarios.txt"):
        r = BASE / nombre
        if r.exists():
            for l in r.read_text(encoding="utf-8").splitlines():
                if l.strip() and not l.startswith("#"):
                    yield l, 3
    try:
        for a in json.loads((BASE / "correcciones.json").read_text(encoding="utf-8")).get("palabras", {}).values():
            yield str(a), 2
    except Exception:  # noqa: BLE001
        pass


def construir(destino: Path = ARCHIVO, minimo: int = 2) -> dict:
    t0 = time.time()
    uni, bi, tri = collections.Counter(), collections.Counter(), collections.Counter()
    for t, peso in _textos():
        for frase in re.split(r"[.\n;:]+", t or ""):
            ws = palabras(frase)
            if not ws:
                continue
            seq = ["<s>"] + ws
            for i, w in enumerate(seq):
                if i > 0:
                    uni[w] += peso
                    bi[(seq[i - 1], w)] += peso
                if i > 1:
                    tri[(seq[i - 2], seq[i - 1], w)] += peso
    datos = {
        "version": VERSION,
        "total": sum(uni.values()),
        "uni": dict(uni),
        "bi": {" ".join(k): c for k, c in bi.items() if c >= minimo},
        "tri": {" ".join(k): c for k, c in tri.items() if c >= minimo},
        "contexto_uni": {},
    }
    # para la parte «tras» de la probabilidad: cuántas veces aparece cada par como contexto
    ctx = collections.Counter()
    for (a, b), c in bi.items():
        ctx[a] += c
    datos["contexto_uni"] = dict(ctx)
    destino.parent.mkdir(exist_ok=True)
    with gzip.open(destino, "wt", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, separators=(",", ":"))
    print(f"[VozRad] Modelo de lenguaje: {len(uni)} palabras, {len(datos['bi'])} pares, {len(datos['tri'])} tríos "
          f"({time.time() - t0:.1f} s)", flush=True)
    return datos


class ModeloLenguaje:
    """Probabilidad con «retroceso simple» (stupid backoff): trío -> par -> palabra sola -> desconocida."""

    RETROCESO = 0.4

    def __init__(self):
        self.listo = False
        self.uni, self.bi, self.tri, self.ctx = {}, {}, {}, {}
        self.total = 1
        self._cache = {}

    def cargar(self, ruta: Path = ARCHIVO, reconstruir_si_falta: bool = True):
        if not ruta.exists():
            if not reconstruir_si_falta:
                return False
            construir(ruta)
        with gzip.open(ruta, "rt", encoding="utf-8") as f:
            d = json.load(f)
        self.uni, self.bi, self.tri = d["uni"], d["bi"], d["tri"]
        self.ctx = d.get("contexto_uni", {})
        self.total = max(1, d.get("total", 1))
        self.desconocida = math.log(0.02 / self.total)         # palabra que nunca aparece en tus informes
        self._cache = {}
        self.listo = True
        return True

    def conoce(self, w: str) -> bool:
        return w in self.uni

    def logp(self, w: str, previas=()) -> float:
        clave = (w, tuple(previas[-2:]))
        if clave in self._cache:
            return self._cache[clave]
        p = None
        a = previas[-2] if len(previas) >= 2 else "<s>" if len(previas) == 1 else None
        b = previas[-1] if previas else "<s>"
        factor = 1.0
        if a is not None:
            c3 = self.tri.get(f"{a} {b} {w}")
            c2 = self.bi.get(f"{a} {b}")
            if c3 and c2:
                p = c3 / c2
            factor = self.RETROCESO
        if p is None:
            c2 = self.bi.get(f"{b} {w}")
            cb = self.ctx.get(b) or self.uni.get(b)
            if c2 and cb:
                p = factor * c2 / cb
            else:
                factor *= self.RETROCESO
        if p is None:
            c1 = self.uni.get(w)
            r = math.log(factor * c1 / self.total) if c1 else self.desconocida
        else:
            r = math.log(p)
        if len(self._cache) > 200000:
            self._cache.clear()
        self._cache[clave] = r
        return r


MODELO = ModeloLenguaje()


if __name__ == "__main__":
    construir()

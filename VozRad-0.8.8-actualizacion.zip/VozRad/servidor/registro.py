"""
VozRad - registro de dictado para enviar a revisión.

Crea en el Escritorio  VozRad-registro-AAAA-MM-DD.txt  con todo lo dictado desde el último registro
(lo que oyó el motor -> lo que escribió VozRad). Arrástralo al chat para corregir los errores.
No incluye audio ni datos del paciente (solo las frases dictadas).
"""
import datetime as dt
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
HIST = BASE / "historial"
MARCA = HIST / "registro_ultimo.json"


def generar():
    desde = ""
    if MARCA.exists():
        desde = json.loads(MARCA.read_text(encoding="utf-8")).get("hasta", "")
    lineas, ultima, n = [], desde, 0
    for archivo in sorted(HIST.glob("20??-??-??.jsonl")):
        for l in archivo.read_text(encoding="utf-8", errors="ignore").splitlines():
            try:
                r = json.loads(l)
            except json.JSONDecodeError:
                continue
            hora = r.get("hora", "")
            if not hora or hora <= desde:
                continue
            ultima = max(ultima, hora)
            if "diagnostico" in r:
                lineas.append(f"[VozRad] ⚠ {json.dumps(r['diagnostico'], ensure_ascii=False)}")
                continue
            if "crudo" not in r:
                continue
            marca = " (Canary)" if r.get("respaldo") else ""
            lineas.append(f"[{r.get('ms', 0):>5} ms | {r.get('segundos_audio', 0):4.1f} s audio]{marca} "
                          f"{r.get('crudo', '')!r} -> {r.get('resultado')!r}")
            n += 1
    if not n:
        print("No hay frases nuevas desde el último registro.")
        return None
    escritorio = next((p for p in (Path.home() / "Desktop", Path.home() / "Escritorio") if p.exists()), BASE)
    destino = escritorio / f"VozRad-registro-{dt.date.today().isoformat()}.txt"
    i = 2
    while destino.exists():
        destino = escritorio / f"VozRad-registro-{dt.date.today().isoformat()}-{i}.txt"
        i += 1
    cabecera = f"# VozRad · registro de dictado · {n} frases · desde {desde or 'el inicio'} hasta {ultima}\n"
    destino.write_text(cabecera + "\n".join(lineas) + "\n", encoding="utf-8")
    MARCA.write_text(json.dumps({"hasta": ultima, "archivo": destino.name}, ensure_ascii=False), encoding="utf-8")
    print(f"Listo: {n} frases en\n  {destino}\nArrástralo al chat de Claude para revisar los errores.")
    return destino


if __name__ == "__main__":
    generar()

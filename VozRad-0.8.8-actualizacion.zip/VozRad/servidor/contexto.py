"""
VozRad - modelo de contexto aprendido de TUS informes.

Idea: el motor de voz conoce el idioma general; tus informes conocen tu lenguaje radiológico.
Si el motor escribe una palabra que en tus informes casi nunca aparece en ese contexto, y existe
otra palabra que SUENA parecido y que en tus informes aparece muchas veces rodeada de esas
mismas palabras, se privilegia la de tus informes.

  "no hay dilatación del conducto Wilson"  ->  "... del conducto Wirsung"
  "vaso de tamaño normal"                   ->  "bazo de tamaño normal"

Fuentes (se recargan solas cuando cambian):
  informes/informes.jsonl                  tus informes importados
  historial/correcciones_manuales.jsonl    cómo dejaste tus informes dictados (vale doble)
  plantillas.json, vocabulario.txt         tus plantillas, frases y términos entrenados

Nunca cambia números ni palabras que alteran el sentido (derecho/izquierdo, hipo/hiper, sin/con...).
"""
import collections
import difflib
import json
import re
import os
import unicodedata
from pathlib import Path

BASE = Path(__file__).resolve().parent

PROTEGIDAS = set("""
no sin con ni y o e de del la el los las un una al en por para que se su sus es son hay mas menos
derecho derecha derechos derechas izquierdo izquierda izquierdos izquierdas bilateral bilaterales
leve leves moderado moderada moderados moderadas severo severa severos severas
mayor menor superior inferior anterior posterior medial lateral proximal distal central periferico periferica
aumentado aumentada disminuido disminuida normal normales alterado alterada conservado conservada
positivo positiva negativo negativa presente ausente simple compleja complejo
agudo aguda cronico cronica antiguo antigua nuevo nueva previo previa
""".split())
PREFIJOS_PROTEGIDOS = ("hipo", "hiper", "iso", "intra", "extra", "supra", "infra", "sub", "pre", "post", "peri", "para", "ante", "retro")
VENTANA = 3


def _sin_tildes(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s.lower()) if unicodedata.category(c) != "Mn")


def fonetica(w: str) -> str:
    """Clave fonética simple para el español: cómo SUENA la palabra."""
    w = _sin_tildes(w)
    w = re.sub(r"[^a-zñ]", "", w)
    for a, b in (("qu", "k"), ("ch", "X"), ("ll", "y"), ("rr", "r"), ("gu(?=[ei])", "g"), ("c(?=[ei])", "s"),
                 ("g(?=[ei])", "j"), ("c", "k"), ("z", "s"), ("v", "b"), ("w", "u"), ("h", ""), ("x", "ks")):
        w = re.sub(a, b, w)
    return re.sub(r"(.)\1+", r"\1", w)


def _tokens(t: str):
    return re.findall(r"[A-Za-zÁÉÍÓÚÑáéíóúñü]+", t or "")


class Modelo:
    def __init__(self):
        self.firma = None
        self.uni = collections.Counter()
        self.co = collections.Counter()       # (palabra_contexto, palabra) dentro de la ventana
        self.forma = {}                       # normalizada -> forma escrita más común
        self.mayus = {}
        self.por_clave = collections.defaultdict(list)

    def _fuentes(self):
        return [BASE / "informes" / "informes.jsonl", BASE / "historial" / "correcciones_manuales.jsonl",
                BASE / "plantillas.json", BASE / "vocabulario.txt"]

    def cargar(self):
        firma = tuple((p.stat().st_mtime, p.stat().st_size) if p.exists() else 0 for p in self._fuentes())
        if firma == self.firma:
            return
        self.__init__()
        self.firma = firma
        textos = []
        inf, corr, pl, voc = self._fuentes()
        if inf.exists():
            for l in inf.read_text(encoding="utf-8", errors="ignore").splitlines():
                try:
                    textos += [(v, 1) for v in json.loads(l).get("secciones", {}).values()]
                except json.JSONDecodeError:
                    pass
        if corr.exists():
            for l in corr.read_text(encoding="utf-8", errors="ignore").splitlines():
                try:
                    textos += [(v, 2) for v in json.loads(l).get("final", {}).values()]
                except json.JSONDecodeError:
                    pass
        if pl.exists():
            try:
                d = json.loads(pl.read_text(encoding="utf-8"))
                for p in d.get("plantillas", {}).values():
                    for v in p.values():
                        t = v.get("texto") if isinstance(v, dict) else v
                        if isinstance(t, str):
                            textos.append((t, 1))
                for v in d.get("frases", {}).values():
                    textos.append((v.get("texto", "") if isinstance(v, dict) else v, 2))
            except json.JSONDecodeError:
                pass
        if voc.exists():
            textos += [(l, 1) for l in voc.read_text(encoding="utf-8").splitlines() if l and not l.startswith("#")]

        formas = collections.defaultdict(collections.Counter)
        for t, peso in textos:
            for frase in re.split(r"[.\n;:]+", t or ""):           # tras ":" también empieza con mayúscula
                toks = _tokens(frase)
                norm = [_sin_tildes(w) for w in toks]
                for i, (w, n) in enumerate(zip(toks, norm)):
                    self.uni[n] += peso
                    formas[n][w if i > 0 else w.lower()] += peso    # la 1ª palabra de la frase va con mayúscula por posición
                for i, n in enumerate(norm):
                    for j in range(max(0, i - VENTANA), min(len(norm), i + VENTANA + 1)):
                        if j != i and len(norm[j]) > 2:
                            self.co[(norm[j], n)] += peso
        self.forma = {n: c.most_common(1)[0][0] for n, c in formas.items()}
        # proporción de veces que la escribes con mayúscula a mitad de oración (Wirsung ~100 %, colelitiasis ~0 %)
        self.mayus = {n: sum(v for w, v in c.items() if w[:1].isupper()) / max(1, sum(c.values())) for n, c in formas.items()}
        for n, c in self.uni.items():
            if c >= 3 and len(n) >= 4 and not _protegida(n):
                k = fonetica(n)
                if k:
                    self.por_clave[k[0]].append((n, k, len(n)))

    def puntaje(self, palabra: str, vecinos):
        return sum(self.co.get((v, palabra), 0) for v in vecinos)


MODELO = Modelo()
_RECARGANDO = {"activo": False, "ultimo": 0.0}
MINIMO_ENTRE_RECARGAS = 20 * 60   # segundos: no competir con el dictado por el procesador


def _prioridad_baja():
    """El modelo se reconstruye sin quitarle procesador al reconocimiento de voz."""
    try:
        if os.name == "nt":
            import ctypes
            k = ctypes.windll.kernel32
            k.SetThreadPriority(k.GetCurrentThread(), -15)          # THREAD_PRIORITY_IDLE
        else:
            os.nice(10)
    except Exception:  # noqa: BLE001
        pass


def cargar_en_segundo_plano():
    """Reconstruye el modelo sin frenar el dictado (se usa el anterior mientras tanto)."""
    import threading
    import time
    if _RECARGANDO["activo"] or time.time() - _RECARGANDO["ultimo"] < MINIMO_ENTRE_RECARGAS:
        return
    _RECARGANDO["ultimo"] = time.time()

    def trabajo():
        global MODELO
        try:
            _prioridad_baja()
            nuevo = Modelo()
            nuevo.cargar()
            MODELO = nuevo
        finally:
            _RECARGANDO["activo"] = False
    _RECARGANDO["activo"] = True
    threading.Thread(target=trabajo, daemon=True).start()


def _firma_actual():
    return tuple((p.stat().st_mtime, p.stat().st_size) if p.exists() else 0 for p in MODELO._fuentes())


def _misma_palabra(a: str, b: str) -> bool:
    """riñón/riñones, quiste/quistes, hipodenso/hipodensa: misma palabra con otro número o género."""
    raiz = lambda x: re.sub(r"(ones|es|os|as|s|o|a|e)$", "", x)  # noqa: E731
    ra, rb = raiz(a), raiz(b)
    return ra == rb or a.startswith(b) or b.startswith(a) or (len(ra) > 3 and (ra.startswith(rb) or rb.startswith(ra)))


_ZIPF = {}


def _zipf(n: str) -> float:
    """Frecuencia de la palabra en español (0 = no existe, 7 = muy común). Se recuerda por palabra."""
    if n not in _ZIPF:
        try:
            from wordfreq import zipf_frequency
            _ZIPF[n] = max(zipf_frequency(n, "es"), zipf_frequency(MODELO.forma.get(n, n), "es"))
        except Exception:  # noqa: BLE001
            _ZIPF[n] = 0.0
    return _ZIPF[n]


def _protegida(n: str) -> bool:
    return n in PROTEGIDAS or n.startswith(PREFIJOS_PROTEGIDOS) or len(n) < 4


def corregir(t: str) -> str:
    """Reemplaza palabras improbables por la alternativa que suena parecido y que tus informes respaldan."""
    try:
        if MODELO.firma is None:
            MODELO.cargar()                       # primera vez (normalmente ya se hizo al iniciar)
        elif _firma_actual() != MODELO.firma:
            cargar_en_segundo_plano()             # cambiaron tus informes: se actualiza sin esperar
    except Exception:  # noqa: BLE001
        return t
    if not MODELO.uni:
        return t
    spans = [(m.start(), m.end(), m.group(0)) for m in re.finditer(r"[A-Za-zÁÉÍÓÚÑáéíóúñü]+", t)]
    norm = [_sin_tildes(w) for _, _, w in spans]
    cambios = []
    for i, (a, b, w) in enumerate(spans):
        n = norm[i]
        if _protegida(n):
            continue
        vecinos = [x for x in norm[max(0, i - VENTANA):i] + norm[i + 1:i + 1 + VENTANA] if len(x) > 2]
        if not vecinos:
            continue
        actual = MODELO.puntaje(n, vecinos)
        if MODELO.uni.get(n, 0) >= 20 and actual > 0:
            continue                                   # palabra tuya y bien acompañada: no tocar
        k = fonetica(n)
        if not k:
            continue
        frec = _zipf(n)
        if frec >= 4.5:
            continue                                   # palabra muy común (como, pero, desde…): nunca se cambia
        # palabra real del español que TÚ usas (anexo): solo se cambia si suena casi igual.
        # si no aparece en tus informes (Wilson en "conducto de Wilson"), basta con que suene parecido.
        # (un nombre con mayúscula que no usas —«conducto de Wilson»— sí puede cambiarse por lo que suena parecido)
        nombre_ajeno = w[:1].isupper() and MODELO.uni.get(n, 0) < 3 and i > 0
        umbral_sonido = 0.8 if frec >= 2.5 and not nombre_ajeno else 0.6
        if frec < 2.5 and len(n) >= 9:
            umbral_sonido = 0.7                        # palabras largas inventadas: exigir algo más de parecido
        mejor, mejor_p = None, 0
        largo = len(n)
        sm = difflib.SequenceMatcher(None, k, "")
        for c, kc, lc in MODELO.por_clave.get(k[0], ()):
            if abs(lc - largo) > 3 or c == n:
                continue
            p = MODELO.puntaje(c, vecinos)                  # barato: si tus informes no la respaldan, ni se compara
            if p < 3 or p <= mejor_p or p < 5 * (actual + 0.5):
                continue
            sm.set_seq2(kc)
            if sm.real_quick_ratio() < umbral_sonido or sm.quick_ratio() < umbral_sonido or sm.ratio() < umbral_sonido or _misma_palabra(n, c):
                continue
            if p > mejor_p:
                mejor, mejor_p = c, p
        if mejor and mejor_p >= 3 and mejor_p >= 5 * (actual + 0.5):
            nuevo = MODELO.forma.get(mejor, mejor)
            if w[:1].isupper():
                nuevo = nuevo[:1].upper() + nuevo[1:]
            cambios.append((a, b, nuevo))
    for a, b, nuevo in reversed(cambios):
        t = t[:a] + nuevo + t[b:]
    return t

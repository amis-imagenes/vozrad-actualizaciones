// VozRad - puente con la página de MultiRisWeb (corre en el contexto de la página, "MAIN world").
// Es la única parte que toca el editor CKEditor del RIS. Recibe órdenes de content.js
// por window.postMessage y responde por el mismo canal.
(() => {
  "use strict";
  if (window.__vozradBridge) return;
  window.__vozradBridge = true;

  const TAG = "__vozrad";
  let cursorManual = {};
  let ultimaSeleccion = { texto: "", campo: "", t: 0 };
  let ultimaInsercion = { campo: "", texto: "", t: 0, origen: "" };   // para "Entrenar palabra" y "Frase tipo"
  let propios = new Set();   // epónimos que siempre van con mayúscula (desde nombres_propios.txt)   // campo -> true si el usuario hizo clic dentro (inserta en el cursor, no al final)

  const editores = () => (window.CKEDITOR && window.CKEDITOR.instances) ? window.CKEDITOR.instances : {};
  const porPrefijo = (prefijo) => {
    const inst = editores();
    const nombre = Object.keys(inst).find((k) => k.startsWith(prefijo));
    return nombre ? inst[nombre] : null;
  };
  const textoDe = (ed) => {
    try { return (ed.editable().$.innerText || "").replace(/ /g, " ").replace(/​/g, ""); }
    catch (_) { return ""; }
  };

  // Texto de un rango del editor, con los <br> (salto de línea simple) convertidos en "\n".
  // Sin esto, tras un salto de línea simple el texto anterior parecía continuar en la misma línea
  // y se agregaba un espacio al inicio de la línea nueva.
  function textoDeRango(rr) {
    const div = document.createElement("div");
    div.appendChild(rr.cloneContents().$);
    div.querySelectorAll("br").forEach((b) => b.replaceWith("\n"));
    return (div.textContent || "").replace(/\u00a0/g, " ").replace(/\u200b/g, "");
  }

  // Texto del mismo párrafo que está justo antes del cursor.
  function antesDelCursor(ed) {
    try {
      const r = ed.getSelection().getRanges()[0];
      const path = new CKEDITOR.dom.elementPath(r.startContainer, ed.editable());
      const bloque = path.block || path.blockLimit || ed.editable();
      const rr = ed.createRange();
      rr.setStartAt(bloque, CKEDITOR.POSITION_AFTER_START);
      rr.setEnd(r.startContainer, r.startOffset);
      return textoDeRango(rr);
    } catch (_) {
      return textoDe(ed);
    }
  }

  // Texto del mismo párrafo justo DESPUÉS del cursor (para no dejar palabras pegadas al insertar en medio).
  function despuesDelCursor(ed) {
    try {
      const r = ed.getSelection().getRanges()[0];
      const path = new CKEDITOR.dom.elementPath(r.endContainer, ed.editable());
      const bloque = path.block || path.blockLimit || ed.editable();
      const rr = ed.createRange();
      rr.setStart(r.endContainer, r.endOffset);
      rr.setEndAt(bloque, CKEDITOR.POSITION_BEFORE_END);
      return textoDeRango(rr).replace(/\n$/, "");          // el <br> de relleno del final no cuenta
    } catch (_) {
      return "";
    }
  }

  function prepararTexto(ed, t) {
    // Ajusta espacio inicial y mayúscula según lo que hay justo antes del cursor.
    const previo = antesDelCursor(ed).replace(/\s+$/, (m) => (m.includes("\n") ? "\n" : m ? " " : ""));
    const vacio = previo.trim() === "";
    const finFrase = vacio || /[.?!:]\s*$/.test(previo) || /\n$/.test(previo);
    if (t.startsWith("\n")) return t;
    if (finFrase && !/^[,.;:)]/.test(t)) t = t.charAt(0).toUpperCase() + t.slice(1);
    else if (!finFrase) {
      // continúa una frase (p.ej. después de una coma): el motor puso mayúscula, se quita
      // incluye palabras de una letra ("Y", "A", "O"), pero no siglas (TC) ni niveles (L4, C5)
      const m = t.match(/^([A-ZÁÉÍÓÚÑ])([a-záéíóúñü]*)(?=$|[\s,.;:)])/);
      const palabra = m ? (m[1] + m[2]) : "";
      const letraSuelta = palabra.length === 1 && !"YAOEU".includes(palabra);
      if (m && !letraSuelta && !propios.has(palabra.toLowerCase())) t = m[1].toLowerCase() + t.slice(1);
    }
    if (!vacio && !/[\s(]$/.test(previo) && !/^[,.;:)\s]/.test(t)) t = " " + t;
    return t;
  }

  function alFinal(ed, campo) {
    const sel = ed.getSelection();
    if (!cursorManual[campo] || !sel || !sel.getRanges().length) {
      const r = ed.createRange();
      r.moveToElementEditEnd(ed.editable());
      ed.getSelection().selectRanges([r]);
    }
  }

  // Salto de línea real del editor (igual que apretar Enter), no un "\n" dentro del texto.
  function salto(ed) {
    try { ed.execCommand("enter"); } catch (_) { ed.insertHtml("<br>"); }
  }

  function insertar(ed, campo, t) {
    if (!t) return;
    ed.fire("saveSnapshot");                       // un "deshacer" = una frase dictada
    alFinal(ed, campo);
    const partes = t.split("\n");
    partes.forEach((parte, i) => {
      if (i > 0) salto(ed);
      if (!parte.trim()) return;
      const listo = prepararTexto(ed, parte);
      ed.insertText(listo);
      // insertado en medio de una frase (plantilla): separar de la palabra que sigue
      if (i === partes.length - 1 && !/\s$/.test(listo) && /^[A-Za-zÁÉÍÓÚÑáéíóúñü0-9(]/.test(despuesDelCursor(ed))) ed.insertText(" ");
    });
    ed.fire("saveSnapshot");
    ed.fire("change");
  }

  function resaltar(prefijoActivo) {
    const inst = editores();
    for (const k of Object.keys(inst)) {
      const c = inst[k].container && inst[k].container.$;
      if (!c) continue;
      const activo = prefijoActivo && k.startsWith(prefijoActivo);
      c.style.outline = activo ? "3px solid #e0533d" : "";
      c.style.outlineOffset = activo ? "1px" : "";
      c.style.transition = "outline-color .2s";
    }
  }

  function engancharFoco(campos) {
    // Si haces clic en un campo, ese pasa a ser el campo activo del dictado.
    for (const [clave, info] of Object.entries(campos)) {
      const ed = porPrefijo(info.prefijo);
      if (!ed || ed.__vozrad) continue;
      ed.__vozrad = true;
      const guardarSel = () => {
        try {
          const t = (ed.getSelection() && ed.getSelection().getSelectedText() || "").replace(/\u00a0/g, " ").trim();
          if (t) ultimaSeleccion = { texto: t, campo: clave, t: Date.now() };
        } catch (_) {}
      };
      ed.on("selectionChange", guardarSel);
      // hiciste clic o te moviste con el teclado dentro del campo: el dictado va donde dejaste el cursor
      const alUsar = () => { cursorManual[clave] = true; setTimeout(guardarSel, 0); };
      const enganchar = () => { ed.editable().attachListener(ed.document, "mouseup", alUsar); ed.editable().attachListener(ed.document, "keyup", alUsar); };
      ed.on("contentDom", enganchar);
      try { enganchar(); } catch (_) {}
      ed.on("focus", () => {
        cursorManual[clave] = true;
        window.postMessage({ [TAG]: "evento", tipo: "foco", campo: clave }, location.origin);
      });
    }
  }

  const ops = {
    seleccion: () => (Date.now() - ultimaSeleccion.t < 5 * 60 * 1000 ? ultimaSeleccion : { texto: "", campo: "" }),

    ping: () => ({ ckeditor: !!window.CKEDITOR, instancias: Object.keys(editores()) }),

    preparar: ({ campos, nombresPropios }) => {
      engancharFoco(campos);
      propios = new Set((nombresPropios || []).map((w) => w.toLowerCase()));
      return true;
    },

    activar: ({ campo, prefijo, desdeClic }) => {
      if (!desdeClic) cursorManual = {};          // cambiar de campo por voz/botón: escribe al final
      resaltar(prefijo);
      return true;
    },

    contexto: ({ prefijo }) => { const ed = porPrefijo(prefijo); return ed ? textoDe(ed).slice(-250) : ""; },

    insertar: ({ campo, prefijo, texto, origen }) => {
      const ed = porPrefijo(prefijo);
      if (!ed) return { error: "campo no encontrado" };
      if (ed.readOnly) return { error: "el campo está bloqueado (solo lectura)" };
      // la misma frase al mismo campo dos veces en < 3 s: se escribe una sola vez
      const ahora = Date.now();
      if (ultimaInsercion.campo === campo && ultimaInsercion.texto === texto && texto.length > 25 && ahora - ultimaInsercion.t < 3000) {
        return { repetida: true, antes: ultimaInsercion.origen, ahora: origen || "" };
      }
      ultimaInsercion = { campo, texto, t: ahora, origen: origen || "" };
      insertar(ed, campo, texto);
      return true;
    },

    // Plantilla: llena varios campos. Si el campo está vacío lo llena; si tiene texto, agrega al final.
    // contenido[campo] puede ser texto, o {texto, html} (plantillas importadas del RIS, con su formato)
    plantilla: ({ contenido, campos }) => {
      for (const [clave, v] of Object.entries(contenido)) {
        if (!campos[clave]) continue;
        const ed = porPrefijo(campos[clave].prefijo);
        if (!ed || ed.readOnly) continue;
        const t = typeof v === "string" ? v : (v && v.texto) || "";
        const html = typeof v === "object" && v ? v.html : "";
        const vacio = textoDe(ed).trim() === "";
        if (clave === "titulo" && !vacio) continue;        // no duplicar el título que ya trae el RIS
        if (html) {
          ed.fire("saveSnapshot");
          alFinal(ed, clave);
          if (!vacio) salto(ed);
          ed.insertHtml(html);
          ed.fire("saveSnapshot"); ed.fire("change");
        } else if (t) {
          insertar(ed, clave, vacio ? t : "\n" + t);
        }
      }
      return true;
    },

    salto: ({ campo, prefijo, punto }) => {
      const ed = porPrefijo(prefijo);
      if (!ed || ed.readOnly) return { error: "campo no disponible" };
      ed.fire("saveSnapshot");
      alFinal(ed, campo);
      if (punto && /[^\s.:;?!]\s*$/.test(textoDe(ed))) ed.insertText(".");
      salto(ed);
      ed.fire("saveSnapshot"); ed.fire("change");
      return true;
    },

    deshacer: ({ prefijo }) => {
      const ed = porPrefijo(prefijo);
      if (ed) ed.execCommand("undo");
      return true;
    },

    textos: ({ campos }) => {
      const out = {};
      for (const [clave, info] of Object.entries(campos)) {
        const ed = porPrefijo(info.prefijo);
        if (ed) out[clave] = textoDe(ed);
      }
      return out;
    },
  };

  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data || e.data[TAG] !== "req") return;
    const { id, op, args } = e.data;
    let resultado, error;
    try { resultado = ops[op] ? ops[op](args || {}) : undefined; if (!ops[op]) error = "op desconocida"; }
    catch (err) { error = String(err && err.message || err); }
    window.postMessage({ [TAG]: "res", id, resultado, error }, location.origin);
  });
})();

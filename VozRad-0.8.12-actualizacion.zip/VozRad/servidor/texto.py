"""
VozRad - post-procesamiento del texto dictado.

Convierte la transcripción cruda de Whisper en texto de informe:
  1. Detecta comandos de voz (cambiar de campo, plantillas, frases, deshacer).
  2. Aplica la puntuación dictada ("coma", "punto aparte", ...).
  3. Aplica tus correcciones (correcciones.json) y reglas de formato (cm, mm, x).
  4. Corrige mayúsculas después de punto o salto de línea.

Este módulo no depende de Whisper, así que se puede probar por separado.
"""
import collections
import difflib
import json
import re
import unicodedata
from pathlib import Path

BASE = Path(__file__).resolve().parent

# Tus archivos (config, correcciones, plantillas, vocabulario) NO vienen en los zip de VozRad:
# si falta alguno (instalación nueva) se crea desde la copia de fábrica. Así, descomprimir una
# versión nueva encima nunca borra lo que VozRad aprendió de ti.
ARCHIVOS_DE_USUARIO = ["config.json", "correcciones.json", "plantillas.json", "vocabulario.txt",
                       "terminos_prioritarios.txt", "nombres_propios.txt"]


def _asegurar_archivos_de_usuario():
    import shutil
    for nombre in ARCHIVOS_DE_USUARIO:
        destino, origen = BASE / nombre, BASE / "fabrica" / nombre
        if not destino.exists() and origen.exists():
            shutil.copy2(origen, destino)


_asegurar_archivos_de_usuario()


# ---------------------------------------------------------------- utilidades
def normalizar(s: str) -> str:
    """minúsculas, sin tildes ni puntuación, espacios simples (para comparar comandos)."""
    s = unicodedata.normalize("NFD", s.lower())
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    s = re.sub(r"[^\w\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


class ArchivoJSON:
    """Lee un JSON y lo recarga solo si el archivo cambió (puedes editarlo con el servidor andando)."""

    def __init__(self, nombre, defecto):
        self.ruta = BASE / nombre
        self.defecto = defecto
        self._mtime = None
        self._datos = defecto

    def datos(self):
        try:
            m = self.ruta.stat().st_mtime
        except FileNotFoundError:
            return self.defecto
        if m != self._mtime:
            with open(self.ruta, encoding="utf-8") as f:
                self._datos = json.load(f)
            self._mtime = m
        return self._datos


CONFIG = ArchivoJSON("config.json", {})
CORRECCIONES = ArchivoJSON("correcciones.json", {"palabras": {}, "reglas": []})
PLANTILLAS = ArchivoJSON("plantillas.json", {"plantillas": {}, "frases": {}})


def vocabulario() -> list[str]:
    ruta = BASE / "vocabulario.txt"
    if not ruta.exists():
        return []
    terminos = []
    for linea in ruta.read_text(encoding="utf-8").splitlines():
        linea = linea.strip()
        if linea and not linea.startswith("#"):
            terminos.append(linea)
    return terminos


# ---------------------------------------------------------------- puntuación dictada
# Orden importa: las frases largas primero.
PUNTUACION_DICTADA = [
    (r"punto y aparte|punto aparte|nuevo párrafo|nuevo parrafo", "\n"),
    (r"no\s+(?:hay|ha|la)\s+l[ií]n[ie]as?(?!\s+(?:de|del)\b)|(?:nueva?|nueba|nuova|nova|nueve|nuev[oe]|no\s+a|na|no|noma)\s+l[ií]n[ie]as?|l[ií]nea nueva|siguiente l[ií]nea|otra l[ií]nea|salto de l[ií]nea", "\n"),
    (r"punto y seguido|punto seguido", ". "),
    (r"punto y coma", "; "),
    (r"dos puntos", ": "),
    (r"(?:abrir|abre|abro|abra)\s+par[eé]ntesis", " ("),
    (r"(?:cerrar|cierra|cierre|cierro|cierran)\s+par[eé]ntesis", ") "),
    (r"(?:abrir|abre|abra|avere|abro)\s*comill(?:as?|illas?)", " \x01"),
    (r"(?:cerrar|cierra|cierre|cierro)\s*comill(?:as?|illas?)", "\x02 "),
    (r"signo de interrogación|signo de interrogacion", "? "),
    (r"guion|guión", " - "),
    (r"coma|coman|comas", ", "),
    (r"com(?=\s+\d)", ", "),
    (r"punto", ". "),
]
_MARCA_PARRAFO = ""  # marcador interno de salto (se resuelve al final)


def aplicar_puntuacion(texto: str, modo: str) -> str:
    """
    modo "dictada": se ignora la puntuación que Whisper agrega por su cuenta y solo
                    vale la que tú dictas ("coma", "punto", ...). Se respetan decimales.
    modo "automatica": se deja la puntuación de Whisper y además se aplica la dictada.
    """
    t = " " + texto + " "
    if modo == "dictada":
        # quita . , ; : ¿ ? ¡ ! que no estén entre dígitos (1,5  2.3 se conservan)
        t = re.sub(r"(?<!\d)[.,;:]|[.,;:](?!\d)", " ", t)
        t = re.sub(r"[¿?¡!]", " ", t)
    for patron, signo in PUNTUACION_DICTADA:
        reemplazo = signo.replace("\n", _MARCA_PARRAFO)
        # palabra completa, tolerando la puntuación que Whisper pegue alrededor
        t = re.sub(r"[\s,.;:]*\b(?:" + patron + r")\b[\s,.;:]*", lambda _m, r=reemplazo: r, t, flags=re.I)
    return t


def limpiar_espacios(t: str) -> str:
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r" +([,.;:)?\"])", r"\1", t)          # sin espacio antes de signos
    t = re.sub(r"\( +", "(", t)
    t = re.sub(r"([,.;:])(?=[^\s\d\n" + _MARCA_PARRAFO + r"])", r"\1 ", t)  # espacio después (no en decimales)
    t = re.sub(r"([,;:])\1+", r"\1", t)
    t = re.sub(r"\.{2,}", ".", t)
    t = re.sub(r"[,;:]\s*\.", ".", t)
    t = re.sub(r"\.\s*,", ".", t)
    # salto de párrafo: cierra la frase anterior con punto si no tiene
    t = re.sub(r"\s*" + _MARCA_PARRAFO + r"\s*", _MARCA_PARRAFO, t)
    t = re.sub(r"(?<=[^\s.;:,\n" + _MARCA_PARRAFO + r"])" + _MARCA_PARRAFO, "." + _MARCA_PARRAFO, t)
    t = re.sub(r"[,;]\s*" + _MARCA_PARRAFO, "." + _MARCA_PARRAFO, t)
    t = t.replace(_MARCA_PARRAFO, "\n")
    t = re.sub(r" *\n *", "\n", t)
    # comillas dictadas: «en abre comillas panal de abejas cierra comillas» -> en "panal de abejas"
    t = re.sub(r"\s*\x01\s*", ' "', t)
    t = re.sub(r"\s*\x02", '"', t)
    t = re.sub(r'"(?=[A-Za-zÁÉÍÓÚÑáéíóúñü0-9(])', lambda m: m.group(0) if t[:m.start()].count('"') % 2 == 0 else '" ', t)
    return t.strip(" ")


def _propios():
    ruta = BASE / "nombres_propios.txt"
    if not ruta.exists():
        return set()
    return {w.lower() for l in ruta.read_text(encoding="utf-8").splitlines() if not l.startswith("#") for w in l.split()}


_CACHE_MAYUS = {"firma": None, "set": set()}


def _palabras_con_mayuscula() -> set:
    """Palabras que SÍ van con mayúscula: epónimos (nombres_propios.txt) y las que en tu vocabulario
    están escritas con mayúscula (Doppler, Glisson, Hounsfield...)."""
    rutas = [BASE / "nombres_propios.txt", BASE / "vocabulario.txt", BASE / "vocabulario_base.txt",
             BASE / "terminos_prioritarios.txt"]
    firma = tuple(r.stat().st_mtime if r.exists() else 0 for r in rutas)
    if firma != _CACHE_MAYUS["firma"]:
        conj = set(_propios())
        for r in rutas[1:]:
            if r.exists():
                contenido = r.read_text(encoding="utf-8")
                if r.name == "vocabulario.txt":
                    contenido = contenido.split("# ---- automático")[0]   # la parte automática puede traer "Vesícula" de inicio de oración
                for l in contenido.splitlines():
                    if not l.startswith("#"):
                        conj |= {w.lower() for w in re.findall(r"[A-ZÁÉÍÓÚÑ][a-záéíóúñü]+", l)}
        _CACHE_MAYUS.update(firma=firma, set=conj)
    conj = _CACHE_MAYUS["set"]
    try:
        import contexto
        m = contexto.MODELO
        if m.forma and _CACHE_MAYUS.get("modelo") is not m:
            _CACHE_MAYUS["de_informes"] = {n for n, f in m.forma.items() if f[:1].isupper() and f[1:2].islower() and m.uni.get(n, 0) >= 5
                                           and getattr(m, "mayus", {}).get(n, 1) >= 0.8}
            _CACHE_MAYUS["modelo"] = m
        return conj | _CACHE_MAYUS.get("de_informes", set())
    except Exception:  # noqa: BLE001
        return conj


def _sin_tildes_simple(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def separar_pegadas(t: str) -> str:
    """«hallazgospatológicos» -> «hallazgos patológicos»: una palabra que no existe, formada por dos que usas."""
    try:
        import contexto
        uni = contexto.MODELO.uni
    except Exception:  # noqa: BLE001
        return t
    if not uni:
        return t

    def partir(m):
        w = m.group(0)
        n = _sin_tildes_simple(w.lower())
        if uni.get(n, 0) or _frecuencia_es_solo(w.lower()) >= 1:
            return w
        for corto in ("ni", "y", "de", "en", "sin", "con", "e"):
            if corto == "e" and not re.match(r"e(?:h?i)", w.lower()):
                continue
            if w.lower().startswith(corto) and uni.get(_sin_tildes_simple(w[len(corto):].lower()), 0) >= 5:
                return f"{w[:len(corto)]} {w[len(corto):]}"
        for i in range(4, len(w) - 3):
            a, b = w[:i], w[i:]
            if uni.get(_sin_tildes_simple(a.lower()), 0) >= 5 and uni.get(_sin_tildes_simple(b.lower()), 0) >= 5:
                return f"{a} {b}"
        return w
    return re.sub(r"[A-Za-zÁÉÍÓÚÑáéíóúñü]{9,}", partir, t)


def quitar_mayusculas_del_motor(t: str) -> str:
    """El motor pone mayúsculas donde ÉL cree que empieza una oración ("normal. Vesícula"). Como la
    puntuación la dictas tú, esas mayúsculas sobran: se pasan a minúscula todas salvo la primera palabra,
    epónimos/términos que escribes con mayúscula y siglas (TC, RM, L4). Después de un «punto» dictado
    se vuelve a poner mayúscula al final del proceso."""
    propias = _palabras_con_mayuscula()
    primera = [True]

    def baja(m):
        w = m.group(0)
        if primera[0] and not t[:m.start()].strip():
            primera[0] = False
            return w
        primera[0] = False
        if w.lower() in propias or _sin_tildes_simple(w.lower()) in propias:
            return w
        if len(w) == 1 and w not in "YAOEU":
            return w                                   # C, L, T, S (niveles vertebrales, letras sueltas)
        return w[0].lower() + w[1:]

    # palabra Capitalizada (no sigla) y que no esté pegada a un dígito (L4, T12)
    return re.sub(r"(?<![\w])[A-ZÁÉÍÓÚÑ][a-záéíóúñü]*(?![\wÁÉÍÓÚÑ])", baja, t)


def minusculas_tras_coma(t: str) -> str:
    """", Lesión" -> ", lesión" (salvo epónimos y siglas)."""
    propios = _propios()
    def baja(m):
        w = m.group(2)
        if w.lower() in propios or not w[1:].islower():
            return m.group(0)
        return m.group(1) + w[0].lower() + w[1:]
    return re.sub(r"([,;]\s+)([A-ZÁÉÍÓÚÑ][a-záéíóúñü]+)", baja, t)


def mayusculas(t: str) -> str:
    def sube(m):
        return m.group(1) + m.group(2).upper()
    t = re.sub(r"([.?!]\s+|\n)([a-záéíóúñü])", sube, t)
    return t


# ---------------------------------------------------------------- correcciones
def aplicar_correcciones(t: str) -> str:
    c = CORRECCIONES.datos()
    # 1) palabras/frases: "hipo denso" -> "hipodenso" (sin distinguir mayúsculas)
    pares = sorted(c.get("palabras", {}).items(), key=lambda kv: -len(kv[0]))
    def con_mayuscula(a):
        # respeta la mayúscula inicial de lo dictado ("Benaporta" -> "Vena porta")
        def f(m):
            inicio = not m.string[:m.start()].strip() or re.search(r"[.?!\n]\s*$", m.string[:m.start()])
            return (a[:1].upper() + a[1:]) if inicio and m.group(0)[:1].isupper() and a[:1].islower() else a
        return f
    for de, a in pares:
        t = re.sub(r"(?<!\w)" + re.escape(de) + r"(?!\w)", con_mayuscula(a), t, flags=re.I)
    # 2) reglas con expresiones regulares (formato de medidas, etc.)
    for regla in c.get("reglas", []):
        try:
            t = re.sub(regla["patron"], regla["reemplazo"], t, flags=re.I)
        except re.error:
            pass
    return t


# ---------------------------------------------------------------- comandos de voz
def _mejor_coincidencia(frase: str, opciones: dict, umbral=0.72):
    norm = {normalizar(k): k for k in opciones}
    if frase in norm:
        return norm[frase]
    compacta = {k.replace(" ", ""): v for k, v in norm.items()}     # "ap lateral" = "aplateral"
    if frase.replace(" ", "") in compacta:
        return compacta[frase.replace(" ", "")]
    cand = difflib.get_close_matches(frase, list(norm), n=1, cutoff=umbral)
    return norm[cand[0]] if cand else None


def detectar_comando(texto: str):
    """Devuelve un dict de comando, o None si el texto es dictado normal."""
    cfg = CONFIG.datos()
    n = normalizar(texto)
    limite = 16 if n.startswith(("plantilla", "insertar plantilla")) else 8
    if not n or len(n.split()) > limite:
        return None

    # cambiar de campo: "campo hallazgos", "ir a impresión", "hallazgos" (si está solo)
    campos = cfg.get("campos", {})
    m = re.fullmatch(r"(?:campo|ir a|ve a|vamos a|seccion|sección)\s+(.+)", n)
    objetivo = m.group(1) if m else n
    for clave, info in campos.items():
        alias = [normalizar(a) for a in info.get("alias", [])] + [normalizar(clave)]
        if objetivo in alias or (m and difflib.get_close_matches(objetivo, alias, n=1, cutoff=0.75)):
            return {"accion": "campo", "campo": clave}

    # deshacer / borrar lo último
    if n in {normalizar(x) for x in cfg.get("comandos", {}).get("deshacer", [])}:
        return {"accion": "deshacer"}
    if n in {normalizar(x) for x in cfg.get("comandos", {}).get("detener", [])}:
        return {"accion": "detener"}

    p = PLANTILLAS.datos()
    # plantilla completa: "plantilla tac de cerebro normal"
    m = re.fullmatch(r"(?:plantilla|insertar plantilla)\s+(.+)", n)
    if m:
        nombre = _mejor_coincidencia(m.group(1), p.get("plantillas", {}))
        if nombre:
            contenido = limpiar_plantilla({k: v for k, v in p["plantillas"][nombre].items() if not k.startswith("_")})
            if not contenido:
                return {"accion": "aviso", "mensaje": f"La plantilla «{nombre}» quedó vacía (solo tenía el pie del informe). Bórrala o vuelve a generar el perfil."}
            return {"accion": "plantilla", "nombre": nombre, "contenido": contenido}
        return {"accion": "aviso", "mensaje": f"No encontré la plantilla «{m.group(1)}»"}

    # frase normal en el campo activo: "frase hígado normal" / "normal hígado"
    m = re.fullmatch(r"(?:frase|insertar|normal de|normal)\s+(.+)", n)
    if m:
        nombre = _mejor_coincidencia(m.group(1), p.get("frases", {}))
        if nombre:
            return {"accion": "frase", "nombre": nombre, "texto": _texto_frase(p["frases"][nombre])}

    # frase tipo dicha sola, sin prefijo: "hígado graso" -> la frase completa
    # (solo nombres de 2+ palabras, para no disparar una frase al decir "hígado" y hacer una pausa)
    if 2 <= len(n.split()) <= 6:
        multi = {k: v for k, v in p.get("frases", {}).items() if len(normalizar(k).split()) >= 2}
        nombre = _mejor_coincidencia(n, multi, umbral=0.9)
        if nombre:
            return {"accion": "frase", "nombre": nombre, "texto": _texto_frase(p["frases"][nombre])}
    return None


def _texto_frase(v):
    return v.get("texto", "") if isinstance(v, dict) else v


# Líneas del pie del informe que se colaron al importar informes (no son parte del texto médico)
BASURA_INFORME = re.compile(r"^\s*(?:m[eé]dico\s+(?:de\s+)?referencia\b.*|fecha\s+(?:del?\s+)?examen\b.*|saluda\s+atentamente\b.*|"
                            r"dr\.?\s*\(a\)\s*:?.*|atentamente\.?)\s*$", re.I)


def es_basura_informe(linea: str) -> bool:
    return bool(BASURA_INFORME.match(re.sub(r"<[^>]+>|&nbsp;", " ", linea or "")))


def limpiar_plantilla(contenido: dict) -> dict:
    """Quita el pie del informe («Médico de Referencia Dr.(a):», «Fecha Examen:», «Saluda Atentamente») y
    convierte en formato el HTML que quedó como texto (títulos importados del RIS: «<p>AngioTAC&nbsp;…»)."""
    import html as _html
    out = {}
    for campo, v in contenido.items():
        if isinstance(v, dict):
            v = dict(v)
            t = v.get("texto", "") or ""
            if re.search(r"<[a-z][^>]*>", t, re.I):
                if not v.get("html"):
                    v["html"] = t
                t = _html.unescape(re.sub(r"<br\s*/?>|</p>", "\n", t, flags=re.I))
                t = re.sub(r"<[^>]+>", "", t).replace("\u00a0", " ")
                t = re.sub(r"[ \t]+", " ", t).strip()
            v["texto"] = "\n".join(l for l in t.split("\n") if not es_basura_informe(l)).strip()
            if v.get("html"):
                h = re.sub(r"<p[^>]*>(?:(?!</p>).)*</p>", lambda m: "" if es_basura_informe(m.group(0)) else m.group(0), v["html"], flags=re.I | re.S)
                v["html"] = h
            if v["texto"]:
                out[campo] = v
        elif isinstance(v, str):
            t = "\n".join(l for l in v.split("\n") if not es_basura_informe(l)).strip()
            if t:
                out[campo] = t
    return out


# ---------------------------------------------------------------- alucinaciones típicas de Whisper
ALUCINACIONES = [
    "subtítulos realizados por la comunidad de amara.org", "subtitulos realizados por la comunidad de amara org",
    "gracias por ver", "gracias por ver el video", "suscríbete", "suscribete al canal",
    "subtítulos por la comunidad de amara.org", "transcripción", "gracias",
]


def es_alucinacion(texto: str) -> bool:
    n = normalizar(texto)
    return not n or n in {normalizar(a) for a in ALUCINACIONES} or "amara org" in n


INTERJECCIONES = set("""wow ok okay oh ah eh mm mmm hmm uh um ay uy yeah yes so bom ta tá ya si sí bueno vale hola
a e o u ok ja jaja je oye mira pues ehm ehh aha ajá aja vaya ups uf bah well right gracias perdón perdon""".split())


def es_ruido(crudo: str, segundos: float) -> bool:
    """Frases cortas que en realidad fueron un ruido, una respiración o alguien hablando de fondo:
    «Wow», «A», «Yeah», «Tá bom», «¡vaya!». Nunca descarta palabras que podrían ser médicas
    (aunque el motor las escriba mal: «Colesis tectomizada», «Fraktura»): esas se corrigen después."""
    palabras = normalizar(crudo).split()
    if not palabras:
        return True
    if all(w in INTERJECCIONES for w in palabras) and len(palabras) <= 3:
        return True                           # «So» tras 25 s de ruido de fondo
    if not segundos or segundos >= 4:
        return False
    if len(palabras) == 1 and palabras[0] in {"punto", "coma", "no", "ni", "sin", "con"}:
        return False                          # dichas solas con una pausa después: son parte del informe
    if all(w in INTERJECCIONES for w in palabras):
        return True                           # «Wow», «Yeah», «Tá bom», «¡vaya!», «So»
    if len(palabras) == 1 and len(palabras[0]) <= 2 and not palabras[0].isdigit() and not re.search(r"[A-Z]{2}", crudo):
        return True                           # «A», «E» sueltas (salvo siglas: TC, RM)
    if re.fullmatch(r"[\s¡!¿?.]+", crudo):
        return True                           # «¡¡¡¡!»
    return False


def es_alucinacion_respaldo(crudo: str, segundos: float) -> bool:
    """Canary (el motor de respaldo) a veces inventa frases enteras con ruido corto:
    «Hay un club de turistas y un club de turistas». Se descarta si casi ninguna palabra es de tus informes."""
    if segundos >= 3:
        return False
    if re.search(r"[¿¡]", crudo):
        return True                           # preguntas/exclamaciones inventadas («¿por qué está…?», «¡no!»)
    palabras = [w for w in normalizar(crudo).split() if len(w) > 2]
    if not palabras:
        return False
    try:
        import contexto
        uni = contexto.MODELO.uni
    except Exception:  # noqa: BLE001
        return False
    if not uni:
        return False
    conocidas = sum(1 for w in palabras if uni.get(w, 0) >= 3)
    return conocidas / len(palabras) < 0.34      # «club de turistas» (20 %) sí; «Traque ahí bronquillas principales permeables» (40 %) no


def _frecuencia_es_solo(w: str) -> float:
    try:
        from wordfreq import zipf_frequency
        return zipf_frequency(w, "es")
    except Exception:  # noqa: BLE001
        return 3.0


def quitar_repeticiones(t: str) -> str:
    """«sin evidencia de la de la de la de la …» -> «sin evidencia de la»: el motor a veces se queda pegado."""
    for n in range(1, 5):
        t = re.sub(r"\b((?:\S+\s+){%d})(?:\1){2,}" % n, r"\1", t + " ").rstrip()
    # la frase completa dos veces seguidas ("X. X."): se deja una
    palabras = t.split()
    n = len(palabras)
    for corte in range(max(6, n // 2 - 2), n // 2 + 3):
        a_, b_ = palabras[:corte], palabras[corte:]
        if len(a_) >= 6 and [normalizar(w) for w in a_] == [normalizar(w) for w in b_]:
            return " ".join(a_)
    return t


# "coma sin" suele oírse "como en" / "comas en": en un informe, tras una coma dictada,
# "en imágenes / en evidencia / en líquido…" casi siempre es "sin …".
_TRAS_SIN = r"(?=im[aá]genes|evidencia|l[ií]quido|signos|alteraciones|lesiones|cambios|dilataci[oó]n|colecciones|hallazgos|derrame|adenopat[ií]as|calcificaciones|c[aá]lculos)"


def normalizar_comandos(t: str) -> str:
    """Variantes con que el motor escribe los comandos de puntuación (vistas en tus dictados)."""
    t = re.sub(r"\bpunt[oó]\b", "punto", t, flags=re.I)
    t = re.sub(r"\b(?:nubal|nueval|nuebal|nuoval|noval|normal|norma|nov|nob|nub)[ií]nea\b", "nueva línea", t, flags=re.I)
    # "punto a nueva línea", "punto en nueva línea", "puntó a línea"
    t = re.sub(r"\bpunto[\s,.]+(?:a|en|y)\s+(?:(?:nueva|nova|nuova|nueba)\s+)?l[ií]nea\b", "punto nueva línea", t, flags=re.I)
    # "punto nuev" (cortado al final de la frase)
    t = re.sub(r"\bpunto[\s,.]+nuev[ao]?[\s.]*$", "punto nueva línea", t, flags=re.I)
    # "... espondilosis. Nueva." (el motor cortó "nueva línea")
    t = re.sub(r"([.,;])\s*nueva[\s.]*$", r"\1 nueva línea", t, flags=re.I)
    # "... cálculos punie." = "punto" cortado
    t = re.sub(r"\bpun(?:ie|i|e|t|te|tos)\.?\s*$", "punto", t, flags=re.I)
    t = re.sub(r"\bpun[at]a?\s+l[ií]nea\b", "punto nueva línea", t, flags=re.I)        # «punta línea», «puna línea»
    # "punto a parte" = "punto aparte"
    t = re.sub(r"\bpunto\s+a\s+parte\b", "punto aparte", t, flags=re.I)
    # "... destructiva, p." = "punto" cortado
    t = re.sub(r"(?<=\w)[\s,]+p\.?\s*$", " punto", t, flags=re.I)
    return t


def coma_sin(t: str) -> str:
    t = re.sub(r"\bc[oó]mo\s+ni\b", "coma ni", t, flags=re.I)
    def ni_pegado(m):          # «como en Ineumotórax» = «coma ni neumotórax» (el motor pegó la i de «ni»)
        resto = m.group(1)
        if _frecuencia_es_solo(("i" + resto).lower()) < 1 and _frecuencia_es_solo(resto.lower()) >= 2:
            return "coma ni " + resto
        return m.group(0)
    t = re.sub(r"\bc[oó]mo\s+en\s+[iI]([a-záéíóúñ]{4,})", ni_pegado, t)
    # "¿Cómo sin observar lesiones…?" al inicio de la frase = "coma sin observar…"
    t = re.sub(r"^\s*¿?\s*c[oó]mo\s+(?=sin\b)", "coma ", t, flags=re.I)
    t = re.sub(r",\s*(?:como|comas?)\s+(?:en|sin)\s+(?:(?:el|la|los|las)\s+)?" + _TRAS_SIN, " coma sin ", t, flags=re.I)
    t = re.sub(r"\bcomas?\s+en\s+" + _TRAS_SIN, "coma sin ", t, flags=re.I)
    return t


# ---------------------------------------------------------------- números dichos en palabras -> dígitos
# (algunos motores escriben "dos coma cinco centímetros"; el informe necesita "2,5 cm")
_U = {"cero": 0, "un": 1, "uno": 1, "una": 1, "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5, "seis": 6, "siete": 7,
      "ocho": 8, "nueve": 9, "diez": 10, "once": 11, "doce": 12, "trece": 13, "catorce": 14, "quince": 15,
      "dieciséis": 16, "dieciseis": 16, "diecisiete": 17, "dieciocho": 18, "diecinueve": 19, "veinte": 20,
      "veintiuno": 21, "veintiún": 21, "veintiuna": 21, "veintidós": 22, "veintidos": 22, "veintitrés": 23,
      "veintitres": 23, "veinticuatro": 24, "veinticinco": 25, "veintiséis": 26, "veintiseis": 26,
      "veintisiete": 27, "veintiocho": 28, "veintinueve": 29}
_D = {"treinta": 30, "cuarenta": 40, "cincuenta": 50, "sesenta": 60, "setenta": 70, "ochenta": 80, "noventa": 90}
_C = {"cien": 100, "ciento": 100, "doscientos": 200, "doscientas": 200, "trescientos": 300, "trescientas": 300,
      "cuatrocientos": 400, "cuatrocientas": 400, "quinientos": 500, "quinientas": 500, "seiscientos": 600,
      "seiscientas": 600, "setecientos": 700, "setecientas": 700, "ochocientos": 800, "ochocientas": 800,
      "novecientos": 900, "novecientas": 900}
_PAL_NUM = sorted(list(_U) + list(_D) + list(_C), key=len, reverse=True)
# «un/una/uno» seguido de otro número es artículo ("un treinta por ciento" = 30, no 31)
_RE_NUMPAL = r"(?:(?:(?:un|una|uno)(?!\s+(?:" + "|".join(_PAL_NUM) + r")\b)|" + "|".join(p for p in _PAL_NUM if p not in ("un", "una", "uno")) + r")(?:(?:" + "|".join("(?<=" + d + ")" for d in _D) + r")\s+y\s+(?:" + "|".join(sorted(_U, key=len, reverse=True)) + r")|\s+(?:" + "|".join(_PAL_NUM) + r"))*)"
_UNIDADES = r"(?:cm\b|mm\b|cent[ií]metros?|mil[ií]metros?|metros?\b|unidades|UH\b|%|por\s?ciento|grados|cc\b|ml\b|mililitros|x\b|por\s+(?!ciento\b)(?:\d|" + "|".join(_PAL_NUM) + r"))"


def _valor(frase: str):
    total, ok = 0, False
    for w in re.findall(r"[a-záéíóúñ]+", frase.lower()):
        if w == "y":
            continue
        for tabla in (_C, _D, _U):
            if w in tabla:
                total += tabla[w]; ok = True
                break
        else:
            return None
    return total if ok else None


def numeros_a_digitos(t: str) -> str:
    # «come»/«com» entre dos números es «coma»; «cometros»/«centímetro» mal oídos
    t = re.sub(r"\b(" + _RE_NUMPAL + r"|\d+)\s+com[e]?\s+(?=(?:" + _RE_NUMPAL + r"|\d))", r"\1 coma ", t, flags=re.I)
    t = re.sub(r"\b(?:co|ce|sen|sin)?ti?metros\b|\bcometros\b", lambda m: "centímetros" if m.group(0).lower() in ("cometros", "cemetros", "sentimetros", "cetimetros") else m.group(0), t, flags=re.I)
    # el motor escribió la «coma» dictada como «,» entre dos números de una medida: «doce, siete por tres»
    _una = r"(?:" + "|".join(_PAL_NUM) + r")"
    t = re.sub(r"(?<!,\s)(?<!\by\s)\b(" + _una + r")\s*,\s*(" + _una + r")(?=\s+(?:por|x)\s|\s+" + _UNIDADES + r")", r"\1 coma \2", t, flags=re.I)
    # la frase es SOLO un número decimal («siete coma cinco»): 7,5
    sol = re.fullmatch(r"\s*(" + _RE_NUMPAL + r")\s*,?\s*coma\s+(" + _RE_NUMPAL + r")\s*[.,]?\s*", t, flags=re.I)
    if sol and _valor(sol.group(1)) is not None and _valor(sol.group(2)) is not None:
        return f"{_valor(sol.group(1))},{_valor(sol.group(2))}"
    # decimales: "dos coma cinco centímetros" -> "2,5 centímetros"
    def dec(m):
        a, b = _valor(m.group(1)), _valor(m.group(2))
        return f"{a},{b}{m.group(3)}" if a is not None and b is not None else m.group(0)
    t = re.sub(r"\b(" + _RE_NUMPAL + r")\s+coma?\s+(" + _RE_NUMPAL + r")(\s+" + _UNIDADES + r")", dec, t, flags=re.I)

    # enteros antes de una unidad: "quince milímetros" -> "15 milímetros", "tres por dos cm" -> "3 por 2 cm"
    def ent(m):
        v = _valor(m.group(1))
        return str(v) if v is not None else m.group(0)
    for _ in range(2):    # la unidad se mira sin consumirla: "cincuenta por treinta y un mm" -> "50 por 31 mm"
        t = re.sub(r"\b(" + _RE_NUMPAL + r")(?=\s+" + _UNIDADES + r")", ent, t, flags=re.I)
    t = re.sub(r"(\d)\s+(?:por(?!\s+ciento)|x)\s+(" + _RE_NUMPAL + r")\b", lambda m: f"{m.group(1)} x {_valor(m.group(2))}" if _valor(m.group(2)) is not None else m.group(0), t, flags=re.I)

    # después de verbos/frases de medida, TODOS los números van en cifras (aunque la unidad venga después o no venga)
    disparador = (r"\b(?:miden?|midiendo|mide\s+(?:aproximadamente|hasta|en\s+total)|alcanza(?:ndo)?|di[aá]metros?(?:\s+(?:mayor|menor|m[aá]ximo|transverso|anteroposterior|longitudinal))?\s+de|"
                  r"espesor\s+de|grosor\s+de|calibre\s+de|longitud\s+de|eje\s+(?:mayor|menor)\s+de|tama[nñ]o\s+de|volumen\s+de|"
                  r"de\s+(?:aproximadamente|hasta|unos?|alrededor\s+de)|aproximadamente|hasta)\s+")
    num = r"(?:\d+(?:[.,]\d+)?|" + _RE_NUMPAL + r")"
    cadena = num + r"(?:\s*(?:coma|,)\s*" + num + r")?(?:\s+(?:por(?!\s+ciento\b)|x|y)\s+" + num + r"(?:\s*(?:coma|,)\s*" + num + r")?)*"

    def a_cifras(m):
        frag = m.group(2)
        # "alcanzando un diámetro", "hasta un 30 %": «un/una/uno» suelto es artículo, no el número 1
        if re.fullmatch(r"(?:un|una|uno)", frag.strip(), flags=re.I) and \
                not re.match(r"\s+" + _UNIDADES, m.string[m.end():], flags=re.I):
            return m.group(0)
        frag = re.sub(r"(" + _RE_NUMPAL + r")\s+coma?\s+(" + _RE_NUMPAL + r")",
                      lambda x: f"{_valor(x.group(1))},{_valor(x.group(2))}" if _valor(x.group(1)) is not None and _valor(x.group(2)) is not None else x.group(0), frag, flags=re.I)
        frag = re.sub(r"(\d)\s+coma?\s+(\d)", r"\1,\2", frag)
        frag = re.sub(r"\b(" + _RE_NUMPAL + r")\b", lambda x: str(_valor(x.group(1))) if _valor(x.group(1)) is not None else x.group(0), frag, flags=re.I)
        frag = re.sub(r"(\d)\s+(?:por|x)\s+(?=\d)", r"\1 x ", frag)
        return m.group(1) + frag
    t = re.sub(r"(" + disparador + r")(" + cadena + r")", a_cifras, t, flags=re.I)
    t = re.sub(r"(\d)\s*por\s?ciento\b", r"\1%", t, flags=re.I)          # "30 por ciento" -> "30%"
    return t


# ---------------------------------------------------------------- fechas
_NUMFECHA = r"(?:\d{1,4}|dos\s+mil(?:\s+" + _RE_NUMPAL + r")?|(?:cero\s+)?" + _RE_NUMPAL + r")"


def _valor_fecha(f: str):
    f = f.strip().lower()
    if f.isdigit():
        return int(f)
    m = re.fullmatch(r"dos\s+mil(?:\s+(.+))?", f)
    if m:
        resto = _valor(m.group(1)) if m.group(1) else 0
        return None if resto is None else 2000 + resto
    return _valor(re.sub(r"^cero\s+", "", f))


def fechas(t: str) -> str:
    """«veinticinco barra diez barra dos mil veintiséis» / «8 barra 10 barra 2026» -> 25/10/2026, 08/10/2026."""
    def f(m):
        d, me, a = (_valor_fecha(m.group(i)) for i in (1, 2, 3))
        if None in (d, me, a) or not (1 <= d <= 31 and 1 <= me <= 12):
            return m.group(0)
        if a < 100:
            a += 2000
        if not 1900 <= a <= 2100:
            return m.group(0)
        return f"{d:02d}/{me:02d}/{a}"
    sep = r"\s*(?:barra|/)\s*"
    return re.sub(r"\b(" + _NUMFECHA + r")" + sep + r"(" + _NUMFECHA + r")" + sep + r"(" + _NUMFECHA + r")\b", f, t, flags=re.I)


# «como» que en realidad es «coma»: el motor confunde las dos. Solo antes de palabras que en tus informes
# casi siempre siguen a una coma (y nunca tras «así como» / «tal como»).
_TRAS_COMA = (r"identificando|midiendo|alcanzando|destacando|observ[aá]ndose|siendo|asociad[oa]s?|probablemente|"
              r"la\s+cual|el\s+cual|las\s+cuales|los\s+cuales|lo\s+que|sin\s+evidencia|sin\s+embargo|ni\b")


def como_es_coma(t: str) -> str:
    def f(m):
        antes = t[:m.start()].rstrip().lower()
        if re.search(r"\b(?:as[ií]|tal|tales)$", antes):
            return m.group(0)
        return " coma "
    t = re.sub(r"\s*\b(?:como|come|coman)\s+(?=(?:" + _TRAS_COMA + r"))", f, t, flags=re.I)
    t = re.sub(r"\b(?:come|coman)\s+y\s+(?=\w)", " coma ni ", t, flags=re.I)        # «come y hay evidencia» = «coma ni hay»
    return t


# ---------------------------------------------------------------- niveles vertebrales
_VERT_NUM = {k: v for k, v in _U.items() if 1 <= v <= 12 and k not in ("un", "una")}


def vertebras(t: str) -> str:
    pal = "|".join(sorted(_VERT_NUM, key=len, reverse=True))
    # "C cuatro guionce cinco" / "guion C": el guion se dice entre niveles
    t = re.sub(r"\bgui[oó]n\s*c[e]?\b", " C", t, flags=re.I)
    t = re.sub(r"(?<=\w)\s+gui[oó]n\s+(?=[CDTLS]\b)", " ", t, flags=re.I)
    t = re.sub(r"\b([CDTLS])\s*-?\s*(" + pal + r")\b", lambda m: m.group(1).upper() + str(_VERT_NUM[m.group(2).lower()]), t, flags=re.I)
    t = re.sub(r"\b([CDTLS])\s+(\d{1,2})\b", lambda m: m.group(1).upper() + m.group(2), t)
    # "C5 C6" / "C5-C6" / "C5 a C6" -> "C5-C6"
    t = re.sub(r"\b([CDTLS]\d{1,2})\s*(?:-|a|y|\s)\s*([CDTLS]\d{1,2})\b", r"\1-\2", t)

    # Lo que el motor escribe mal al oír dos niveles seguidos (solo si el segundo es el nivel siguiente):
    def siguiente(m, letra, n, otro):
        try:
            return f"{letra}{n}-{letra}{int(n) + 1}" if int(otro) == int(n) + 1 else m.group(0)
        except ValueError:
            return m.group(0)
    #   "C5 seis" / "C5 y 6" (sin repetir la letra)
    t = re.sub(r"\b([CDTLS])(\d{1,2})\s+(?:a\s+|y\s+)?(" + pal + r"|\d{1,2})\b(?![,.]\d|\s*(?:mm|cm|%))",
               lambda m: siguiente(m, m.group(1).upper(), m.group(2), _VERT_NUM.get(m.group(3).lower(), m.group(3))), t, flags=re.I)
    #   "C4-115" / "C5-116"
    t = re.sub(r"\b([CDTLS])(\d)-1{1,2}(\d)\b", lambda m: siguiente(m, m.group(1), m.group(2), m.group(3)), t)
    #   "C4G5"
    t = re.sub(r"\b([CDTLS])(\d)[GgCc](\d)\b", lambda m: siguiente(m, m.group(1), m.group(2), m.group(3)), t)
    #   "C56" (C y L no tienen niveles de dos cifras como 56)
    t = re.sub(r"\b([CLS])([1-7])([2-8])\b", lambda m: siguiente(m, m.group(1), m.group(2), m.group(3)), t)
    #   "C4-C y C5-C6": nivel incompleto -> el siguiente
    t = re.sub(r"\b([CDTLS])(\d{1,2})-([CDTLS])(?![\w])", lambda m: f"{m.group(1)}{m.group(2)}-{m.group(3)}{int(m.group(2)) + 1}", t)
    return t


# ---------------------------------------------------------------- salto de línea dicho solo
SALTOS = {
    "nova linea", "nuova linea", "nueve linea", "no a linea", "nuevo linea", "na linea", "no linea", "puntan a lineas", "noma linea",
    "nueva linea", "nueva linia", "nueva lina", "nueba linea", "nuevalinea", "linea nueva", "siguiente linea",
    "otra linea", "salto de linea", "salto", "enter", "aparte", "no hay linea", "no la linea", "no ha linea",
}
PARRAFOS = {"punto aparte", "punto y aparte", "nuevo parrafo", "punto a parte", "punto y a parte"}


def detectar_salto(texto: str):
    n = normalizar(texto)
    if n in PARRAFOS:
        return {"tipo": "comando", "accion": "salto", "punto": True}
    if n.startswith("punt") and len(n) <= 21 and difflib.get_close_matches(n, ["punto nueva linea", "punto nova linea", "punto nuova linea"], n=1, cutoff=0.7):
        return {"tipo": "comando", "accion": "salto", "punto": True}       # «Puntano la linee»
    if n in SALTOS or (len(n) <= 18 and difflib.get_close_matches(n, list(SALTOS), n=1, cutoff=0.8)):
        return {"tipo": "comando", "accion": "salto", "punto": False}
    return None


# ---------------------------------------------------------------- números romanos
NUMEROS = {"uno": 1, "una": 1, "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5, "seis": 6, "siete": 7, "ocho": 8,
           "nueve": 9, "diez": 10, "once": 11, "doce": 12, "trece": 13, "catorce": 14, "quince": 15,
           "dieciséis": 16, "dieciseis": 16, "diecisiete": 17, "dieciocho": 18, "diecinueve": 19, "veinte": 20}
ROMANOS_PALABRAS_CLAVE = [
    "segmento", "segmentos", "grado", "estadio", "tipo", "clase",
    "par craneal", "pares craneales", "nervio craneal", "nervios craneales", "par", "pares",
]


def a_romano(n: int) -> str:
    vals = [(10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]
    out = ""
    for v, r in vals:
        while n >= v:
            out += r
            n -= v
    return out


def aplicar_romanos(t: str) -> str:
    conf = CORRECCIONES.datos().get("romanos", {})
    claves = conf.get("despues_de", ROMANOS_PALABRAS_CLAVE)
    if not conf.get("activo", True) or not claves:
        return t
    pal = "|".join(sorted(NUMEROS, key=len, reverse=True))
    num = r"(?:\d{1,2}|" + pal + r")(?:\s?[ab]\b)?"
    sep = r"(?:\s*(?:,|y|e|o|-|a|al)\s*)"
    clave = "|".join(re.escape(c).replace("\\ ", r"\s+") for c in sorted(claves, key=len, reverse=True))
    patron = re.compile(r"\b(" + clave + r")\s+(" + num + r"(?:" + sep + num + r")*)(?![\d,.]\d)", re.I)

    def convertir_num(m):
        tok = m.group(0)
        mm = re.fullmatch(r"(\d{1,2}|[a-záéíóúñ]+)(?:\s?([ab]))?", tok, re.I)
        if not mm:
            return tok
        base, letra = mm.group(1).lower(), (mm.group(2) or "").lower()
        n = int(base) if base.isdigit() else NUMEROS.get(base)
        if not n or n > 20:
            return tok
        return a_romano(n) + letra

    def reemplazar(m):
        lista = re.sub(num, convertir_num, m.group(2), flags=re.I)
        return m.group(1) + " " + lista

    t = patron.sub(reemplazar, t)
    # "cuatro romano" -> IV  (también si ya quedó "IV romano")
    t = re.sub(r"\b(" + num + r")\s+romanos?\b", lambda m: convertir_num(re.match(num, m.group(1), re.I)), t, flags=re.I)
    t = re.sub(r"\b([IVX]+[ab]?)\s+romanos?\b", r"\1", t)
    # comando explícito: "romano cuatro" -> IV
    t = re.sub(r"\bromanos?\s+(" + num + r")", lambda m: convertir_num(re.match(num, m.group(1), re.I)), t, flags=re.I)
    return t


# ---------------------------------------------------------------- corrector por vocabulario
# Si el motor escribe una palabra que no existe en español (p.ej. "doluminales"), se busca la más
# parecida en tu vocabulario médico (vocabulario_base.txt + vocabulario.txt + tus informes importados).
_VOC = {"firma": None, "por_norm": {}, "lista": []}


def _cargar_vocabulario():
    rutas = [BASE / "vocabulario_base.txt", BASE / "vocabulario.txt", BASE / "terminos_prioritarios.txt",
             BASE / "informes" / "informes.jsonl"]
    firma = tuple((r.stat().st_mtime if r.exists() else 0) for r in rutas)
    if firma == _VOC["firma"]:
        return
    palabras = collections.Counter()
    for r in rutas:
        if not r.exists():
            continue
        for linea in r.read_text(encoding="utf-8", errors="ignore").splitlines():
            if linea.startswith("#"):
                continue
            for w in re.findall(r"[A-Za-zÁÉÍÓÚÑáéíóúñü]{5,}", linea):
                palabras[w.lower()] += 1
    por_norm = {}
    for w, _ in palabras.most_common():
        por_norm.setdefault(normalizar(w), w)
    _VOC.update(firma=firma, por_norm=por_norm, lista=list(por_norm))


def _frecuencia_es(w: str) -> float:
    """Qué tan común es la palabra en español (o en inglés: stent, shunt, Doppler...)."""
    try:
        from wordfreq import zipf_frequency
        return max(zipf_frequency(w, "es"), zipf_frequency(w, "en") - 0.5)
    except Exception:  # noqa: BLE001
        return -1.0


def _solo_flexion(a: str, b: str) -> bool:
    """True si a y b solo difieren en género/número (hipodenso/hipodensa/hipodensos)."""
    raiz = lambda x: re.sub(r"(os|as|es|o|a|e|s)$", "", x)  # noqa: E731
    return raiz(a) == raiz(b)


def corregir_por_vocabulario(t: str) -> str:
    if not CONFIG.datos().get("corrector_vocabulario", True):
        return t
    _cargar_vocabulario()
    if not _VOC["lista"]:
        return t

    def cambiar(m):
        w = m.group(0)
        wl = w.lower()
        n = normalizar(wl)
        if n in _VOC["por_norm"]:
            nuevo = _VOC["por_norm"][n]            # solo faltaban tildes: parenquima -> parénquima
        else:
            f = _frecuencia_es(wl)
            if f < 0 or f > 1.0:                   # palabra real del español (o sin diccionario): no tocar
                return w
            cand = difflib.get_close_matches(n, _VOC["lista"], n=1, cutoff=0.84)
            if not cand:
                return w
            nuevo = _VOC["por_norm"][cand[0]]
            if _solo_flexion(n, cand[0]):
                # misma palabra con otro género/número: solo copiar las tildes ("mediastinicas" -> "mediastínicas")
                fin = re.search(r"(os|as|es|o|a|e|s)?$", n).group(0)
                raiz = re.sub(r"(os|as|es|o|a|e|s)$", "", nuevo)
                if fin.startswith("e") and re.search(r"[áéíóú][ns]$", raiz):
                    raiz = raiz[:-2] + _sin_tildes_simple(raiz[-2]) + raiz[-1]   # -ión -> -iones
                nuevo = raiz + fin
                if normalizar(nuevo) != n:
                    return w
        if nuevo == wl:
            return w
        return nuevo[:1].upper() + nuevo[1:] if w[:1].isupper() else nuevo

    return re.sub(r"[A-Za-zÁÉÍÓÚÑáéíóúñü]{5,}", cambiar, t)


# ---------------------------------------------------------------- todo junto
def solo_latino(t: str) -> str:
    """Quita palabras en otros alfabetos (cirílico, griego, etc.) que el motor a veces inventa."""
    return re.sub(r"\S*[^\x00-\u024F\u2010-\u2027\u00B3\u00B2\u00BA\u00AA\s]\S*", " ", t)


def procesar(texto_crudo: str, segundos: float = 0, respaldo: bool = False) -> dict:
    """Devuelve {"tipo": "comando", ...} o {"tipo": "texto", "texto": ...}."""
    texto_crudo = solo_latino(texto_crudo).strip()
    if es_alucinacion(texto_crudo):
        return {"tipo": "vacio"}
    texto_crudo = quitar_repeticiones(texto_crudo)
    salto = detectar_salto(normalizar_comandos(texto_crudo))
    if salto:
        return salto
    cmd = detectar_comando(texto_crudo)
    if cmd:
        cmd["tipo"] = "comando"
        return cmd
    if es_ruido(texto_crudo, segundos) or (respaldo and es_alucinacion_respaldo(texto_crudo, segundos)):
        return {"tipo": "vacio", "ruido": True}
    modo = CONFIG.datos().get("modo_puntuacion", "dictada")
    t = numeros_a_digitos(fechas(como_es_coma(coma_sin(normalizar_comandos(texto_crudo)))))
    t = vertebras(t)
    t = aplicar_puntuacion(t, modo)
    t = aplicar_romanos(t)
    t = aplicar_correcciones(t)
    t = separar_pegadas(t)
    t = corregir_por_vocabulario(t)
    t = separar_pegadas(t)                    # otra vez: el vocabulario pudo dejar «niendoluminales»
    if CONFIG.datos().get("modelo_contexto", True):
        try:
            import contexto
            t = contexto.corregir(t)
        except Exception:  # noqa: BLE001
            pass
    if modo == "dictada":
        t = quitar_mayusculas_del_motor(t)        # después de corregir: tampoco quedan mayúsculas de correcciones
    t = limpiar_espacios(t)
    t = minusculas_tras_coma(t)
    t = mayusculas(t)
    return {"tipo": "texto", "texto": t}


def prompt_inicial(contexto: str = "") -> str:
    """Texto que se le da a Whisper como contexto: tu vocabulario + lo último del campo."""
    cfg = CONFIG.datos()
    base = cfg.get("prompt_base", "Informe radiológico.")
    terminos = ", ".join(vocabulario())
    p = f"{base} {terminos}".strip()
    p = p[: cfg.get("max_largo_prompt_vocabulario", 300)]
    if contexto:
        p = p + " " + contexto[-120:]
    return p

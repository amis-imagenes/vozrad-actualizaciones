"""
VozRad - mide el contexto radiológico con el motor de VozRad (el mismo de cada día, onnx-asr) en tu turno
de prueba (entrenamiento/datos/prueba.jsonl, que arma armar_entrenamiento).

Uso:  .venv\\Scripts\\python evaluar_contexto.py [orden:alfa | archivo.arpa:alfa ...]   p. ej.  5:0.2 radiologia-5-nuevo.arpa:0.2
Deja el resultado en C:\\VozRad\\entrenamiento\\resultado-contexto-vozrad.txt (sin audio). No cambia nada.
"""
import datetime as dt
import json
import sys
import time
import wave
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
sys.path.insert(0, str(BASE / "entrenar"))
ENT = BASE.parent / "entrenamiento"


def _wav(ruta: str):
    p = Path(ruta)
    if ruta.startswith("/mnt/c/"):
        p = Path("C:/" + ruta[7:])
    with wave.open(str(p)) as w:
        return np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0


def main():
    import contexto_radiologico as C
    import motores
    import texto
    import vozrad_nemo as V
    combos = [tuple(x.split(":")) for x in sys.argv[1:]] or [("5", "0.2"), ("4", "0.3")]
    filas = [json.loads(l) for l in (ENT / "datos" / "prueba.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
    cfg = dict(texto.CONFIG.datos())
    par = motores.MotorParakeet(None, cfg.get("dispositivo", "cuda"))
    par.punto_por_tiempo = False
    par.punto_por_cola = False
    par.confianzas = False
    audios = [_wav(f["audio_filepath"]) for f in filas]
    L = [f"VozRad - contexto radiológico con el motor de VozRad ({dt.datetime.now():%d-%m-%Y %H:%M})",
         f"Motor: {par.descripcion} · {len(filas)} frases de prueba", ""]
    base = None
    for orden, alfa in [("0", "0")] + combos:
        archivo = orden if orden.endswith(".arpa") else None
        estado = C.preparar(par.modelo, {"activo": orden != "0", "orden": None if archivo else int(orden),
                                         "archivo": archivo, "alfa": float(alfa)})
        t0 = time.time()
        hips = [par.reconocer(a) for a in audios]
        seg = time.time() - t0
        E = N = K = 0
        por_frase = []
        for f, h in zip(filas, hips):
            e, n, c = V.errores(V.normal(f["text"]), V.normal(h))
            E, N, K = E + e, N + n, K + c
            por_frase.append(e)
        nombre = "sin contexto" if orden == "0" else (f"{orden}, alfa {alfa}" if archivo else f"orden {orden}, alfa {alfa}")
        L.append(f"{nombre:<22} palabras erradas {E}/{N} = {100 * E / max(N, 1):.2f} % · críticos {K} · "
                 f"{1000 * seg / len(filas):.0f} ms por frase · {estado}")
        print(L[-1], flush=True)
        if base is None:
            base, e_base = hips, por_frase
        else:
            mejor = [(f["text"], b, h) for f, b, h, x, y in zip(filas, base, hips, e_base, por_frase) if y < x]
            peor = [(f["text"], b, h) for f, b, h, x, y in zip(filas, base, hips, e_base, por_frase) if y > x]
            L.append(f"   frases mejores: {len(mejor)} · peores: {len(peor)}")
            for titulo, lista in (("MEJORES", mejor), ("PEORES", peor)):
                L.append(f"   {titulo}:")
                for t, b, h in lista[:25]:
                    L += [f"     = {t}", f"       sin {b}", f"       con {h}"]
    C.preparar(par.modelo, {"activo": False})
    salida = ENT / "resultado-contexto-vozrad.txt"
    salida.write_text("\n".join(L) + "\n", encoding="utf-8")
    print(f"[VozRad] Resultado en {salida}")


if __name__ == "__main__":
    main()

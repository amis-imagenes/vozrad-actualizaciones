"""
VozRad - servidor local de reconocimiento de voz.

Corre solo en tu computador (127.0.0.1). La extensión de Chrome le envía cada frase
dictada y recibe el texto ya corregido o el comando reconocido.

Iniciar:  iniciar.bat (Windows) / iniciar.command (Mac)   (o:  python servidor.py)
"""
import base64
import datetime as dt
import json
import re
import os
import sys
import threading
import time
import wave
from pathlib import Path

BASE = Path(__file__).resolve().parent


# --- En Windows, las librerías CUDA vienen como paquetes pip (nvidia-cublas / nvidia-cudnn).
#     Hay que decirle a Windows dónde están antes de cargar el motor.
def _registrar_dll_cuda():
    if os.name != "nt":
        return
    import site
    rutas = []
    for sp in site.getsitepackages() + [site.getusersitepackages()]:
        for sub in ("nvidia/cublas/bin", "nvidia/cudnn/bin", "nvidia/cuda_nvrtc/bin"):
            p = Path(sp) / sub
            if p.is_dir():
                rutas.append(str(p))
    for r in rutas:
        try:
            os.add_dll_directory(r)
        except OSError:
            pass
    os.environ["PATH"] = os.pathsep.join(rutas + [os.environ.get("PATH", "")])


_registrar_dll_cuda()

import numpy as np  # noqa: E402
from fastapi import Body, FastAPI, Request  # noqa: E402
from fastapi.middleware.cors import CORSMiddleware  # noqa: E402
import uvicorn  # noqa: E402

import texto  # noqa: E402
import informes  # noqa: E402
import aprendizaje  # noqa: E402

ULTIMO_USO = {"t": 0.0}   # última vez que se usó el motor (para mantener la tarjeta despierta)
GPU = threading.Lock()   # una sola transcripción a la vez; el dictado final tiene prioridad sobre el texto en vivo

CFG = texto.CONFIG.datos()

# ---------------------------------------------------------------- carga del modelo
MODELO = None
DISPOSITIVO = ""


_CARGA = {"t": 0.0}


def _capturar_carga(ms: int):
    """Frase lenta: anota qué programas usaban el procesador y la tarjeta en ese momento
    (historial/carga_frases_lentas.txt), para saber quién compite con el motor. Máx. una vez por minuto."""
    if os.name != "nt" or time.time() - _CARGA["t"] < 60:
        return
    _CARGA["t"] = time.time()
    destino = BASE / "historial" / "carga_frases_lentas.txt"
    ps = (
        # (los contadores de procesador tienen nombres traducidos en Windows en español: se mide con Get-Process)
        "$n = [Environment]::ProcessorCount; $a = @{}; Get-Process | ForEach-Object { $a[$_.Id] = $_.CPU }; "
        "Start-Sleep -Milliseconds 1500; 'PROCESADOR (% de todo el equipo, 1,5 s):'; "
        "Get-Process | ForEach-Object { if ($a.ContainsKey($_.Id) -and $_.CPU) { "
        "[pscustomobject]@{ p = 100 * ($_.CPU - $a[$_.Id]) / 1.5 / $n; n = $_.ProcessName } } } | "
        "Where-Object { $_.p -gt 2 } | Sort-Object p -Descending | Select-Object -First 8 | "
        "ForEach-Object { '  {0,5:N0} %  {1}' -f $_.p, $_.n }; "
        "$g = Get-Counter '\\GPU Engine(*)\\Utilization Percentage' -ErrorAction SilentlyContinue; "
        "'TARJETA (% por programa):'; "
        "$g.CounterSamples | Where-Object { $_.CookedValue -gt 2 } | ForEach-Object { "
        "$id = [int]($_.InstanceName -replace '^pid_(\\d+)_.*', '$1'); $t = ($_.InstanceName -replace '.*engtype_', ''); "
        "$nom = (Get-Process -Id $id -ErrorAction SilentlyContinue).ProcessName; "
        "'  {0,5:N0} %  {1} ({2})' -f $_.CookedValue, $nom, $t } | Sort-Object -Descending | Select-Object -First 8"
    )

    def tarea():
        try:
            import subprocess
            r = subprocess.run(["powershell.exe", "-NoProfile", "-Command", ps], capture_output=True, text=True,
                               timeout=40, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            with open(destino, "a", encoding="utf-8") as f:
                f.write(f"\n== {time.strftime('%Y-%m-%d %H:%M:%S')} · frase de {ms} ms ==\n{r.stdout.strip()}\n")
        except Exception:  # noqa: BLE001
            pass
    threading.Thread(target=tarea, daemon=True).start()


def subir_prioridad():
    """El motor con prioridad «superior a lo normal» en Windows: si el visor u otro programa ocupa el
    procesador, el dictado pasa primero (no afecta a los demás cuando no dictas)."""
    if os.name != "nt":
        return
    try:
        import ctypes
        ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x00008000)
    except Exception:  # noqa: BLE001
        pass


def mantener_tarjeta_despierta(cada_s: int = 45):
    """27-11: tras un rato sin dictar, las primeras frases tardaban 3-10 s (la tarjeta baja a reposo y Windows
    puede sacar la memoria del motor de la tarjeta). Mientras no dictas, cada 45 s el motor reconoce un segundo
    de silencio (unos milisegundos de trabajo) para que la tarjeta y su memoria sigan listas."""
    import numpy as np
    silencio = (np.random.default_rng(0).standard_normal(16000) * 1e-4).astype(np.float32)
    while True:
        time.sleep(cada_s)
        try:
            if "cuda" not in str(DISPOSITIVO) or MODELO is None or time.time() - ULTIMO_USO["t"] < cada_s:
                continue
            if GPU.acquire(blocking=False):
                try:
                    for m in _parakeets() or [MODELO]:
                        m.modelo.recognize(silencio) if hasattr(m, "modelo") else None
                    resp = getattr(MODELO, "respaldo", None)
                    if resp is not None:
                        try:
                            resp.reconocer(silencio)
                        except Exception:  # noqa: BLE001
                            pass
                finally:
                    GPU.release()
        except Exception:  # noqa: BLE001
            time.sleep(300)


def cargar_modelo():
    global MODELO, DISPOSITIVO
    import motores
    cfg = dict(texto.CONFIG.datos())
    if os.environ.get("VOZRAD_MOTOR_DE_PRUEBA"):          # solo para pruebas automáticas (sin modelo real)
        class _Prueba:
            descripcion = "motor de prueba"
            def reconocer(self, pcm, **kw):
                return "hígado de tamaño normal punto"
        MODELO, DISPOSITIVO = _Prueba(), "motor de prueba"
        print("[VozRad] Listo: motor de prueba")
        return
    MODELO = motores.cargar(cfg)
    DISPOSITIVO = MODELO.descripcion
    motores.MotorParakeet.punto_por_tiempo = bool(cfg.get("punto_por_tiempo", True))
    motores.MotorParakeet.punto_por_cola = bool(cfg.get("punto_por_cola", True))
    motores.MotorParakeet.lenguaje = dict(cfg.get("modelo_lenguaje") or {})
    _preparar_lenguaje()
    _preparar_contexto(cfg.get("contexto_radiologico") or {})
    if cfg.get("hilos_cpu_medidos"):
        try:                                   # guardar la medición para no repetirla
            ruta = BASE / "config.json"
            datos = json.loads(ruta.read_text(encoding="utf-8"))
            datos["hilos_cpu"] = cfg["hilos_cpu_medidos"]
            ruta.write_text(json.dumps(datos, ensure_ascii=False, indent=2), encoding="utf-8")
        except (OSError, ValueError):
            pass
    print(f"[VozRad] Listo: {DISPOSITIVO}")


# ---------------------------------------------------------------- historial (para aprender después)
HISTORIAL = BASE / "historial"


def guardar_historial(registro: dict):
    if not texto.CONFIG.datos().get("guardar_historial", True):
        return
    HISTORIAL.mkdir(exist_ok=True)
    archivo = HISTORIAL / f"{dt.date.today().isoformat()}.jsonl"
    with open(archivo, "a", encoding="utf-8") as f:
        f.write(json.dumps(registro, ensure_ascii=False) + "\n")


# ---------------------------------------------------------------- API
app = FastAPI(title="VozRad")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


# ---------------------------------------------------------------- motor en red (otro equipo usa este como motor)
RED = {"activa": False, "clave": ""}
LOCALES = {"127.0.0.1", "::1", "localhost"}


@app.middleware("http")
async def clave_de_red(request: Request, call_next):
    """Desde este mismo equipo no se pide nada. Desde otro equipo de la red: solo con modo red y la clave."""
    origen = request.client.host if request.client else ""
    if RED.get("proxy") and request.url.path == "/salud":
        return await call_next(request)                 # para el monitoreo del servidor (sin datos)
    if (origen not in LOCALES or RED.get("proxy")) and request.method != "OPTIONS":
        from fastapi.responses import JSONResponse
        if not RED["activa"]:
            return JSONResponse({"error": "este motor no está en modo red"}, status_code=403)
        if request.headers.get("x-vozrad-clave", "").strip().upper() != RED["clave"]:
            print(f"[VozRad] ⚠ intento sin clave correcta desde {origen}", flush=True)
            return JSONResponse({"error": "clave incorrecta"}, status_code=401)
    return await call_next(request)


@app.middleware("http")
async def red_privada(request: Request, call_next):
    # Chrome pide este permiso cuando una página https habla con 127.0.0.1
    resp = await call_next(request)
    resp.headers["Access-Control-Allow-Private-Network"] = "true"
    return resp


@app.get("/salud")
def salud():
    return {"ok": MODELO is not None}


@app.get("/estado")
def estado():
    import socket
    import actualizador
    return {"ok": MODELO is not None, "motor": DISPOSITIVO, "version": actualizador.version_actual(),
            "equipo": socket.gethostname(), "red": RED["activa"],
            "actualizacion": actualizador.ESTADO.get("disponible")}


# ---------------------------------------------------------------- actualizaciones con un clic
@app.get("/actualizacion")
def ver_actualizacion():
    import actualizador
    return actualizador.publico()


@app.post("/actualizacion/buscar")
def buscar_actualizacion():
    import actualizador
    return actualizador.buscar(texto.CONFIG.datos())


@app.post("/actualizacion/aplicar")
def aplicar_actualizacion():
    """Descarga e instala la versión nueva y reinicia el motor (los lanzadores lo vuelven a abrir solos)."""
    import actualizador
    if not actualizador.ESTADO.get("disponible"):
        actualizador.buscar(texto.CONFIG.datos())
    try:
        r = actualizador.aplicar()
    except Exception as e:  # noqa: BLE001
        print(f"[VozRad] No se pudo actualizar: {e}", flush=True)
        return {"ok": False, "error": str(e)}
    def reiniciar():
        time.sleep(1.0)
        os._exit(3)                       # código 3 = «reiniciar»: iniciar.bat / .command lo vuelven a abrir
    threading.Thread(target=reiniciar, daemon=True).start()
    return r


@app.get("/config")
def config():
    cfg = texto.CONFIG.datos()
    ruta_np = BASE / "nombres_propios.txt"
    propios = re.findall(r"[^\s#]+", "\n".join(l for l in ruta_np.read_text(encoding="utf-8").splitlines() if not l.startswith("#"))) if ruta_np.exists() else []
    return {"campos": cfg.get("campos", {}), "audio": cfg.get("audio", {}), "nombres_propios": sorted(set(propios) | texto._palabras_con_mayuscula()),
            "texto_en_vivo": cfg.get("texto_en_vivo", True)}


def terminos_prioritarios() -> str:
    ruta = BASE / "terminos_prioritarios.txt"
    if not ruta.exists():
        return ""
    t = [l.strip() for l in ruta.read_text(encoding="utf-8").splitlines() if l.strip() and not l.startswith("#")]
    return " ".join(t)[:400]


def _pcm(datos) -> np.ndarray:
    return np.frombuffer(base64.b64decode(datos["audio"]), dtype=np.int16).astype(np.float32) / 32768.0


def _reconocer(pcm, contexto: str, beam: int) -> str:
    return MODELO.reconocer(pcm, prompt=texto.prompt_inicial(contexto), hotwords=terminos_prioritarios(), beam=beam)


def _guardar_audio(pcm_bytes: bytes) -> str:
    """Guarda la frase (para entrenar el modelo con tu voz más adelante). Devuelve la ruta relativa."""
    ahora = dt.datetime.now()
    carpeta = HISTORIAL / "audio" / ahora.date().isoformat()
    carpeta.mkdir(parents=True, exist_ok=True)
    nombre = ahora.strftime("%H%M%S_%f")[:-3] + ".wav"
    with wave.open(str(carpeta / nombre), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000)
        w.writeframes(pcm_bytes)
    return f"audio/{ahora.date().isoformat()}/{nombre}"


@app.post("/parcial")
def parcial(datos: dict = Body(...)):
    """Texto en vivo mientras hablas. Si el motor está ocupado con una frase final, se salta."""
    if not GPU.acquire(blocking=False):
        return {"tipo": "ocupado"}
    try:
        t0 = time.perf_counter()
        motor = getattr(MODELO, "rapido", MODELO)
        crudo = motor.reconocer(_pcm(datos))
        return {"tipo": "parcial", "texto": crudo, "ms": int((time.perf_counter() - t0) * 1000)}
    finally:
        GPU.release()


PROVISIONALES = {}   # id -> (registro, audio, resultado): frases reconocidas por adelantado


@app.post("/transcribir")
def transcribir(datos: dict = Body(...)):
    """
    Cuerpo JSON: {"audio": base64 de PCM 16-bit mono 16 kHz, "contexto": "...", "campo": "hallazgos"}
    Con "provisional": true y "id": se reconoce por adelantado (apenas empiezas a callar) sin guardar nada;
    la extensión confirma con /confirmar si de verdad terminaste la frase.
    """
    crudo_bytes = base64.b64decode(datos["audio"])
    pcm = np.frombuffer(crudo_bytes, dtype=np.int16).astype(np.float32) / 32768.0
    if pcm.size < 16000 * 0.25:
        return {"tipo": "vacio"}
    cfg = texto.CONFIG.datos()
    ULTIMO_USO["t"] = time.time()
    with GPU:
        mot = sys.modules.get("motores")
        cr = sys.modules.get("contexto_radiologico")
        if mot:
            mot.ETAPAS.clear()
        if cr:
            cr.TIEMPOS.clear()
        fallos0 = mot.fallos_de_pagina() if mot else None
        t0 = time.perf_counter()
        crudo = _reconocer(pcm, datos.get("contexto", ""), cfg.get("beam_size", 1))
        ms = int((time.perf_counter() - t0) * 1000)
        etapas = None
        if ms > 1500 and mot:
            # frase lenta: anotar en qué se fue el tiempo
            etapas = dict(mot.ETAPAS)
            if cr:
                etapas.update(cr.TIEMPOS)
            f1 = mot.fallos_de_pagina()
            if fallos0 is not None and f1 is not None:
                etapas["fallos_pagina"] = f1 - fallos0
            print(f"[VozRad] frase lenta ({ms} ms): {etapas}", flush=True)
            _capturar_carga(ms)
        respaldo = getattr(MODELO, "ultimo_respaldo", False)
        punto_inferido = bool(getattr(getattr(MODELO, "rapido", MODELO), "punto_inferido", False)) and not respaldo
        punto_cola = bool(getattr(getattr(MODELO, "rapido", MODELO), "punto_por_cola_usado", False)) and not respaldo
        punto_diag = getattr(sys.modules.get("motores"), "ULTIMO_PUNTO", None) if not respaldo else None
        confianzas = None if respaldo else getattr(getattr(MODELO, "rapido", MODELO), "ultimas_confianzas", None)
    t1 = time.perf_counter()
    resultado = texto.procesar(crudo, pcm.size / 16000, respaldo, confianzas=confianzas)
    resultado["ms"] = ms
    resultado["ms_texto"] = int((time.perf_counter() - t1) * 1000)
    resultado["crudo"] = crudo

    registro = {
        "hora": dt.datetime.now().isoformat(timespec="seconds"),
        "campo": datos.get("campo"), "segundos_audio": round(pcm.size / 16000, 2),
        "ms": ms, "crudo": crudo, "resultado": resultado.get("texto") or resultado.get("accion"),
        "respaldo": respaldo,
    }
    if punto_inferido:
        registro["punto_inferido"] = True
    if punto_cola:
        registro["punto_cola"] = True
    if punto_diag and not punto_cola:
        registro["punto_diag"] = punto_diag
    if etapas:
        registro["etapas"] = etapas
    if resultado.get("predichas"):
        registro["predichas"] = resultado["predichas"]
    if datos.get("provisional") and datos.get("id"):
        PROVISIONALES[str(datos["id"])] = (registro, crudo_bytes, resultado)
        while len(PROVISIONALES) > 5:
            PROVISIONALES.pop(next(iter(PROVISIONALES)))
        return resultado
    _registrar(registro, crudo_bytes, resultado)
    return resultado


def _registrar(registro, crudo_bytes, resultado, adelantada=False):
    cfg = texto.CONFIG.datos()
    if cfg.get("guardar_historial", True) and cfg.get("guardar_audio", True) and resultado.get("tipo") == "texto":
        try:
            registro["audio"] = _guardar_audio(crudo_bytes)
        except OSError:
            pass
    guardar_historial(registro)
    if registro.get("respaldo"):
        print("        (Parakeet dejó la frase incompleta: se usó Canary)", flush=True)
    marca = " ⚡" if adelantada else ""
    if registro.get("punto_inferido"):
        marca += " (punto añadido)"
    if registro.get("punto_cola"):
        marca += " (punto oído al final)"
    if registro.get("predichas"):
        marca += " (predicho: " + ", ".join(f"{a}→{b}" for a, b in registro["predichas"]) + ")"
    if registro.get("punto_inferido"):
        pass
    elif registro.get("punto_diag"):
        d = registro["punto_diag"]
        marca += f" [.{d.get('hueco')}{'/' + str(d['voz']) if d.get('voz') is not None else ''}]"
    print(f"[{registro['ms']:>5} ms | {registro['segundos_audio']:4.1f} s audio]{marca} {registro['crudo']!r} -> "
          f"{resultado.get('texto', resultado.get('accion'))!r}", flush=True)


@app.post("/confirmar")
def confirmar(datos: dict = Body(...)):
    """La frase reconocida por adelantado era la definitiva: se guarda en el historial."""
    x = PROVISIONALES.pop(str(datos.get("id")), None)
    if x:
        _registrar(*x, adelantada=True)
    return {"ok": bool(x)}


# ---------------------------------------------------------------- prueba de calidad del micrófono
def _db(x):
    return float(20 * np.log10(max(float(x), 1e-7)))


def _palabras_iguales(esperado: str, obtenido: str) -> float:
    """Porcentaje de palabras reconocidas bien (1 - tasa de error por palabra)."""
    a, b = texto.normalizar(esperado).split(), texto.normalizar(obtenido).split()
    if not a:
        return 0.0
    d = list(range(len(b) + 1))
    for i in range(1, len(a) + 1):
        previo, d[0] = d[0], i
        for j in range(1, len(b) + 1):
            previo, d[j] = d[j], min(d[j] + 1, d[j - 1] + 1, previo + (a[i - 1] != b[j - 1]))
    return max(0.0, 1 - d[len(b)] / len(a)) * 100


@app.post("/calidad")
def calidad(datos: dict = Body(...)):
    """
    {"silencio": base64 PCM (2 s callado), "voz": base64 PCM (lectura de la frase), "esperado": "...",
     "microfono": "...", "procesamiento": {...}}  ->  mediciones y consejos.
    """
    def leer(clave):
        b = base64.b64decode(datos.get(clave) or b"")
        return np.frombuffer(b, dtype=np.int16).astype(np.float32) / 32768.0

    sil, voz = leer("silencio"), leer("voz")
    if voz.size < 16000:
        return {"ok": False, "motivo": "La grabación de voz es muy corta."}
    trama = 480                                   # 30 ms
    def rms_tramas(x):
        n = x.size // trama
        return np.sqrt(np.mean(x[: n * trama].reshape(n, trama) ** 2, axis=1)) if n else np.zeros(1)

    r_sil = rms_tramas(sil - np.mean(sil)) if sil.size else np.zeros(1)
    ruido = float(np.median(r_sil)) if sil.size else float(np.percentile(rms_tramas(voz), 10))
    r_voz = rms_tramas(voz - np.mean(voz))
    hablado = r_voz[r_voz > max(ruido * 4, 0.003)]
    nivel = float(np.sqrt(np.mean(hablado ** 2))) if hablado.size else float(np.sqrt(np.mean(r_voz ** 2)))
    pico = float(np.max(np.abs(voz)))
    saturacion = float(np.mean(np.abs(voz) > 0.985) * 100)
    snr = _db(nivel) - _db(ruido)
    zumbido = 0.0
    if sil.size >= 16000:
        esp = np.abs(np.fft.rfft((sil - np.mean(sil)) * np.hanning(sil.size))) ** 2
        f = np.fft.rfftfreq(sil.size, 1 / 16000)
        red = sum(esp[(f > c - 3) & (f < c + 3)].sum() for c in (50, 100, 150))
        zumbido = float(red / max(esp[f > 20].sum(), 1e-12) * 100)
    # ancho de banda: un micrófono bueno tiene voz por encima de 4 kHz (consonantes s, f, t)
    espv = np.abs(np.fft.rfft(voz - np.mean(voz))) ** 2
    fv = np.fft.rfftfreq(voz.size, 1 / 16000)
    agudos = float(espv[(fv > 4000) & (fv < 7800)].sum() / max(espv[(fv > 100) & (fv < 7800)].sum(), 1e-12) * 100)

    with GPU:
        t0 = time.perf_counter()
        crudo = MODELO.reconocer(voz)
        ms = int((time.perf_counter() - t0) * 1000)
    obtenido = texto.procesar(crudo).get("texto", crudo) if crudo else ""
    precision = _palabras_iguales(datos.get("esperado", ""), obtenido)

    def nota(valor, bueno, regular, mayor_es_mejor=True):
        if mayor_es_mejor:
            return "bien" if valor >= bueno else "regular" if valor >= regular else "mal"
        return "bien" if valor <= bueno else "regular" if valor <= regular else "mal"

    niv_db = _db(nivel)
    items = [
        {"nombre": "Volumen de tu voz", "valor": f"{niv_db:.0f} dB",
         "nota": "mal" if niv_db < -40 or saturacion > 0.5 else "regular" if niv_db < -32 or niv_db > -8 else "bien"},
        {"nombre": "Ruido de fondo", "valor": f"{_db(ruido):.0f} dB", "nota": nota(_db(ruido), -55, -42, False)},
        {"nombre": "Voz sobre ruido", "valor": f"{snr:.0f} dB", "nota": nota(snr, 25, 15)},
        {"nombre": "Saturación", "valor": f"{saturacion:.2f} %", "nota": nota(saturacion, 0.05, 0.5, False)},
        {"nombre": "Nitidez (agudos)", "valor": f"{agudos:.1f} %", "nota": nota(agudos, 2.0, 0.7)},
        {"nombre": "Reconocimiento", "valor": f"{precision:.0f} %", "nota": nota(precision, 95, 85)},
        {"nombre": "Velocidad del motor", "valor": f"{ms / 1000:.1f} s para {voz.size / 16000:.0f} s de voz".replace(".", ","),
         "nota": nota(ms / max(voz.size / 16000, 1), 0.12, 0.25, False)},
    ]
    consejos = []
    if niv_db < -32:
        consejos.append("Tu voz llega baja: acerca el SpeechMike a 5-10 cm de la boca o sube el nivel del micrófono en "
                        "Windows (Configuración > Sistema > Sonido > Entrada > Volumen, 80-100).")
    if saturacion > 0.05 or niv_db > -8 or pico > 0.995:
        consejos.append("La voz satura (se recorta): baja el volumen del micrófono en Windows a ~70 o aleja un poco el SpeechMike.")
    if _db(ruido) > -42 or snr < 15:
        consejos.append("Hay mucho ruido de fondo (ventilador, aire acondicionado, conversación): aléjate de la fuente "
                        "o habla más cerca del micrófono.")
    if zumbido > 25:
        consejos.append(f"Se detecta zumbido eléctrico de 50 Hz ({zumbido:.0f}% del ruido): prueba otro puerto USB "
                        "(directo al PC, no a un hub ni al monitor).")
    if agudos < 0.7:
        consejos.append("El sonido llega apagado (pocos agudos): revisa que el micrófono elegido sea el SpeechMike "
                        "y no la cámara o el micrófono del monitor.")
    proc = datos.get("procesamiento") or {}
    if any(proc.get(k) for k in ("echoCancellation", "noiseSuppression", "autoGainControl")):
        consejos.append("El navegador está filtrando el audio (cancelación de eco / ruido): eso empeora el reconocimiento.")
    mic = datos.get("microfono", "")
    if mic and not re.search(r"speechmike|philips", mic, re.I):
        consejos.append(f"El micrófono en uso es «{mic}», no el SpeechMike. Elige el SpeechMike en el panel "
                        "o como dispositivo de entrada predeterminado de Windows.")
    if precision < 85 and not consejos:
        consejos.append("El audio está bien: los errores son del motor. Usa «Entrenar palabra» con los términos que fallen.")
    notas = [i["nota"] for i in items[:5]]
    general = "mal" if "mal" in notas else "regular" if "regular" in notas else "bien"
    print(f"[VozRad] Prueba de micrófono: {general} | voz {niv_db:.0f} dB, ruido {_db(ruido):.0f} dB, "
          f"S/R {snr:.0f} dB, saturación {saturacion:.2f}%, reconocimiento {precision:.0f}%", flush=True)
    return {"ok": True, "general": general, "items": items, "consejos": consejos, "obtenido": obtenido,
            "microfono": mic}


@app.post("/plantillas/importar")
def importar_plantillas(datos: dict = Body(...)):
    """Plantillas leídas de MultiRisWeb. Reemplaza las importadas antes; no toca las tuyas."""
    ruta = BASE / "plantillas.json"
    actuales = json.loads(ruta.read_text(encoding="utf-8")) if ruta.exists() else {}
    actuales.setdefault("plantillas", {}); actuales.setdefault("frases", {})
    (BASE / "plantillas_respaldo.json").write_text(json.dumps(actuales, ensure_ascii=False, indent=2), encoding="utf-8")
    actuales["plantillas"] = {k: v for k, v in actuales["plantillas"].items() if not (isinstance(v, dict) and v.get("_ris"))}
    voz = datos.get("voz_modalidad", {})
    lista = datos.get("plantillas", [])
    base = [re.sub(r"[.\s]+$", "", texto.normalizar(p.get("nombre", ""))) for p in lista]
    repetidos = {b for b in base if base.count(b) > 1}
    nombres = []
    for p, b in zip(lista, base):
        if not b or not p.get("contenido"):
            continue
        nombre = b
        if b in repetidos or nombre in actuales["plantillas"]:
            mod = voz.get(re.split(r"[\s-]+", p.get("modalidad", "").strip())[0].upper(), p.get("modalidad", "").lower())
            nombre = f"{b} {mod}".strip()
        n, i = nombre, 2
        while n in actuales["plantillas"]:
            n, i = f"{nombre} {i}", i + 1
        actuales["plantillas"][n] = {**p["contenido"], "_ris": p.get("id"), "_modalidad": p.get("modalidad")}
        nombres.append(n)
    ruta.write_text(json.dumps(actuales, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[VozRad] {len(nombres)} plantillas importadas desde el RIS", flush=True)
    return {"importadas": len(nombres), "nombres": sorted(nombres)}


def _agregar_a_lista(archivo: str, termino: str):
    """Agrega un término a vocabulario.txt / terminos_prioritarios.txt (parte manual) si no está."""
    ruta = BASE / archivo
    actual = ruta.read_text(encoding="utf-8") if ruta.exists() else ""
    if termino.lower() in {l.strip().lower() for l in actual.splitlines()}:
        return
    marca = "# ---- automático"
    if marca in actual:
        i = actual.index(marca)
        nuevo = actual[:i].rstrip("\n") + "\n" + termino + "\n\n" + actual[i:]
    else:
        nuevo = actual.rstrip("\n") + "\n" + termino + "\n"
    ruta.write_text(nuevo, encoding="utf-8")


FUNCIONALES = {"ni", "de", "en", "y", "o", "la", "el", "los", "las", "con", "sin", "a", "al", "del", "un", "una", "se"}


def _forma_de_palabra(palabra: str) -> str:
    """«Próstata» o «Vena porta» seleccionadas al inicio de una oración: la mayúscula es por posición.
    Se guardan en minúscula salvo epónimos (Wirsung) y siglas (TC)."""
    if re.fullmatch(r"[A-ZÁÉÍÓÚÑ][a-záéíóúñü]+(?:\s.*)?", palabra):
        primera = palabra.split()[0].lower()
        propias = texto._palabras_con_mayuscula()
        if primera not in propias and texto._sin_tildes_simple(primera) not in propias:
            return palabra[0].lower() + palabra[1:]      # «Colecistectomizada» -> «colecistectomizada»
    return palabra


@app.post("/entrenar")
def entrenar(datos: dict = Body(...)):
    """
    Entrenar palabra: el radiólogo dice la palabra; se ve qué escribe el motor y se guarda
    que eso debe escribirse como la palabra correcta.
    """
    palabra = re.sub(r"\s+", " ", datos.get("palabra", "")).strip(" .,;:")
    crudo_bytes = base64.b64decode(datos["audio"])
    return _entrenar(palabra, crudo_bytes, guardar=True)


def _entrenar(palabra: str, crudo_bytes: bytes, guardar: bool = True) -> dict:
    pcm = np.frombuffer(crudo_bytes, dtype=np.int16).astype(np.float32) / 32768.0
    if not palabra or pcm.size < 16000 * 0.3:
        return {"ok": False, "motivo": "sin palabra o audio muy corto"}
    motores_a_probar = [m for m in (getattr(MODELO, "rapido", None), getattr(MODELO, "respaldo", None)) if m] or [MODELO]
    with GPU:
        escuchado = [m.reconocer(pcm) for m in motores_a_probar]
    aprendido, comunes, correcto, aviso = [], [], False, ""
    escuchado = [texto.solo_latino(c).strip() for c in escuchado]
    palabra = _forma_de_palabra(palabra)
    # si la palabra entrenada tiene una corrección conocida («isquiorectales» -> «isquiorrectales»), se aprende hacia la correcta
    palabra = texto.CORRECCIONES.datos().get("palabras", {}).get(palabra.lower(), palabra)
    try:
        import contexto
        uni = contexto.MODELO.uni
    except Exception:  # noqa: BLE001
        uni = {}
    usada = lambda w: uni.get(texto.normalizar(w), 0)  # noqa: E731  veces que aparece en tus informes
    desconocida = all(usada(w) < 3 and texto._frecuencia_es_solo(w.lower()) < 1.5 for w in palabra.split())
    limpios = []
    for crudo in escuchado:
        limpio = texto.aplicar_puntuacion(crudo, "dictada")
        limpio = re.sub(r"[.,;:¿?¡!()\"\n]+", " ", limpio)
        limpio = re.sub(r"\s+", " ", limpio).strip().lower()
        # "ni andorminales" al entrenar "endoluminales": el "ni" no es parte de la palabra
        partes = limpio.split()
        while len(partes) > 1 and partes[0] in FUNCIONALES and not palabra.lower().startswith(partes[0]):   # «un cuartrosis» = uncoartrosis
            partes = partes[1:]
        limpios.append(" ".join(partes))
    # ¿la palabra a entrenar está mal escrita? (p. ej. se seleccionó la palabra MAL reconocida)
    if desconocida and any(l and usada(l) >= 5 for l in limpios):
        aviso = (f"«{palabra}» no aparece en tus informes ni en el diccionario, y el motor oyó «{next(l for l in limpios if usada(l) >= 5)}», "
                 "que sí usas. ¿Seleccionaste la palabra mal reconocida? No aprendí nada: selecciona la palabra BIEN escrita.")
        limpios = []
    for limpio in limpios:
        if not limpio:
            continue
        if limpio == palabra.lower():
            correcto = True
            continue
        if len(limpio.split()) > 5:
            continue
        if len(limpio.split()) == 1 and (texto._frecuencia_es(limpio) > 3.5 or usada(limpio) >= 5):
            comunes.append(limpio)       # palabra real que usas: reemplazarla siempre sería peligroso
            continue
        if len(limpio.split()) >= 2 and all(texto._frecuencia_es_solo(w) >= 4 for w in limpio.split()):
            comunes.append(limpio)       # expresión común del español («a pie», «así dice»): podría ser real
            continue
        aprendizaje.aceptar(limpio, palabra)
        aprendido.append({"de": limpio, "a": palabra})
    if not aviso:
        _agregar_a_lista("vocabulario.txt", palabra)
        _agregar_a_lista("terminos_prioritarios.txt", palabra)
    if guardar:
        try:
            carpeta = HISTORIAL / "entrenamiento"
            carpeta.mkdir(parents=True, exist_ok=True)
            nombre = re.sub(r"[^\w-]+", "_", palabra)[:40] + dt.datetime.now().strftime("_%Y%m%d_%H%M%S_%f")[:-3] + ".wav"
            with wave.open(str(carpeta / nombre), "wb") as w:
                w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000); w.writeframes(crudo_bytes)
            _marcar_entrenado(nombre)
        except OSError:
            pass
    print(f"[VozRad] Entrenar «{palabra}»: escuché {escuchado} -> aprendí {[x['de'] for x in aprendido]}", flush=True)
    return {"ok": True, "escuchado": escuchado, "aprendido": aprendido, "comunes": comunes, "correcto": correcto,
            "aviso": aviso, "palabra": palabra}


def _procesados_path():
    return HISTORIAL / "entrenamiento" / "procesados.json"


def _marcar_entrenado(nombre: str):
    p = _procesados_path()
    hechos = set(json.loads(p.read_text(encoding="utf-8"))) if p.exists() else set()
    hechos.add(nombre)
    p.write_text(json.dumps(sorted(hechos), ensure_ascii=False), encoding="utf-8")


def reentrenar_desde_audios():
    """Vuelve a aprender las palabras entrenadas a partir de los audios guardados en historial/entrenamiento
    (tras importar un perfil en otro computador, o si se perdieron las correcciones). Solo los no procesados."""
    carpeta = HISTORIAL / "entrenamiento"
    if not carpeta.exists():
        return
    hechos = set(json.loads(_procesados_path().read_text(encoding="utf-8"))) if _procesados_path().exists() else set()
    pendientes = sorted(p for p in carpeta.glob("*.wav") if p.name not in hechos)
    if not pendientes:
        return
    print(f"[VozRad] Reentrenando {len(pendientes)} audios de «Entrenar palabra»...", flush=True)
    palabras = {}
    for p in pendientes:
        m = re.match(r"(.+)_\d{8}_\d{6}_\d{3}$", p.stem)
        palabra = (m.group(1) if m else p.stem).replace("_", " ")
        try:
            with wave.open(str(p), "rb") as w:
                datos = w.readframes(w.getnframes())
            r = _entrenar(palabra, datos, guardar=False)
            palabras.setdefault(palabra, []).extend(x["de"] for x in r.get("aprendido", []))
            if r.get("aviso"):
                print(f"         «{palabra}»: {r['aviso'][:120]}", flush=True)
        except Exception as e:  # noqa: BLE001
            print(f"         no pude usar {p.name}: {e}", flush=True)
        _marcar_entrenado(p.name)
    print(f"[VozRad] Listo: {len(palabras)} palabras reentrenadas ({', '.join(palabras)})", flush=True)


# ------------------------------------------------------------------ plantillas (menú del panel, 27-11)
def _modalidad(texto_: str) -> str:
    """Modalidad a partir del título o del nombre: TC, RM, ECO, RX, MG, DXA ('' si no se sabe)."""
    t = texto.normalizar(texto_ or "")
    for mod, pat in (("RM", r"\b(resonancia|rm|rnm|angio ?rm|colangio ?resonancia)\b"),
                     ("TC", r"\b(tomografia|tc|tac|scanner|angio ?tc|pet ?ct|uro ?tac|pielotac)\b"),
                     ("ECO", r"\b(ecografia|eco|doppler|ecotomografia|ultrasonido|eco ?doppler)\b"),
                     ("MG", r"\b(mamografia|mamografias|tomosintesis)\b"),
                     ("DXA", r"\b(densitometria)\b"),
                     ("RX", r"\b(radiografia|radiografias|rx|columna total|teleradiografia|telerradiografia|edad osea)\b")):
        if re.search(pat, t):
            return mod
    return ""


_MOD_RIS = {"CT": "TC", "MR": "RM", "US": "ECO", "CR - DX": "RX", "DX - CR": "RX", "DX": "RX", "CR": "RX",
            "MG": "MG", "DXA": "DXA"}


def _texto_de(v) -> str:
    return (v if isinstance(v, str) else (v or {}).get("texto", "")) or ""


@app.get("/plantillas")
def ver_plantillas():
    """Tus plantillas con su modalidad y texto por campo (menú del panel)."""
    out = []
    for nombre, v in (texto.PLANTILLAS.datos().get("plantillas") or {}).items():
        if not isinstance(v, dict):
            continue
        try:
            limpio = texto.limpiar_plantilla({k: x for k, x in v.items() if not k.startswith("_")})
        except Exception:  # noqa: BLE001
            limpio = {k: x for k, x in v.items() if not k.startswith("_")}
        campos = {k: _texto_de(x).strip() for k, x in limpio.items()}
        mod = v.get("_mod_vozrad") or _MOD_RIS.get(str(v.get("_modalidad") or "").strip().upper(), "") \
            or _modalidad(campos.get("titulo", "") + " " + nombre)
        out.append({"nombre": nombre, "modalidad": mod, "campos": campos, "ris": bool(v.get("_ris"))})
    out.sort(key=lambda x: x["nombre"])
    return {"plantillas": out}


@app.get("/plantillas/contenido")
def contenido_plantilla(nombre: str):
    """Lo mismo que «plantilla <nombre>» por voz: para insertarla con un clic."""
    p = texto.PLANTILLAS.datos().get("plantillas") or {}
    if nombre not in p:
        return {"ok": False}
    return {"ok": True, "nombre": nombre,
            "contenido": texto.limpiar_plantilla({k: v for k, v in p[nombre].items() if not k.startswith("_")})}


@app.post("/plantillas/guardar")
def guardar_plantilla(datos: dict = Body(...)):
    """Crea o edita una plantilla. Editada en el panel queda como tuya (una nueva importación del RIS no la pisa)."""
    nombre = re.sub(r"\s+", " ", texto.normalizar(datos.get("nombre", ""))).strip()
    campos = {k: (v or "").strip() for k, v in (datos.get("campos") or {}).items() if k in ETIQUETAS_CAMPOS and (v or "").strip()}
    if not nombre or not any(k != "titulo" for k in campos):
        return {"ok": False, "motivo": "falta el nombre o el texto"}
    ruta = BASE / "plantillas.json"
    actuales = json.loads(ruta.read_text(encoding="utf-8")) if ruta.exists() else {}
    actuales.setdefault("plantillas", {}); actuales.setdefault("frases", {})
    anterior = re.sub(r"\s+", " ", texto.normalizar(datos.get("anterior", ""))).strip()
    if anterior and anterior != nombre and anterior in actuales["plantillas"]:
        actuales["plantillas"].pop(anterior)
    nueva = nombre not in actuales["plantillas"]
    (BASE / "plantillas_respaldo.json").write_text(json.dumps(actuales, ensure_ascii=False, indent=2), encoding="utf-8")
    p = dict(campos)
    p["_mod_vozrad"] = (datos.get("modalidad") or "").strip() or _modalidad(campos.get("titulo", "") + " " + nombre)
    actuales["plantillas"][nombre] = p
    ruta.write_text(json.dumps(actuales, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[VozRad] Plantilla {'nueva' if nueva else 'editada'}: «{nombre}» ({p['_mod_vozrad'] or 'sin modalidad'})", flush=True)
    return {"ok": True, "nombre": nombre, "nueva": nueva}


@app.post("/plantillas/borrar")
def borrar_plantilla(datos: dict = Body(...)):
    ruta = BASE / "plantillas.json"
    actuales = json.loads(ruta.read_text(encoding="utf-8")) if ruta.exists() else {}
    (BASE / "plantillas_respaldo.json").write_text(json.dumps(actuales, ensure_ascii=False, indent=2), encoding="utf-8")
    actuales.get("plantillas", {}).pop(datos.get("nombre", ""), None)
    ruta.write_text(json.dumps(actuales, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": True}


ETIQUETAS_CAMPOS = ("titulo", "tecnica", "antecedentes", "hallazgos", "impresion")


@app.post("/frases/agregar")
def agregar_frase(datos: dict = Body(...)):
    nombre = re.sub(r"\s+", " ", texto.normalizar(datos.get("nombre", ""))).strip()
    contenido = (datos.get("texto") or "").strip()
    if not nombre or not contenido:
        return {"ok": False, "motivo": "falta nombre o texto"}
    ruta = BASE / "plantillas.json"
    actuales = json.loads(ruta.read_text(encoding="utf-8")) if ruta.exists() else {}
    actuales.setdefault("plantillas", {}); actuales.setdefault("frases", {})
    reemplazo = nombre in actuales["frases"]
    actuales["frases"][nombre] = contenido
    ruta.write_text(json.dumps(actuales, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": True, "nombre": nombre, "reemplazo": reemplazo}


@app.get("/frases")
def ver_frases():
    """Tus frases tipo con su texto (para la lista del panel)."""
    p = texto.PLANTILLAS.datos()
    return {"frases": {k: texto._texto_frase(v) for k, v in p.get("frases", {}).items()}}


@app.post("/frases/borrar")
def borrar_frase(datos: dict = Body(...)):
    ruta = BASE / "plantillas.json"
    actuales = json.loads(ruta.read_text(encoding="utf-8")) if ruta.exists() else {}
    actuales.get("frases", {}).pop(datos.get("nombre", ""), None)
    ruta.write_text(json.dumps(actuales, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": True}


@app.post("/diagnostico")
def diagnostico(datos: dict = Body(...)):
    """Algo raro que la extensión detectó (p. ej. una frase repetida bloqueada): queda en esta ventana y en el historial."""
    if datos.get("tipo") == "insercion":
        if not texto.CONFIG.datos().get("diagnostico_insercion"):
            return {"ok": True}
        print(f"      [inserción {datos.get('campo')}/{datos.get('bloque')}{' tras salto' if datos.get('salto') else ''}] "
              f"antes=«{datos.get('previo')}» escrito=«{datos.get('listo')}»", flush=True)
        return {"ok": True}
    else:
        print(f"[VozRad] ⚠ FRASE REPETIDA BLOQUEADA ({datos.get('tipo')}): antes={datos.get('antes')!r} ahora={datos.get('ahora')!r} "
              f"texto={datos.get('texto')!r}", flush=True)
    guardar_historial({"hora": dt.datetime.now().isoformat(timespec="seconds"), "diagnostico": datos})
    return {"ok": True}


@app.post("/esperar")
def esperar(datos: dict = Body(...)):
    """Pausa para el importador (la pestaña del navegador no la frena aunque esté en segundo plano)."""
    time.sleep(min(max(float(datos.get("ms", 0)), 0), 5000) / 1000)
    return {"ok": True}


@app.get("/ayuda")
def ayuda():
    """Datos para la ventana de ayuda del panel: tus plantillas, frases y comandos."""
    p = texto.PLANTILLAS.datos()
    cfg = texto.CONFIG.datos()
    return {
        "plantillas": sorted(p.get("plantillas", {})),
        "frases": sorted(p.get("frases", {})),
        "campos": {k: {"boton": v.get("boton", ""), "alias": v.get("alias", [])} for k, v in cfg.get("campos", {}).items()},
        "deshacer": cfg.get("comandos", {}).get("deshacer", []),
        "detener": cfg.get("comandos", {}).get("detener", []),
        "motor": DISPOSITIVO,
    }


@app.get("/sugerencias")
def ver_sugerencias():
    return {"sugerencias": aprendizaje.sugerencias()}


@app.post("/sugerencias/aceptar")
def aceptar_sugerencia(datos: dict = Body(...)):
    aprendizaje.aceptar(datos["de"], datos["a"])
    return {"ok": True}


@app.post("/sugerencias/rechazar")
def rechazar_sugerencia(datos: dict = Body(...)):
    aprendizaje.rechazar(datos["de"], datos["a"])
    return {"ok": True}


@app.get("/estadisticas")
def ver_estadisticas():
    return aprendizaje.estadisticas()


@app.post("/aprender")
async def aprender(request: Request):
    """La extensión envía lo que se insertó y cómo quedó después de tu corrección manual."""
    datos = await request.json()
    HISTORIAL.mkdir(exist_ok=True)
    with open(HISTORIAL / "correcciones_manuales.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps({"hora": dt.datetime.now().isoformat(timespec="seconds"), **datos},
                           ensure_ascii=False) + "\n")
    aprendidas = []
    cfg = texto.CONFIG.datos()
    if cfg.get("aprendizaje_automatico", True):
        try:
            aprendidas = aprendizaje.auto_aprender(cfg.get("veces_para_aprender", 2))
        except Exception as e:  # noqa: BLE001
            print(f"[VozRad] aviso aprendizaje: {e}", flush=True)
    for x in aprendidas:
        print(f"[VozRad] Aprendí: «{x['de']}» -> «{x['a']}»", flush=True)
    return {"ok": True, "aprendidas": aprendidas}


@app.post("/aprendizaje/deshacer")
def deshacer_aprendizaje(datos: dict = Body(...)):
    for x in datos.get("lista", []):
        aprendizaje.deshacer(x["de"], x["a"])
    return {"ok": True}


@app.post("/importar")
async def importar(request: Request):
    """Recibe el PDF de un informe antiguo (desde el importador de la extensión) y lo guarda anonimizado."""
    datos = await request.json()
    try:
        return informes.importar(str(datos.get("id_informe", "")), base64.b64decode(datos["pdf"]))
    except Exception as e:  # noqa: BLE001
        return {"guardado": False, "motivo": f"{type(e).__name__}: {e}"}


def _ips_locales() -> list:
    import socket
    ips = set()
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sk:
            sk.connect(("10.255.255.255", 1))          # no envía nada: solo elige la interfaz de la red local
            ips.add(sk.getsockname()[0])
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    return sorted(ip for ip in ips if not ip.startswith("127."))


def _preparar_red():
    """Modo red: genera (una vez) la clave y la guarda en config.json."""
    import secrets
    ruta = BASE / "config.json"
    cfg = json.loads(ruta.read_text(encoding="utf-8"))
    clave = str(cfg.get("clave_red") or "").strip().upper()
    if not clave:
        letras = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        clave = "-".join("".join(secrets.choice(letras) for _ in range(4)) for _ in range(3))
        cfg["clave_red"] = clave
        ruta.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    RED.update(activa=True, clave=clave)


CONTEXTO = {"estado": "apagado"}


def _parakeets():
    """Los motores Parakeet cargados (solo o dentro del híbrido)."""
    out = []
    for m in (MODELO, getattr(MODELO, "rapido", None)):
        if m is not None and getattr(m, "nombre", "") == "parakeet" and m not in out:
            out.append(m)
    return out


def _preparar_contexto(cfg_ctx: dict):
    """Contexto radiológico en el reconocimiento (contexto_radiologico.py). Nunca deja al motor sin funcionar."""
    try:
        import contexto_radiologico
        estados = [contexto_radiologico.preparar(m.modelo, cfg_ctx) for m in _parakeets()]
        CONTEXTO["estado"] = estados[0] if estados else "no disponible con este motor"
    except Exception as e:  # noqa: BLE001
        CONTEXTO["estado"] = f"error ({e})"
        try:
            import contexto_radiologico
            for m in _parakeets():
                contexto_radiologico.preparar(m.modelo, {"activo": False})
        except Exception:  # noqa: BLE001
            pass
    print(f"[VozRad] Contexto radiológico: {CONTEXTO['estado']}", flush=True)


@app.get("/contexto")
def ver_contexto():
    cfg = dict(texto.CONFIG.datos().get("contexto_radiologico") or {})
    return {"activo": bool(cfg.get("activo")), "estado": CONTEXTO["estado"], "alfa": cfg.get("alfa"), "orden": cfg.get("orden")}


@app.post("/contexto")
def cambiar_contexto(datos: dict = Body(...)):
    ruta = BASE / "config.json"
    cfg = json.loads(ruta.read_text(encoding="utf-8"))
    ctx = dict(cfg.get("contexto_radiologico") or {})
    ctx["activo"] = bool(datos.get("activo"))
    cfg["contexto_radiologico"] = ctx
    ruta.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    _preparar_contexto(ctx)
    return ver_contexto()


def _preparar_lenguaje():
    """Carga (o arma, si tus informes cambiaron) el modelo de lenguaje radiológico, sin hacer esperar."""
    import threading

    def tarea():
        try:
            import lenguaje
            import motores
            fuentes = [BASE / "informes" / "informes.jsonl", BASE / "historial" / "correcciones_manuales.jsonl",
                       BASE / "plantillas.json", BASE / "correcciones.json"]
            viejo = not lenguaje.ARCHIVO.exists() or any(
                f.exists() and f.stat().st_mtime > lenguaje.ARCHIVO.stat().st_mtime + 3600 for f in fuentes)
            if viejo:
                # en un proceso aparte (~100 s con 30.000+ informes): dentro del motor frenaba el dictado
                import subprocess
                flags = (0x00000040 | 0x08000000) if os.name == "nt" else 0
                r = subprocess.run([sys.executable, "-c", "import lenguaje; lenguaje.construir()"], cwd=str(BASE),
                                   creationflags=flags, timeout=1800, capture_output=True)
                if r.returncode != 0:
                    lenguaje.construir()
                while time.time() - ULTIMO_USO["t"] < 20:      # leerlo cuando no estés dictando
                    time.sleep(5)
            lenguaje.MODELO.cargar()
            cfg_lm = motores.MotorParakeet.lenguaje or {}
            if cfg_lm.get("activo"):
                print(f"[VozRad] Oído radiológico activo (alfa {cfg_lm.get('alfa', 0.5)}, beta {cfg_lm.get('beta', 1.0)})", flush=True)
        except Exception as e:  # noqa: BLE001
            print(f"[VozRad] aviso: no se pudo preparar el modelo de lenguaje ({e})", flush=True)
    threading.Thread(target=tarea, daemon=True).start()


def _puerto_libre(puerto: int, esperar_s: float = 12) -> bool:
    """¿Está libre el puerto? Se reintenta unos segundos: tras una actualización, el motor anterior
    acaba de cerrarse y el sistema tarda un momento en liberar el puerto."""
    import socket
    fin = time.time() + esperar_s
    while True:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sk:
            if os.name != "nt":
                sk.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)   # igual que el servidor web
            try:
                sk.bind(("0.0.0.0" if RED["activa"] else "127.0.0.1", puerto))
                return True
            except OSError:
                if time.time() > fin:
                    return False
        time.sleep(1)


if __name__ == "__main__":
    if "--puerto" in sys.argv:
        CFG["puerto"] = int(sys.argv[sys.argv.index("--puerto") + 1])
    _p = CFG.get("puerto", 8765)
    if "--red" in sys.argv or "--servidor" in sys.argv:
        _preparar_red()
    if "--servidor" in sys.argv:
        RED["proxy"] = True                 # detrás del proxy HTTPS del servidor: la clave se pide SIEMPRE
    if not _puerto_libre(_p):
        print("[VozRad] VozRad YA ESTÁ ABIERTO en otra ventana (o quedó abierto de antes).")
        print("         No hace falta abrirlo dos veces: usa esa ventana, o ciérrala y vuelve a abrir esta.")
        sys.exit(1)
    try:
        import migraciones
        migraciones.aplicar()
        texto.CONFIG._mtime = None; texto.CORRECCIONES._mtime = None
    except Exception as e:  # noqa: BLE001
        print(f"[VozRad] aviso: no se pudieron actualizar los datos ({e})")
    try:
        cargar_modelo()
    except Exception as e:  # noqa: BLE001
        print()
        print("[VozRad] No pude cargar el motor de voz.")
        if not (BASE / "modelos" / "hf").exists() or "Proxy" in str(e) or "Connection" in str(e) or "resolve" in str(e).lower():
            print("         La primera vez hay que DESCARGAR el modelo (~1,6 GB): revisa que haya internet y vuelve a abrir «iniciar».")
        print(f"         Detalle: {type(e).__name__}: {str(e)[:200]}")
        sys.exit(1)
    try:
        import contexto
        t0 = time.perf_counter()
        contexto.EN_REPOSO = lambda: time.time() - ULTIMO_USO["t"] > 20
        contexto.MODELO.cargar()
        if not contexto.COPIA.exists():
            contexto.MODELO._guardar_copia()
        print(f"[VozRad] Modelo de contexto: {len(contexto.MODELO.uni)} palabras de tus informes ({time.perf_counter() - t0:.1f} s)")
    except Exception as e:  # noqa: BLE001
        print(f"[VozRad] aviso: modelo de contexto no disponible ({e})")
    threading.Thread(target=reentrenar_desde_audios, daemon=True).start()
    threading.Thread(target=mantener_tarjeta_despierta, daemon=True).start()
    subir_prioridad()
    try:
        import actualizador
        actualizador.revisar_periodicamente(texto.CONFIG.datos, cada_horas=1)
    except Exception as e:  # noqa: BLE001
        print(f"[VozRad] aviso: buscador de actualizaciones no disponible ({e})")
    puerto = CFG.get("puerto", 8765)
    if RED.get("proxy"):
        print(f"[VozRad] Modo servidor: escuchando en 127.0.0.1:{puerto} detrás del proxy HTTPS · clave {RED['clave']}", flush=True)
        uvicorn.run(app, host="127.0.0.1", port=puerto, log_level="warning")
    elif RED["activa"]:
        import socket
        print("")
        print("[VozRad] ===== MOTOR EN RED =====")
        print("  En el otro computador, en el panel de VozRad pulsa ⚙ y escribe:")
        for ip in _ips_locales():
            print(f"     Dirección:  {ip}")
        print(f"     (o el nombre: {socket.gethostname().split('.')[0]}.local)")
        print(f"     Clave:      {RED['clave']}")
        print("  Deja esta ventana abierta y el computador encendido y enchufado.")
        print("[VozRad] =========================")
        print("")
        uvicorn.run(app, host="0.0.0.0", port=puerto, log_level="warning")
    else:
        print(f"[VozRad] Escuchando en http://127.0.0.1:{puerto}  (deja esta ventana abierta)")
        uvicorn.run(app, host="127.0.0.1", port=puerto, log_level="warning")

"""
VozRad - al actualizar, suma a TUS archivos (config.json, correcciones.json) lo nuevo de la versión,
sin borrar lo que tú agregaste o aceptaste. Se ejecuta solo al iniciar el servidor.
"""
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent


def aplicar():
    ruta_mig = BASE / "actualizacion_datos.json"
    if not ruta_mig.exists():
        return
    mig = json.loads(ruta_mig.read_text(encoding="utf-8"))
    ruta_cfg, ruta_cor = BASE / "config.json", BASE / "correcciones.json"
    cfg = json.loads(ruta_cfg.read_text(encoding="utf-8"))
    if cfg.get("_version_datos", 0) >= mig["version"]:
        return
    for k, v in mig.get("config", {}).items():
        reemplazables = mig.get("config_reemplazar_si", {}).get(k)
        if k not in cfg or (reemplazables and cfg.get(k) in reemplazables) or k.startswith("_ayuda"):
            cfg[k] = v
    cor = json.loads(ruta_cor.read_text(encoding="utf-8")) if ruta_cor.exists() else {"palabras": {}, "reglas": []}
    pal = cor.setdefault("palabras", {})
    nuevas = 0
    for de, a in mig.get("palabras", {}).items():
        if de not in pal:
            pal[de] = a
            nuevas += 1
    patrones = {r.get("patron") for r in cor.setdefault("reglas", [])}
    for r in mig.get("reglas", []):
        if r.get("patron") not in patrones:
            cor["reglas"].append(r)
            nuevas += 1
    # limpieza de aprendizajes equivocados (p. ej. una palabra entrenada al revés)
    # cada limpieza se hace UNA sola vez: si después vuelves a aceptar ese par, se respeta (antes se borraba en
    # cada actualización y la sugerencia volvía a aparecer). En instalaciones que ya las recibieron antes
    # (sin registro), se dan por hechas sin volver a borrar.
    limpiezas = [f"destino:{x.lower()}" for x in mig.get("borrar_si_destino", [])] + \
                [f"par:{de.lower()}->{str(a).lower()}" for de, a in mig.get("borrar_pares", {}).items()]
    if "_limpiezas_hechas" not in cor and cfg.get("_version_datos", 0) > 0:
        cor["_limpiezas_hechas"] = sorted(set(limpiezas))
    hechas = set(cor.setdefault("_limpiezas_hechas", []))
    destinos_malos = {x.lower() for x in mig.get("borrar_si_destino", []) if f"destino:{x.lower()}" not in hechas}
    for de in list(pal):
        if str(pal[de]).lower() in destinos_malos:
            del pal[de]
    for de, a in mig.get("borrar_pares", {}).items():
        if f"par:{de.lower()}->{str(a).lower()}" in hechas:
            continue
        if str(pal.get(de, "")).lower() == a.lower():
            del pal[de]
    cor["_limpiezas_hechas"] = sorted(hechas | set(limpiezas))
    destinos = {k.lower(): v for k, v in mig.get("corregir_destinos", {}).items()}
    for de in list(pal):
        if str(pal[de]).lower() in destinos:
            pal[de] = destinos[str(pal[de]).lower()]       # aprendido hacia una forma mal escrita
    for de, a in mig.get("agregar_tras_borrar", {}).items():
        pal.setdefault(de, a)
    if mig.get("minusculas_aprendidas"):
        # «Próstata», «Vena porta» aprendidas con mayúscula por estar al inicio de una oración
        try:
            from wordfreq import zipf_frequency
            ruta_np = BASE / "nombres_propios.txt"
            propios = {w.lower() for w in ruta_np.read_text(encoding="utf-8").split()} if ruta_np.exists() else set()
            def minus(v):
                if isinstance(v, str) and len(v) > 1 and v[0].isupper() and v[1:2].islower():
                    w = v.split()[0].lower()
                    if w not in propios:
                        return v[0].lower() + v[1:]
                return v
            for de in pal:
                pal[de] = minus(pal[de])
            for nombre in ("vocabulario.txt", "terminos_prioritarios.txt"):
                r = BASE / nombre
                if r.exists():
                    lineas = r.read_text(encoding="utf-8").splitlines()
                    quitar = {x.lower() for x in mig.get("quitar_vocabulario", [])}
                    nuevas_l, auto = [], False
                    for l in lineas:
                        auto = auto or l.startswith("# ---- automático")
                        if l.strip().lower() in quitar:
                            continue
                        nuevas_l.append(l if auto or l.startswith("#") else minus(l))
                    r.write_text("\n".join(nuevas_l) + "\n", encoding="utf-8")
        except Exception as e:  # noqa: BLE001
            print(f"[VozRad] aviso migración: {e}", flush=True)
    # epónimos nuevos (nombres_propios.txt es tuyo y la actualización no lo reemplaza: solo se agregan los que faltan)
    if mig.get("nombres_propios"):
        try:
            r = BASE / "nombres_propios.txt"
            actual = r.read_text(encoding="utf-8") if r.exists() else ""
            ya = {w.lower() for w in actual.split()}
            faltan = [w for w in mig["nombres_propios"] if w.lower() not in ya]
            if faltan:
                r.write_text(actual.rstrip("\n") + "\n" + " ".join(faltan) + "\n", encoding="utf-8")
        except OSError:
            pass
    if mig.get("romanos") and "romanos" not in cor:
        cor["romanos"] = mig["romanos"]
    cfg["_version_datos"] = mig["version"]
    ruta_cor.write_text(json.dumps(cor, ensure_ascii=False, indent=2), encoding="utf-8")
    ruta_cfg.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[VozRad] Datos actualizados: {nuevas} correcciones nuevas agregadas (las tuyas se mantienen).", flush=True)

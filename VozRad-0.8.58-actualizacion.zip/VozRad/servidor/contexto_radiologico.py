"""
VozRad - contexto radiológico en el reconocimiento (idea de Álvaro, 23-11-2026).

Cuando Parakeet duda entre trozos de palabra que suenan parecido, se suma lo probable que es cada trozo
según un modelo de idioma armado con TUS informes radiológicos (radiologia-N.arpa, que arma
entrenar/contexto.sh en el PC). Así gana «intersticiales» sobre «interticiales» o «hemitórax» sobre
«semitórax».

Es la misma fusión que hace NVIDIA NeMo («greedy_batch» con ngram_lm_model), medida en tu turno de prueba
(24-11): 10,60 % -> 8,43 % de palabras erradas con orden 5 y alfa 0,2, sin más errores en
lateralidad/negación/severidad:
  · el modelo decide primero, sin contexto, si en ese instante hay palabra o silencio (blank): el contexto
    nunca agrega ni borra palabras;
  · solo si hay un trozo, se elige el mejor entre  puntaje del oído + alfa * modelo de idioma.

El modelo de idioma queda solo en el PC (C:\\VozRad\\entrenamiento\\contexto): contiene tus informes y nunca
se publica ni sale del computador.
"""
import math
import pickle
import time
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent
CARPETAS = [BASE.parent / "entrenamiento" / "contexto"]
OFFSET = 100             # cada trozo del tokenizador es el carácter chr(id + 100) en el ARPA
BOS = "\x01"
TIEMPOS = {}   # ms de decodificación y de contexto acumulados (servidor.py los reinicia en cada frase)
LN10 = math.log(10.0)


class ModeloIdioma:
    """Modelo n-grama (ARPA) sobre trozos del tokenizador de Parakeet, con retroceso (backoff)."""

    def __init__(self, ruta: Path, vocab: int):
        self.ruta, self.V = Path(ruta), int(vocab)
        self.orden = 1
        self.uni = None          # log-prob (ln) de cada trozo sin contexto
        self.ctx = {}            # historia -> (backoff, inicio, fin) en ids/lps
        self.ids = self.lps = None
        self._cache = {}
        self._cargar()

    # ---------------------------------------------------------------- carga (con copia rápida .pkl)
    def _cargar(self):
        cache = self.ruta.with_suffix(f".v{self.V}.pkl")
        if cache.exists() and cache.stat().st_mtime >= self.ruta.stat().st_mtime:
            try:
                with open(cache, "rb") as f:
                    d = pickle.load(f)
                self.orden, self.uni, self.ctx, self.ids, self.lps = d["orden"], d["uni"], d["ctx"], d["ids"], d["lps"]
                return
            except Exception:  # noqa: BLE001
                pass
        self._leer_arpa()
        try:
            with open(cache, "wb") as f:
                pickle.dump({"orden": self.orden, "uni": self.uni, "ctx": self.ctx, "ids": self.ids, "lps": self.lps}, f,
                            protocol=pickle.HIGHEST_PROTOCOL)
        except OSError:
            pass

    @staticmethod
    def _clave(palabras):
        out = []
        for w in palabras:
            if w == "<s>":
                out.append(BOS)
            elif w in ("</s>", "<unk>"):
                return None
            elif len(w) == 1:
                out.append(w)
            else:
                return None
        return "".join(out)

    def _leer_arpa(self):
        V = self.V
        uni = np.full(V, -np.inf, dtype=np.float32)
        unk = None
        bow = {}
        suc = {}
        n = 0
        # newline="\n": algunos trozos son caracteres que Python también considera salto de línea
        with open(self.ruta, encoding="utf-8", newline="\n") as f:
            for linea in f:
                linea = linea.rstrip("\n").rstrip("\r")
                if not linea:
                    continue
                if linea.startswith("\\"):
                    if linea.endswith("-grams:"):
                        n = int(linea[1:].split("-")[0])
                        self.orden = max(self.orden, n)
                    continue
                if n == 0:
                    continue
                campos = linea.split("\t")
                if len(campos) < 2:
                    continue
                lp = float(campos[0]) * LN10
                palabras = campos[1].split(" ")
                b = float(campos[2]) * LN10 if len(campos) > 2 else 0.0
                if n == 1 and palabras[0] == "<unk>":
                    unk = lp
                    continue
                k = self._clave(palabras)
                if k is None or len(k) != n:
                    continue
                if b:
                    bow[k] = b
                if n == 1:
                    if k != BOS:
                        i = ord(k) - OFFSET
                        if 0 <= i < V:
                            uni[i] = lp
                    continue
                i = ord(k[-1]) - OFFSET
                if 0 <= i < V and k[-1] != BOS:
                    suc.setdefault(k[:-1], []).append((i, lp))
        faltan = int(np.sum(~np.isfinite(uni)))
        if unk is not None and faltan:
            uni[~np.isfinite(uni)] = unk - (math.log(faltan) if faltan > 1 else 0.0)   # como NeMo (normalize_unk)
        self.uni = uni
        ids, lps, ctx = [], [], {}
        pos = 0
        for h in set(bow) | set(suc):
            lista = suc.get(h, [])
            ctx[h] = (bow.get(h, 0.0), pos, pos + len(lista))
            ids += [i for i, _ in lista]
            lps += [p for _, p in lista]
            pos += len(lista)
        self.ctx = ctx
        self.ids = np.asarray(ids, dtype=np.int32)
        self.lps = np.asarray(lps, dtype=np.float32)

    # ---------------------------------------------------------------- uso
    def inicio(self) -> str:
        return BOS

    def avanzar(self, historia: str, token: int) -> str:
        return (historia + chr(token + OFFSET))[-(self.orden - 1):] if self.orden > 1 else ""

    def puntajes(self, historia: str) -> np.ndarray:
        """log P(trozo | historia) para todos los trozos (ln), con retroceso como en un ARPA."""
        v = self._cache.get(historia)
        if v is not None:
            return v
        v = self.uni.copy()
        for k in range(1, len(historia) + 1):
            e = self.ctx.get(historia[-k:])
            if e is None:
                continue
            b, i0, i1 = e
            if b:
                v += b
            if i1 > i0:
                v[self.ids[i0:i1]] = self.lps[i0:i1]
        if len(self._cache) > 20000:
            self._cache.clear()
        self._cache[historia] = v
        return v


def buscar_arpa(orden: int | None = None):
    for c in CARPETAS:
        if orden:
            p = c / f"radiologia-{orden}.arpa"
            if p.exists():
                return p
        else:
            ps = sorted(c.glob("radiologia-*.arpa"))
            if ps:
                return ps[-1]
    return None


class Fusion:
    """Reemplaza el decodificador de onnx-asr (Parakeet TDT) por uno con el modelo de idioma."""

    def __init__(self, asr, lm: ModeloIdioma, alfa: float):
        self.asr, self.lm, self.alfa = asr, lm, float(alfa)
        self.original = asr._decoding
        V = asr._blank_idx
        vocab = getattr(asr, "_vocab", {}) or {}
        # signos (. , : etc.): tus informes están en forma dictada («coma», «punto»), así que el modelo de idioma
        # no los conoce; se dejan como los oyó el motor y no se eligen por contexto
        self.signo = np.array([not any(c.isalnum() for c in vocab.get(i, "")) for i in range(V)], dtype=bool)
        self.minus = [vocab.get(i, "").lower() for i in range(V)]

    def activar(self):
        self.asr._decoding = self._decoding

    def desactivar(self):
        self.asr._decoding = self.original

    def _decoding(self, encoder_out, encoder_out_lens, /, **kwargs):
        asr, lm, alfa = self.asr, self.lm, self.alfa
        need_logprobs = kwargs.get("need_logprobs")
        blank = asr._blank_idx
        max_pasos = asr._max_tokens_per_step
        if getattr(asr, "use_low_precision", False):
            encoder_out_lens = np.minimum(encoder_out_lens, encoder_out.shape[1])
        t_ini = time.perf_counter()
        t_lm = 0.0
        for enc, largo in zip(encoder_out, encoder_out_lens, strict=True):
            estado = asr._create_state()
            tokens, tiempos, logprobs = [], [], []
            hist = lm.inicio()
            t = emitidos = 0
            while t < largo:
                logits, paso, nuevo = asr._decode(tokens, estado, enc[t])
                token = int(logits.argmax())
                if token != blank:
                    # solo se re-elige entre trozos (nunca se cambia «hay palabra» por «silencio» ni al revés)
                    if not self.signo[token]:
                        t1 = time.perf_counter()
                        s = logits[:blank] + alfa * lm.puntajes(hist)
                        t_lm += time.perf_counter() - t1
                        s[self.signo] = -np.inf
                        elegido = int(np.argmax(s))
                        if self.minus[elegido] != self.minus[token]:     # mayúsculas: como las oyó el motor
                            token = elegido
                        hist = lm.avanzar(hist, token)
                    estado = nuevo
                    tokens.append(token)
                    tiempos.append(t)
                    emitidos += 1
                    if need_logprobs:
                        m = float(np.max(logits))
                        logprobs.append(float(logits[token]) - m - math.log(float(np.sum(np.exp(logits - m)))))
                if paso > 0:
                    t += paso
                    emitidos = 0
                elif token == blank or emitidos == max_pasos:
                    t += 1
                    emitidos = 0
            TIEMPOS["decodificar"] = TIEMPOS.get("decodificar", 0) + int((time.perf_counter() - t_ini) * 1000)
            TIEMPOS["contexto"] = TIEMPOS.get("contexto", 0) + int(t_lm * 1000)
            t_ini, t_lm = time.perf_counter(), 0.0
            yield tokens, tiempos, logprobs if need_logprobs else None


_MODELOS = {}


def preparar(adaptador, cfg: dict):
    """Activa o desactiva el contexto en el motor (adaptador de onnx-asr). Devuelve un texto de estado."""
    asr = getattr(adaptador, "asr", None)
    if asr is None or not all(hasattr(asr, a) for a in ("_decoding", "_decode", "_create_state", "_blank_idx",
                                                       "_max_tokens_per_step")):
        return "no disponible con este motor"
    previo = getattr(asr, "_vozrad_fusion", None)
    if previo:
        previo.desactivar()
        asr._vozrad_fusion = None
    if not (cfg or {}).get("activo"):
        return "apagado"
    ruta = None
    if cfg.get("archivo"):
        ruta = next((c / cfg["archivo"] for c in CARPETAS if (c / cfg["archivo"]).exists()), None)
    ruta = ruta or buscar_arpa(cfg.get("orden"))
    if ruta is None:
        return "falta el modelo de idioma (se arma con entrenar/contexto.sh en el PC)"
    clave = (str(ruta), ruta.stat().st_mtime, asr._blank_idx)   # si se rearma el archivo, se vuelve a leer
    t0 = time.time()
    if clave not in _MODELOS:
        _MODELOS.clear()
        _MODELOS[clave] = ModeloIdioma(ruta, asr._blank_idx)
    lm = _MODELOS[clave]
    f = Fusion(asr, lm, float(cfg.get("alfa", 0.2)))
    f.activar()
    asr._vozrad_fusion = f
    return f"activo ({ruta.name}, orden {lm.orden}, alfa {f.alfa:g}, {time.time() - t0:.1f} s)"

"""
VozRad - ¿por qué a veces una frase tarda 2-4 s? Mide el decodificador de Parakeet (el paso que se repite
trozo por trozo) en la tarjeta gráfica vs. en el procesador, con la tarjeta libre y con la tarjeta ocupada
por otro programa (simulado), usando frases de tu turno de prueba. No cambia nada de VozRad.

Uso:  .venv\\Scripts\\python medir_decodificador.py      -> C:\\VozRad\\entrenamiento\\resultado-decodificador.txt
"""
import datetime as dt
import json
import os
import sys
import threading
import time
import wave
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
ENT = BASE.parent / "entrenamiento"
N = 60


def _wav(ruta: str):
    p = Path("C:/" + ruta[7:]) if ruta.startswith("/mnt/c/") else Path(ruta)
    with wave.open(str(p)) as w:
        return np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0


def main():
    import onnxruntime as ort
    import motores
    import texto
    cfg = dict(texto.CONFIG.datos())
    par = motores.MotorParakeet(None, cfg.get("dispositivo", "cuda"))
    par.punto_por_cola = False
    asr = par.modelo.asr
    gpu_sesion = asr._decoder_joint
    carpeta = next((BASE / "modelos" / "hf" / "hub").glob("models--istupakov--parakeet-tdt-0.6b-v3-onnx/snapshots/*"))
    op = ort.SessionOptions()
    op.intra_op_num_threads = 1          # un paso pequeño: más hilos solo agregan espera
    cpu32 = ort.InferenceSession(str(carpeta / "decoder_joint-model.onnx"), op, providers=["CPUExecutionProvider"])
    cpu8 = ort.InferenceSession(str(carpeta / "decoder_joint-model.int8.onnx"), op, providers=["CPUExecutionProvider"])
    filas = [json.loads(l) for l in (ENT / "datos" / "prueba.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
    filas = sorted(filas, key=lambda f: -f.get("duration", 0))[:N]
    audios = [_wav(f["audio_filepath"]) for f in filas]
    L = [f"VozRad - decodificador en tarjeta vs procesador ({dt.datetime.now():%d-%m-%Y %H:%M}) · {N} frases largas", ""]

    # carga en la tarjeta (simula otro programa usándola, p. ej. un visor de imágenes): Canary en bucle
    ocupar = threading.Event()
    def carga():
        can = motores.MotorCanary(None, cfg.get("dispositivo", "cuda"))
        x = np.concatenate(audios[:3])
        while True:
            ocupar.wait()
            try:
                can.modelo.asr._encode(*can.modelo.asr._preprocessor(x[None, :], np.array([x.size])))
            except Exception:  # noqa: BLE001
                time.sleep(0.05)
    threading.Thread(target=carga, daemon=True).start()

    ref = None
    for nombre, ses, ocupada in (("tarjeta (actual)", gpu_sesion, False), ("procesador fp32", cpu32, False),
                                 ("procesador int8", cpu8, False), ("tarjeta (actual), tarjeta OCUPADA", gpu_sesion, True),
                                 ("procesador fp32, tarjeta OCUPADA", cpu32, True)):
        asr._decoder_joint = ses
        if ocupada:
            ocupar.set(); time.sleep(8)
        else:
            ocupar.clear(); time.sleep(2)
        tiempos, textos = [], []
        for a in audios:
            t0 = time.perf_counter()
            textos.append(par.reconocer(a))
            tiempos.append((time.perf_counter() - t0) * 1000)
        t = np.array(tiempos)
        iguales = "" if ref is None else f" · texto igual en {sum(x == y for x, y in zip(ref, textos))}/{N}"
        ref = ref or textos
        L.append(f"{nombre:<36} mediana {np.median(t):5.0f} ms · p90 {np.percentile(t, 90):5.0f} ms · máx {t.max():5.0f} ms{iguales}")
        print(L[-1], flush=True)
    asr._decoder_joint = gpu_sesion
    (ENT / "resultado-decodificador.txt").write_text("\n".join(L) + "\n", encoding="utf-8")
    os._exit(0)


if __name__ == "__main__":
    main()

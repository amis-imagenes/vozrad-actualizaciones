"""
VozRad - arma los datos para entrenar el reconocedor con TU voz (fase 2 del plan de entrenamiento).

Lee
  servidor/historial                      lo dictado en este equipo (audio + lo que oyó el motor)
  entrenamiento/<equipo>/historial        copias traídas de otros equipos (p. ej. entrenamiento/mac/historial)
y junta cada frase dictada con cómo quedó en el informe guardado. El texto objetivo queda en la forma
HABLADA que entrega el motor («siete coma cinco milímetros punto»), con las palabras médicas corregidas
según tu informe final. Solo se usan frases donde la diferencia es claramente un error de reconocimiento:
si cambiaste la redacción, un número, la lateralidad, una negación o la severidad, la frase se descarta.

Escribe en entrenamiento/datos/
  entrenar.jsonl  validar.jsonl  prueba.jsonl   (manifiestos para NeMo; prueba = las frases más recientes)
y en el Escritorio VozRad-entrenamiento-resumen.txt (horas, descartes y ejemplos para revisión; sin audio).

No cambia nada de VozRad, no copia ni mueve audios y no usa internet.
"""
import collections
import datetime as dt
import difflib
import json
import os
import random
import re
import sys
import unicodedata
import wave
from pathlib import Path

BASE = Path(__file__).resolve().parent
RAIZ = BASE.parent
sys.path.insert(0, str(BASE))
SALIDA = RAIZ / "entrenamiento" / "datos"

SEG_MIN, SEG_MAX = 0.5, 30.0
PROP_PRUEBA = 0.12          # las frases más recientes, nunca se usan para entrenar
CADA_VALIDAR = 20           # 1 de cada 20 del resto
MAX_COMANDOS = 0.10         # frases que son solo un comando («Punto aparte.»): como máximo 10 %

COMANDO = {"punto", "coma", "comas", "coman", "aparte", "seguido", "parrafo", "guion", "salto", "puntos"}
NUEVA = {"nueva", "nuevo", "nueba", "nova", "nuova", "nueve", "noma"}
ABRE = {"abre", "abrir", "abro", "abra", "cierra", "cerrar", "cierre", "cierro"}
RELLENO = {"eh", "ehh", "em", "emm", "mm", "mmm", "ah", "ehm"}
# nunca se «aprende» un cambio que toque estas palabras (puede ser una corrección de contenido tuya)
PROTEGIDAS = {"derecho", "derecha", "derechos", "derechas", "izquierdo", "izquierda", "izquierdos", "izquierdas",
              "bilateral", "bilaterales", "unilateral", "no", "sin", "con", "ni", "ningun", "ninguna", "ninguno",
              "leve", "leves", "moderado", "moderada", "moderados", "moderadas", "severo", "severa", "severos",
              "severas", "grave", "graves", "importante", "discreto", "discreta", "marcado", "marcada", "mayor",
              "menor", "superior", "inferior", "superiores", "inferiores", "anterior", "posterior", "medial",
              "lateral", "proximal", "distal", "interno", "interna", "externo", "externa", "normal", "normales",
              "anormal", "positivo", "negativo", "aumento", "disminucion", "aumentado", "disminuido"}
_NUMPAL = {"cero", "un", "uno", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez",
           "once", "doce", "trece", "catorce", "quince", "dieciseis", "diecisiete", "dieciocho", "diecinueve",
           "veinte", "veinti", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa",
           "cien", "ciento", "mil", "medio", "media", "milimetros", "milimetro", "centimetros", "centimetro",
           "por", "x", "mm", "cm", "ml", "cc", "hu"}
_TOKEN = re.compile(r"[^\W\d_]+|\d+(?:[.,]\d+)?", re.U)


def clave(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s.lower()) if unicodedata.category(c) != "Mn")


def tokens(s: str):
    return [(m.group(), clave(m.group()), m.start(), m.end()) for m in _TOKEN.finditer(s or "")]


def es_numero(k: str) -> bool:
    return k[0].isdigit() or k in _NUMPAL or k.startswith("veinti")


def marcar_comandos(ks):
    """True en las palabras del motor que son comandos dictados (punto, coma, nueva línea, dos puntos...)."""
    n = len(ks)
    cmd = [False] * n
    for i, k in enumerate(ks):
        sig = ks[i + 1] if i + 1 < n else ""
        ant = ks[i - 1] if i else ""
        if k in COMANDO:
            cmd[i] = True
        if k in NUEVA and sig in ("linea", "linia", "lina", "parrafo"):
            cmd[i] = cmd[i + 1] = True
        if k == "dos" and sig == "puntos":
            cmd[i] = cmd[i + 1] = True
        if k == "y" and ant == "punto" and sig in ("aparte", "seguido", "coma", "a"):
            cmd[i] = True
        if k in ABRE and sig in ("parentesis", "comillas", "comilla"):
            cmd[i] = cmd[i + 1] = True
        if k in ("parte", "aparta") and (ant == "punto" or (i == 0 and n <= 3) or (ant == "a" and i >= 2 and ks[i - 2] == "punto")):
            cmd[i] = True
            if ant == "a":
                cmd[i - 1] = True
    return cmd


def ventana(crudo_ks, final_ks):
    """Trozo del informe final que corresponde a la frase (índices) o None."""
    d = [k for k in crudo_ks if k not in COMANDO]
    if len(d) < 2 or not final_ks:
        return None
    sm = difflib.SequenceMatcher(None, d, final_ks, autojunk=False)
    bloques = [b for b in sm.get_matching_blocks() if b.size]
    if not bloques or sum(b.size for b in bloques) / len(d) < 0.5:
        return None
    ini = max(0, bloques[0].b - bloques[0].a)
    fin = min(len(final_ks), bloques[-1].b + bloques[-1].size + (len(d) - bloques[-1].a - bloques[-1].size))
    if not (0.6 * len(d) <= fin - ini <= 1.6 * len(d)):
        return None
    if difflib.SequenceMatcher(None, d, final_ks[ini:fin], autojunk=False).ratio() < 0.6:
        return None
    return ini, fin


def equivale_por_vozrad(palabras_crudo: str, final_ks) -> bool:
    """Lo que VozRad escribe con esas palabras (cifras, mm, L5-S1, romanos, tus correcciones) = lo del informe."""
    import texto
    try:
        r = texto.procesar(palabras_crudo)
    except Exception:  # noqa: BLE001
        return False
    return r.get("tipo") == "texto" and [t[1] for t in tokens(r.get("texto", ""))] == list(final_ks)


def procesado(crudo: str):
    """Palabras que VozRad escribe con la frase (cifras, siglas, correcciones aplicadas), o None."""
    import texto
    try:
        r = texto.procesar(crudo)
    except Exception:  # noqa: BLE001
        return None
    return [t[1] for t in tokens(r.get("texto", ""))] if r.get("tipo") == "texto" else None


def mismas_cifras(crudo: str, final_ks) -> bool:
    """Las cifras que escribe VozRad con la frase completa son las mismas (y en el mismo orden) que las del informe."""
    import texto
    try:
        r = texto.procesar(crudo)
    except Exception:  # noqa: BLE001
        return False
    if r.get("tipo") != "texto":
        return False
    hechas = [t[1] for t in tokens(r.get("texto", "")) if t[1][0].isdigit()]
    return hechas == [k for k in final_ks if k[0].isdigit()]


def forma_final(tok_final, texto_final):
    """Palabra del informe tal como debe quedar en el objetivo (sin la mayúscula de inicio de oración)."""
    pal, _, ini, _ = tok_final
    if len(pal) >= 2 and pal.isupper():
        return pal                                          # siglas: TC, AP, HNP
    antes = texto_final[:ini].rstrip()
    if pal[:1].isupper() and (not antes or antes[-1] in ".:\n;!?"):
        return pal[:1].lower() + pal[1:]                    # mayúscula solo por empezar la oración
    return pal


def objetivo(crudo: str, final: str):
    """(texto objetivo, hubo_arreglo, motivo_descarte)."""
    tc, tf = tokens(crudo), tokens(final)
    ks = [t[1] for t in tc]
    cmd = marcar_comandos(ks)
    if not tc:
        return None, False, "vacía"
    if all(cmd[i] or ks[i] in RELLENO for i in range(len(ks))):
        return crudo.strip(), False, None                   # solo comandos: se aprende tal cual
    v = ventana(procesado(crudo) or ks, [t[1] for t in tf])
    if not v:
        return None, False, "no está en el informe"
    tf = tf[v[0]:v[1]]
    fk = [t[1] for t in tf]
    reemplazos = []                                         # (ini, fin, texto) sobre el crudo
    hubo = False
    cifras_ok = None                                        # ¿VozRad deja las mismas cifras que el informe?
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, ks, fk, autojunk=False).get_opcodes():
        if op == "equal":
            continue
        idx = list(range(i1, i2))
        while idx and cmd[idx[0]]:
            idx.pop(0)
        while idx and cmd[idx[-1]]:
            idx.pop()
        nuevas = tf[j1:j2]
        if any(es_numero(ks[i]) for i in idx) or any(es_numero(t[1]) for t in nuevas):
            if cifras_ok is None:
                cifras_ok = mismas_cifras(crudo, fk)
            if cifras_ok:
                continue                                    # cifras y unidades: VozRad ya las deja como el informe
            return None, False, "número o medida distinta"
        if any(cmd[i] for i in idx):
            return None, False, "comando en medio de un cambio"
        idx = [i for i in idx if ks[i] not in RELLENO] if op == "delete" else idx
        if not idx and not nuevas:
            continue                                        # solo se borraron comandos o muletillas
        if not idx:
            return None, False, "el informe tiene palabras que no se dictaron"
        if not nuevas:
            return None, False, "se borraron palabras dictadas"
        ck = [ks[i] for i in idx]
        nk = [t[1] for t in nuevas]
        texto_c = crudo[tc[idx[0]][2]:tc[idx[-1]][3]]
        if any(len(t[0]) <= 3 and t[0].isupper() for t in nuevas):
            if equivale_por_vozrad(texto_c, nk):
                continue                                    # siglas: VozRad ya lo deja bien
            return None, False, "sigla distinta"
        if (set(ck) | set(nk)) & PROTEGIDAS:
            if equivale_por_vozrad(texto_c, nk):
                continue
            return None, False, "lateralidad/negación/severidad"
        parecido = difflib.SequenceMatcher(None, " ".join(ck), " ".join(nk), autojunk=False).ratio()
        if parecido >= 0.5 and abs(len(ck) - len(nk)) <= 1:
            nuevo = " ".join(forma_final(t, final) for t in nuevas)
            if tc[idx[0]][0][:1].isupper():
                nuevo = nuevo[:1].upper() + nuevo[1:]
            reemplazos.append((tc[idx[0]][2], tc[idx[-1]][3], nuevo))
            hubo = True
            continue
        if equivale_por_vozrad(texto_c, nk):
            continue                                        # ya lo arreglan tus correcciones
        return None, False, "redacción cambiada"
    s = crudo
    for ini, fin, nuevo in sorted(reemplazos, reverse=True):
        s = s[:ini] + nuevo + s[fin:]
    return re.sub(r"\s+", " ", s).strip(), hubo, None


# ---------------------------------------------------------------- lectura del historial
def fuentes():
    out = [("este equipo", BASE / "historial")]
    carpeta = RAIZ / "entrenamiento"
    if carpeta.exists():
        for h in sorted(carpeta.glob("*/historial")):
            out.append((h.parent.name, h))
    return [(n, h) for n, h in out if h.exists()]


def leer_jsonl(ruta: Path):
    if not ruta.exists():
        return
    for l in ruta.read_text(encoding="utf-8", errors="ignore").splitlines():
        try:
            yield json.loads(l)
        except json.JSONDecodeError:
            continue


def duracion(wav: Path):
    try:
        with wave.open(str(wav)) as w:
            return w.getnframes() / float(w.getframerate())
    except Exception:  # noqa: BLE001
        return None


def ruta_wsl(p: Path) -> str:
    p = p.resolve()
    if os.name == "nt" and p.drive:
        return f"/mnt/{p.drive[0].lower()}" + p.as_posix()[2:]
    return p.as_posix()


def frases(nombre, hist: Path, motivos: collections.Counter):
    registros = {}
    for arch in sorted(hist.glob("20??-??-??.jsonl")):
        for r in leer_jsonl(arch):
            if r.get("audio") and r.get("crudo"):
                registros[r["crudo"].strip()] = r
    finales = {}
    for r in leer_jsonl(hist / "correcciones_manuales.jsonl"):        # el último guardado manda
        for it in r.get("dictado", []):
            c = (it.get("crudo") or "").strip()
            fin = (r.get("final") or {}).get(it.get("campo"), "") or ""
            if c and fin:
                finales[c] = fin
    for crudo, r in registros.items():
        wav = hist / r["audio"]
        seg = duracion(wav)
        if seg is None:
            motivos["audio no encontrado"] += 1
            continue
        if not (SEG_MIN <= seg <= SEG_MAX):
            motivos["muy corta o muy larga"] += 1
            continue
        ks = [t[1] for t in tokens(crudo)]
        cmd = marcar_comandos(ks)
        solo_cmd = bool(ks) and all(cmd[i] or ks[i] in RELLENO for i in range(len(ks)))
        if not solo_cmd and crudo not in finales:
            motivos["sin informe guardado"] += 1
            continue
        obj, hubo, motivo = objetivo(crudo, finales.get(crudo, ""))
        if motivo:
            motivos[motivo] += 1
            continue
        fecha = wav.parent.name
        yield {"audio_filepath": ruta_wsl(wav), "duration": round(seg, 2), "text": obj, "crudo": crudo,
               "fuente": nombre, "fecha": fecha, "orden": f"{fecha}/{wav.name}", "arreglo": hubo, "comando": solo_cmd}


def main():
    random.seed(7)
    motivos = collections.Counter()
    todas, vistos = [], set()
    srcs = fuentes()
    if not srcs:
        print("[VozRad] No encontré ningún historial.")
        return 1
    for nombre, hist in srcs:
        n0 = len(todas)
        print(f"[VozRad] Leyendo {nombre}: {hist}", flush=True)
        for f in frases(nombre, hist, motivos):
            k = (f["orden"], f["crudo"])
            if k not in vistos:
                vistos.add(k)
                todas.append(f)
        print(f"[VozRad]   {len(todas) - n0} frases útiles", flush=True)
    comandos = [f for f in todas if f["comando"]]
    texto_f = [f for f in todas if not f["comando"]]
    tope = int(MAX_COMANDOS * len(texto_f))
    if len(comandos) > tope:
        random.shuffle(comandos)
        motivos["comandos sobrantes (se usa una parte)"] += len(comandos) - tope
        comandos = comandos[:tope]
    todas = sorted(texto_f + comandos, key=lambda f: f["orden"])
    if not todas:
        print("[VozRad] No quedó ninguna frase útil.")
        return 1
    n_prueba = max(1, int(PROP_PRUEBA * len(todas)))
    prueba, resto = todas[-n_prueba:], todas[:-n_prueba]
    validar = [f for i, f in enumerate(resto) if i % CADA_VALIDAR == CADA_VALIDAR - 1]
    entrenar = [f for i, f in enumerate(resto) if i % CADA_VALIDAR != CADA_VALIDAR - 1]
    SALIDA.mkdir(parents=True, exist_ok=True)
    for nombre, lista in (("entrenar", entrenar), ("validar", validar), ("prueba", prueba)):
        with open(SALIDA / f"{nombre}.jsonl", "w", encoding="utf-8") as fh:
            for f in lista:
                fh.write(json.dumps(f, ensure_ascii=False) + "\n")

    horas = lambda lista: sum(f["duration"] for f in lista) / 3600  # noqa: E731
    arreglos = [f for f in todas if f["arreglo"]]
    cambios = collections.Counter()
    for f in arreglos:
        a, b = [t[0] for t in tokens(f["crudo"])], [t[0] for t in tokens(f["text"])]
        for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, [clave(x) for x in a], [clave(x) for x in b]).get_opcodes():
            if op != "equal":
                cambios[(" ".join(a[i1:i2]).lower(), " ".join(b[j1:j2]))] += 1
    L = [f"VozRad - datos de entrenamiento ({dt.datetime.now():%d-%m-%Y %H:%M})", "",
         "Fuentes: " + ", ".join(f"{n} ({h})" for n, h in srcs), "",
         f"Frases útiles: {len(todas)} = {horas(todas):.2f} h de voz",
         f"  entrenar: {len(entrenar)} ({horas(entrenar):.2f} h)   validar: {len(validar)} ({horas(validar):.2f} h)"
         f"   prueba: {len(prueba)} ({horas(prueba):.2f} h, desde {prueba[0]['fecha']})",
         f"  con alguna palabra corregida según tu informe: {len(arreglos)}   solo comandos: {len(comandos)}", "",
         "Frases descartadas:"] + [f"  {m}: {n}" for m, n in motivos.most_common()] + ["",
         "Palabras corregidas más frecuentes (lo que oyó el motor -> lo que se le enseña):"]
    L += [f"  {n:4d}  {a}  ->  {b}" for (a, b), n in cambios.most_common(80)]
    L += ["", "Ejemplos al azar para revisar (oído / objetivo):"]
    for f in random.sample(arreglos, min(150, len(arreglos))):
        L += [f"  - {f['crudo']}", f"    {f['text']}"]
    L += ["", "Ejemplos sin cambios:"]
    sin = [f for f in todas if not f["arreglo"]]
    for f in random.sample(sin, min(30, len(sin))):
        L += [f"  = {f['text']}"]
    escritorio = next((p for p in (Path.home() / "Desktop", Path.home() / "Escritorio") if p.exists()), BASE)
    destino = escritorio / "VozRad-entrenamiento-resumen.txt"
    destino.write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n".join(L[:12 + len(motivos)]))
    print(f"\n[VozRad] Listo. Datos en {SALIDA}")
    print(f"[VozRad] Resumen para revisar: {destino} (sin audio; envíalo a Álvaro/Claude)")
    return 0


if __name__ == "__main__":
    sys.exit(main())

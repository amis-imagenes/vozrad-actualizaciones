@echo off
chcp 65001 >nul
title VozRad - importar correcciones compartidas
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Primero ejecuta instalar.bat
  pause & exit /b 1
)
.venv\Scripts\python.exe importar_correcciones.py
pause

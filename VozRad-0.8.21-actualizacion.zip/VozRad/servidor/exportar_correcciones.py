"""
VozRad - exporta TUS correcciones (sin informes ni dictados) para sumarlas a la próxima versión.

Deja en el Escritorio «VozRad-correcciones-<equipo>-<fecha>.json» con:
  - las correcciones de palabras y reglas que tú agregaste o que VozRad aprendió de ti
    (no las que ya trae el programa)
  - cuántas veces corregiste cada una (no las frases donde ocurrió)
  - las sugerencias que rechazaste (para no imponérselas a otros)
  - tu vocabulario, términos prioritarios, epónimos y frases tipo
Envía ese archivo a Álvaro. No contiene texto de informes, nombres de pacientes ni audio.
"""
import datetime as dt
import json
import socket
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
HIST = BASE / "historial"


def leer_json(ruta, defecto):
    try:
        return json.loads(ruta.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return defecto


def lista(nombre):
    r = BASE / nombre
    if not r.exists():
        return []
    return [l.strip() for l in r.read_text(encoding="utf-8").splitlines() if l.strip() and not l.startswith("#")]


def main():
    mig = leer_json(BASE / "actualizacion_datos.json", {})
    de_fabrica = {k.lower(): str(v).lower() for k, v in mig.get("palabras", {}).items()}
    reglas_fabrica = {r.get("patron") for r in mig.get("reglas", [])}
    mia = leer_json(BASE / "correcciones.json", {})
    palabras = {k: v for k, v in mia.get("palabras", {}).items() if de_fabrica.get(k.lower()) != str(v).lower()}
    reglas = [r for r in mia.get("reglas", []) if r.get("patron") not in reglas_fabrica]
    veces = {}
    ruta = HIST / "aprendido.jsonl"
    if ruta.exists():
        for l in ruta.read_text(encoding="utf-8", errors="ignore").splitlines():
            try:
                x = json.loads(l)
                veces[x["de"]] = max(veces.get(x["de"], 0), int(x.get("veces", 1)))
            except Exception:  # noqa: BLE001
                pass
    rechazadas = leer_json(HIST / "sugerencias_rechazadas.json", [])
    plantillas = leer_json(BASE / "plantillas.json", {})
    cfg = leer_json(BASE / "config.json", {})
    salida = {
        "_que_es": "Correcciones de dictado VozRad para combinar entre radiólogos. Sin informes ni datos de pacientes.",
        "equipo": socket.gethostname().replace(".local", ""),
        "fecha": dt.date.today().isoformat(),
        "version_datos": cfg.get("_version_datos"),
        "palabras": palabras,
        "veces": {k: v for k, v in veces.items() if k in palabras},
        "reglas": reglas,
        "rechazadas": rechazadas,
        "vocabulario": lista("vocabulario.txt"),
        "terminos_prioritarios": lista("terminos_prioritarios.txt"),
        "nombres_propios": " ".join(lista("nombres_propios.txt")).split(),
        "frases": {k: (v.get("texto", "") if isinstance(v, dict) else v) for k, v in plantillas.get("frases", {}).items()},
    }
    escritorio = next((p for p in (Path.home() / "Desktop", Path.home() / "Escritorio") if p.exists()), BASE)
    destino = escritorio / f"VozRad-correcciones-{salida['equipo']}-{salida['fecha']}.json"
    destino.write_text(json.dumps(salida, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"[VozRad] {len(palabras)} correcciones propias, {len(reglas)} reglas, {len(salida['frases'])} frases tipo.")
    print(f"[VozRad] Guardado en {destino}")
    print("Envíaselo a Álvaro: se suma a la próxima versión para todos.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

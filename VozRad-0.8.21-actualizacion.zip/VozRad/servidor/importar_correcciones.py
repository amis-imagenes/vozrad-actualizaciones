"""
VozRad - suma a TU perfil las correcciones y términos de otro radiólogo (carpeta «compartido»).

Solo AGREGA lo que no tienes: tus propias correcciones, vocabulario y frases tipo no se tocan.
No trae informes ni dictados de nadie (eso es dato clínico y cada uno arma el suyo).
"""
import json
import shutil
import sys
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent
ORIGEN = BASE / "compartido"


def leer_json(ruta, defecto):
    try:
        return json.loads(ruta.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return defecto


def respaldar(ruta):
    if ruta.exists():
        destino = BASE / "respaldos"
        destino.mkdir(exist_ok=True)
        shutil.copy2(ruta, destino / f"{ruta.stem}-antes-de-importar-{time.strftime('%Y%m%d-%H%M%S')}{ruta.suffix}")


def lineas(ruta):
    return ruta.read_text(encoding="utf-8").splitlines() if ruta.exists() else []


def main():
    if not ORIGEN.exists():
        print("No encuentro la carpeta «compartido» junto a este archivo."); return 1
    total = {}
    # correcciones (palabras y reglas)
    comp = leer_json(ORIGEN / "correcciones_compartidas.json", {})
    ruta = BASE / "correcciones.json"
    mia = leer_json(ruta, {"palabras": {}, "reglas": []})
    respaldar(ruta)
    pal = mia.setdefault("palabras", {})
    n = 0
    for de, a in comp.get("palabras", {}).items():
        if de not in pal:
            pal[de] = a; n += 1
    patrones = {r.get("patron") for r in mia.setdefault("reglas", [])}
    for r in comp.get("reglas", []):
        if r.get("patron") not in patrones:
            mia["reglas"].append(r); n += 1
    if "romanos" not in mia and comp.get("romanos"):
        mia["romanos"] = comp["romanos"]
    ruta.write_text(json.dumps(mia, ensure_ascii=False, indent=1), encoding="utf-8")
    total["correcciones"] = n
    # listas de términos
    for nombre in ("vocabulario.txt", "terminos_prioritarios.txt", "nombres_propios.txt"):
        src = ORIGEN / nombre
        if not src.exists():
            continue
        dst = BASE / nombre
        actuales = lineas(dst)
        tengo = {x.strip().lower() for x in " ".join(actuales).split()} if nombre == "nombres_propios.txt" else \
                {x.strip().lower() for x in actuales}
        nuevas = []
        for l in lineas(src):
            if not l.strip() or l.startswith("#"):
                continue
            if nombre == "nombres_propios.txt":
                nuevas += [w for w in l.split() if w.lower() not in tengo and w not in nuevas]
            elif l.strip().lower() not in tengo:
                nuevas.append(l.strip())
        if nuevas:
            respaldar(dst)
            sep = " " if nombre == "nombres_propios.txt" else "\n"
            texto = "\n".join(actuales).rstrip("\n")
            dst.write_text((texto + "\n" if texto else "") + sep.join(nuevas) + "\n", encoding="utf-8")
        total[nombre] = len(nuevas)
    # frases tipo
    fr = leer_json(ORIGEN / "frases_compartidas.json", {})
    ruta = BASE / "plantillas.json"
    p = leer_json(ruta, {})
    p.setdefault("plantillas", {}); p.setdefault("frases", {})
    n = 0
    for k, v in fr.items():
        if k not in p["frases"]:
            p["frases"][k] = v; n += 1
    if n:
        respaldar(ruta)
        ruta.write_text(json.dumps(p, ensure_ascii=False, indent=2), encoding="utf-8")
    total["frases tipo"] = n
    print("[VozRad] Agregado a tu perfil (lo tuyo se mantiene):")
    for k, v in total.items():
        print(f"   {k:28} {v}")
    print("Cierra y vuelve a abrir la ventana del motor (iniciar) para que se use.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/bin/bash
# VozRad - sumar las correcciones compartidas a tu perfil. Doble clic desde el Finder.
cd "$(dirname "$0")" || exit 1
printf '\033]0;VozRad - importar correcciones compartidas\007'
if [ ! -x .venv/bin/python ]; then echo "Primero haz doble clic en instalar.command"; read -r -p "Enter para cerrar..." _; exit 1; fi
.venv/bin/python importar_correcciones.py
read -r -p "Presiona Enter para cerrar..." _

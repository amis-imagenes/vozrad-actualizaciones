@echo off
chcp 65001 >nul
title VozRad - exportar mis correcciones
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Primero ejecuta instalar.bat
  pause & exit /b 1
)
.venv\Scripts\python.exe exportar_correcciones.py
pause

#!/usr/bin/env bash
# VozRad - prueba el contexto radiológico (modelo de idioma de tus informes y lista de términos) con tus
# frases de prueba. Uso en Ubuntu (motor de VozRad cerrado):  bash /mnt/c/VozRad/servidor/entrenar/contexto.sh
ENV="$HOME/vozrad-entrenar"
export PATH="$HOME/.local/bin:$PATH"
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:False
VIRTUAL_ENV="$ENV" uv pip install -q wordfreq "numba-cuda[cu13]" || echo "[VozRad] aviso: no se pudo instalar wordfreq"
"$ENV/bin/python" -u /mnt/c/VozRad/servidor/entrenar/contexto_nemo.py "$@" 2>&1 | tee /mnt/c/VozRad/entrenamiento/contexto.log

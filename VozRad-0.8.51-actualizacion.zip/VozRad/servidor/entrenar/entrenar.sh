#!/usr/bin/env bash
# VozRad - entrena Parakeet con tu voz.
#   bash /mnt/c/VozRad/servidor/entrenar/entrenar.sh --prueba    ensayo corto (~10 min), no guarda modelo
#   bash /mnt/c/VozRad/servidor/entrenar/entrenar.sh             entrenamiento completo
ENV="$HOME/vozrad-entrenar"
export PATH="$HOME/.local/bin:$PATH"
# en WSL el reservador «expandible» de PyTorch falla al mapear memoria (cuMemSetAccess): se usa el clásico
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:False
# componente de NVIDIA para calcular el error de Parakeet en la tarjeta (libNVVM); si ya está, no hace nada
VIRTUAL_ENV="$ENV" uv pip install -q "numba-cuda[cu13]" || echo "[VozRad] aviso: no se pudo instalar numba-cuda"
"$ENV/bin/python" -u /mnt/c/VozRad/servidor/entrenar/vozrad_nemo.py entrenar "$@" 2>&1 | tee /mnt/c/VozRad/entrenamiento/entrenar.log

"""
VozRad - contexto radiológico al reconocer (corre en Ubuntu/WSL con el entorno de instalar.sh).

Idea del Dr. Otárola: ante un sonido dudoso, el reconocedor debe preferir lo que se escribe en informes
radiológicos y solo después el español general. Se prueban dos formas que trae NeMo, ambas en la tarjeta:

  LM      un modelo de idioma (n-gramas sobre las piezas de texto del reconocedor) armado con tus informes,
          tus informes finales guardados y tus frases de entrenamiento -> pesa las secuencias habituales
  REFUERZO una lista de términos radiológicos de tus informes (poco comunes en español general) que reciben
          un pequeño premio cuando el reconocedor los empieza a escribir

y se mide cada combinación con tus 360 frases de prueba (las del último turno, que NO se usan para armar
nada de esto: se excluyen los informes guardados desde esa fecha). Si hay un modelo entrenado en
entrenamiento/modelos, también se mide con él.

Resultado: C:\\VozRad\\entrenamiento\\resultado-contexto.txt
"""
import argparse
import collections
import datetime as dt
import json
import math
import re
import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import vozrad_nemo as V  # noqa: E402  (prepara numba/NumPy/memoria y trae medir/cargar/normal)

SERV = Path("/mnt/c/VozRad/servidor")
ENT = V.ENT
CTX = ENT / "contexto"
OFFSET = 100            # NeMo: DEFAULT_TOKEN_OFFSET (cada pieza de texto se escribe como chr(id + 100))
PROTEGIDAS = {"derecho", "derecha", "derechos", "derechas", "izquierdo", "izquierda", "izquierdos", "izquierdas",
              "bilateral", "bilaterales", "leve", "leves", "moderado", "moderada", "moderados", "moderadas",
              "severo", "severa", "acentuado", "acentuada", "ascendente", "descendente", "superior", "inferior",
              "superiores", "inferiores", "anterior", "posterior", "proximal", "distal", "medial", "lateral"}


# ------------------------------------------------------------------------------------------- textos
def _jsonl(p: Path):
    if not p.exists():
        return
    for l in p.read_text(encoding="utf-8", errors="ignore").splitlines():
        try:
            yield json.loads(l)
        except json.JSONDecodeError:
            continue


def _hablado(linea: str) -> str:
    """Texto escrito de un informe -> forma dictada aproximada («… derecho, coma …, punto»)."""
    t = linea.strip()
    if not t:
        return ""
    termina = t.endswith(".")
    t = t.replace(";", " punto y coma ").replace(":", " dos puntos ")
    t = re.sub(r",", " coma", t)
    t = re.sub(r"\.(\s+)(?=\S)", r" punto\1", t)
    t = re.sub(r"[\"“”()\[\]]", " ", t).rstrip(" .")
    if termina:
        t += " punto aparte"
    return re.sub(r"\s+", " ", t).strip()


def corpus(L: list) -> tuple[list[str], collections.Counter]:
    """Líneas para el modelo de idioma + conteo de palabras (para la lista de términos)."""
    sys.path.insert(0, str(SERV))
    try:
        import texto
        limpiar = texto.limpiar_informe
        basura = texto.es_basura_informe
    except Exception:  # noqa: BLE001
        limpiar, basura = (lambda x: x), (lambda x: False)
    prueba = V.leer("prueba")
    desde = min((f.get("fecha") or "9999") for f in prueba)        # no usar informes del período de prueba
    lineas, palabras = [], collections.Counter()
    n_inf = n_fin = 0
    for r in _jsonl(SERV / "informes" / "informes.jsonl"):
        for v in (r.get("secciones") or {}).values():
            for l in limpiar(v or "").split("\n"):
                if l.strip() and not basura(l):
                    lineas.append(_hablado(l))
                    n_inf += 1
    fuentes = [SERV / "historial"] + [p.parent for p in (ENT).rglob("correcciones_manuales.jsonl")
                                      if "datos" not in p.parts]
    vistos = set()
    for h in fuentes:
        for r in _jsonl(h / "correcciones_manuales.jsonl"):
            if (r.get("hora") or "")[:10] >= desde:
                continue
            for v in (r.get("final") or {}).values():
                if v and v not in vistos:
                    vistos.add(v)
                    for l in limpiar(v).split("\n"):
                        if l.strip() and not basura(l):
                            lineas.append(_hablado(l))
                            n_fin += 1
    for l in lineas:
        palabras.update(w.lower() for w in re.findall(r"[^\W\d_]+", l))
    textos = [f["text"] for f in V.leer("entrenar")]
    lineas += textos * 3                                           # forma exacta en que el motor escribe
    L += [f"Textos: {n_inf} líneas de informes importados · {n_fin} de informes guardados (antes del {desde}) · "
          f"{len(textos)} frases de entrenamiento (×3)"]
    return [l for l in lineas if l], palabras


NOMBRES = {"salazar", "martinez", "martínez", "alfonso", "sebastian", "sebastián", "mauricio", "gomez", "gómez",
           "matus", "vivanco", "villanueva", "pablo", "juan", "jose", "josé", "maria", "maría", "gonzalez",
           "gonzález", "lopez", "lópez", "rodriguez", "rodríguez", "perez", "pérez", "munoz", "muñoz", "rojas",
           "diaz", "díaz", "soto", "contreras", "silva", "morales", "sepulveda", "sepúlveda", "araya", "fuentes"}


def diccionario(L: list) -> collections.Counter:
    """Diccionario de palabras frecuentes en informes radiológicos reales («frecuencia#palabra»), si está en
    entrenamiento/contexto/diccionario.txt. Se descartan nombres y palabras pegadas («significativaecotomografía»)."""
    p = next((x for x in (CTX / "diccionario.txt", CTX / "Diccionario.txt") if x.exists()), None)
    if not p:
        return collections.Counter()
    crudo = collections.Counter()
    for l in p.read_text(encoding="utf-8", errors="ignore").splitlines():
        n, _, w = l.partition("#")
        w = w.strip().lower()
        if n.strip().isdigit() and re.fullmatch(r"[^\W\d_]+", w):
            crudo[w] += int(n)
    conocidas = {w for w, c in crudo.items() if c >= 20 and len(w) >= 4}
    out = collections.Counter()
    pegadas = 0
    for w, c in crudo.items():
        if w in NOMBRES:
            continue
        if any(w[:i] in conocidas and w[i:] in conocidas for i in range(4, len(w) - 3)):
            pegadas += 1
            continue
        out[w] = c
    L += [f"Diccionario radiológico: {len(out)} palabras ({pegadas} pegadas descartadas)"]
    return out


def terminos(palabras: collections.Counter, maximo: int, dicc: collections.Counter | None = None) -> list[str]:
    """Términos radiológicos: frecuentes en tus informes (o en el diccionario radiológico) y poco comunes en el
    español general. Del diccionario solo entran palabras que también aparecen en tus textos (así no se
    premian errores de tipeo que traía, como «sibmandibulares»)."""
    try:
        from wordfreq import zipf_frequency
    except ImportError:
        zipf_frequency = None
    puntaje = collections.Counter()
    for w, c in palabras.items():
        if c >= 5:
            puntaje[w] += c
    total_d = sum((dicc or {}).values()) or 1
    total_p = sum(palabras.values()) or 1
    for w, c in (dicc or {}).items():
        if palabras[w] >= 1 and c >= 20:                  # solo si también la usas tú (evita errores de tipeo)
            puntaje[w] += c * total_p / total_d          # misma escala que tus informes
    # si existe la forma con tilde, la sin tilde se descarta (higado/hígado)
    sin_tilde = {V.unicodedata.normalize("NFD", w).encode("ascii", "ignore").decode(): w for w in puntaje
                 if not w.isascii()}
    out = []
    for w, _ in puntaje.most_common():
        if len(w) < 5 or w in PROTEGIDAS or w in V.CRITICAS or w in NOMBRES:
            continue
        if w.isascii() and w in sin_tilde:
            continue
        if zipf_frequency and zipf_frequency(w, "es") >= 3.0:
            continue
        out.append(w)
        if len(out) >= maximo:
            break
    return out


# ------------------------------------------------------------------------------------- modelo de idioma
BOS, EOS = "\x01", "\x02"     # inicio/fin de frase dentro de las cadenas (cada pieza = un carácter)


def _simbolos(k: str) -> str:
    return " ".join("<s>" if c == BOS else "</s>" if c == EOS else c for c in k)


def arpa(lineas: list[str], tok, destino: Path, orden: int, L: list, D: float = 0.7):
    """Modelo de n-gramas sobre las piezas del reconocedor (descuento absoluto interpolado, formato ARPA).
    Ahorra memoria: líneas repetidas se cuentan una vez (con su multiplicidad) y cada n-grama es una cadena."""
    import gc
    t0 = time.time()
    unicas = collections.Counter(lineas)
    cnt = [collections.Counter() for _ in range(orden + 1)]
    for l, veces in unicas.items():
        ids = BOS + "".join(chr(i + OFFSET) for i in tok.text_to_ids(l)) + EOS
        for n in range(1, orden + 1):
            c = cnt[n]
            for i in range(len(ids) - n + 1):
                c[ids[i:i + n]] += veces
    del unicas
    # poda: n-gramas de orden ≥3 vistos una sola vez (conserva prefijos y sufijos: sus conteos son ≥)
    for n in range(3, orden + 1):
        cnt[n] = collections.Counter({k: v for k, v in cnt[n].items() if v >= 2})
        gc.collect()
    total1 = sum(v for k, v in cnt[1].items() if k != BOS)
    prob = [dict() for _ in range(orden + 1)]
    prob[1] = {k: v / total1 for k, v in cnt[1].items() if k != BOS}
    back = [dict() for _ in range(orden + 1)]
    for n in range(2, orden + 1):
        hist_tot, hist_dist = collections.Counter(), collections.Counter()
        for k, v in cnt[n].items():
            hist_tot[k[:-1]] += v
            hist_dist[k[:-1]] += 1
        gam = {h: D * hist_dist[h] / hist_tot[h] for h in hist_tot}
        back[n - 1] = gam
        p = {}
        for k, v in cnt[n].items():
            h = k[:-1]
            inferior = prob[n - 1].get(k[1:])
            if inferior is None:          # sufijo podado: se usa la cadena de respaldo
                inferior = _p(prob, back, k[1:])
            p[k] = max(v - D, 0) / hist_tot[h] + gam[h] * inferior
        prob[n] = p
        cnt[n] = None
        gc.collect()
    with open(destino, "w", encoding="utf-8") as f:
        f.write("\\data\\\n")
        tamaños = [len(prob[1]) + 2] + [len(prob[n]) for n in range(2, orden + 1)]
        for n, t in enumerate(tamaños, 1):
            f.write(f"ngram {n}={t}\n")
        for n in range(1, orden + 1):
            f.write(f"\n\\{n}-grams:\n")
            if n == 1:
                f.write(f"-99\t<s>\t{math.log10(back[1].get(BOS, 1.0)):.6f}\n")
                f.write("-7.000000\t<unk>\n")
            for k in sorted(prob[n]):
                linea = f"{math.log10(max(prob[n][k], 1e-12)):.6f}\t{_simbolos(k)}"
                if n < orden and k in back[n]:
                    linea += f"\t{math.log10(back[n][k]):.6f}"
                f.write(linea + "\n")
        f.write("\n\\end\\\n")
    L += [f"Modelo de idioma: orden {orden}, " + ", ".join(f"{len(prob[n])} de orden {n}" for n in range(1, orden + 1))
          + f" · {time.time() - t0:.0f} s · {destino.stat().st_size / 2**20:.0f} MB"]


def _p(prob, back, k):
    """Probabilidad con respaldo para un n-grama que no está en la tabla."""
    if len(k) == 1:
        return prob[1].get(k, 1e-7)
    if k in prob[len(k)]:
        return prob[len(k)][k]
    return back[len(k) - 1].get(k[:-1], 1.0) * _p(prob, back, k[1:])


# ------------------------------------------------------------------------------------------ pruebas
def decodificar(m, lm: Path | None, alfa: float, lista: Path | None, beta: float, haz: int = 0):
    import copy
    from omegaconf import open_dict
    cfg = copy.deepcopy(m.cfg.decoding)
    with open_dict(cfg):
        if haz:
            cfg.strategy = "malsd_batch"
            cfg.beam.beam_size = haz
            cfg.beam.return_best_hypothesis = True
            rama = cfg.beam
        else:
            cfg.strategy = "greedy_batch"
            rama = cfg.greedy
        rama.ngram_lm_model = str(lm) if lm else None
        rama.ngram_lm_alpha = alfa if lm else 0.0
        if lista:
            rama.boosting_tree = {"key_phrases_file": str(lista), "source_lang": "es", "context_score": 1.0,
                                  "depth_scaling": 2.0, "use_triton": True}
            rama.boosting_tree_alpha = beta
        else:
            if "boosting_tree" in rama:
                rama.boosting_tree = {"key_phrases_file": None}
            rama.boosting_tree_alpha = 0.0
    m.change_decoding_strategy(cfg, verbose=False)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--orden", type=int, default=4)
    p.add_argument("--terminos", type=int, default=3000)
    p.add_argument("--rapido", action="store_true", help="menos combinaciones")
    p.add_argument("--modelos", type=int, default=3, help="cuántos modelos entrenados (los más recientes) se prueban")
    p.add_argument("--alfas", default="", help="pesos del modelo de idioma, p. ej. 0.1,0.2,0.3")
    p.add_argument("--betas", default="", help="pesos de la lista de términos")
    p.add_argument("--combinados", default="", help="pares alfa:beta, p. ej. 0.2:0.5,0.3:0.5")
    p.add_argument("--haz-alfas", default="", help="pesos del modelo de idioma con búsqueda en haz")
    p.add_argument("--nombre", default="")
    a = p.parse_args()
    L = [f"VozRad - contexto radiológico ({dt.datetime.now():%d-%m-%Y %H:%M})", ""]
    try:
        CTX.mkdir(parents=True, exist_ok=True)
        lineas, palabras = corpus(L)
        lista = terminos(palabras, a.terminos, diccionario(L))
        ruta_lista = CTX / "terminos.txt"
        variantes = []
        for w in lista:
            variantes += [w, w[:1].upper() + w[1:]]
        ruta_lista.write_text("\n".join(variantes) + "\n", encoding="utf-8")
        L += [f"Términos radiológicos: {len(lista)} (p. ej. {', '.join(lista[:25])})"]
        modelos = [("ORIGINAL", None)]
        entrenados = sorted((ENT / "modelos").glob("vozrad-*.nemo"))[-a.modelos:] if a.modelos else []
        modelos += [(f"ENTRENADO {e.name}", str(e)) for e in entrenados]
        prueba = V.leer("prueba")
        ruta_lm = CTX / f"radiologia-{a.orden}.arpa"
        resumen = []
        for nombre, ruta in modelos:
            m = V.cargar(ruta)
            if not ruta_lm.exists() or ruta_lm.stat().st_mtime < (SERV / "informes" / "informes.jsonl").stat().st_mtime:
                arpa(lineas, m.tokenizer, ruta_lm, a.orden, L)
            combos = [("sin contexto", None, 0, None, 0, 0)]
            if a.alfas:
                alfas = [float(x) for x in a.alfas.split(",")]
            else:
                alfas = (0.3, 0.6) if a.rapido else (0.2, 0.4, 0.6, 0.8)
            combos += [(f"LM α={x}", ruta_lm, x, None, 0, 0) for x in alfas]
            if a.betas:
                betas = [float(x) for x in a.betas.split(",")]
            else:
                betas = (1.0,) if a.rapido else (0.5, 1.0, 2.0)
            combos += [(f"REFUERZO β={b}", None, 0, ruta_lista, b, 0) for b in betas]
            combos += [(f"LM α={x} + REFUERZO β={b}", ruta_lm, x, ruta_lista, b, 0)
                       for x, b in ([(0.4, 1.0)] if not a.combinados else
                                    [tuple(map(float, c.split(":"))) for c in a.combinados.split(",")])]
            combos += [(f"haz 4 + LM α={x}", ruta_lm, x, None, 0, 4)
                       for x in ([0.4] if not a.haz_alfas else [float(v) for v in a.haz_alfas.split(",")])]
            L += ["", f"== Modelo {nombre} =="]
            base = None
            for etiqueta, lm, alfa, lst, beta, haz in combos:
                try:
                    t0 = time.time()
                    decodificar(m, lm, alfa, lst, beta, haz)
                    sub = []
                    r = V.medir(m, prueba, f"  {etiqueta:<28}", sub)
                    L += [sub[0] + f" (incl. carga {time.time() - t0:.0f} s)"]
                    if base is None:
                        base = r
                    resumen.append((r["wer"], r["criticos"], nombre, etiqueta, r, base))
                except Exception as e:  # noqa: BLE001
                    L += [f"  {etiqueta:<28} ERROR: {str(e).splitlines()[0][:200]}"]
                    print(traceback.format_exc(), flush=True)
                print("\n".join(L[-1:]), flush=True)
            del m
        mejores = sorted([x for x in resumen if x[1] <= min(y[1] for y in resumen if y[3] == "sin contexto")],
                         key=lambda x: x[0])
        if mejores:
            w, c, nombre, etiqueta, r, base = mejores[0]
            L += ["", f"MEJOR (sin más errores críticos): modelo {nombre} · {etiqueta} · {100 * w:.2f} % "
                      f"(sin contexto {100 * base['wer']:.2f} %) · críticos {c}"]
            L += ["", "Frases que cambiaron con el mejor contexto (objetivo / sin contexto / con contexto):"]
            n = 0
            for f, h0, h1 in zip(prueba, base["hips"], r["hips"]):
                if V.normal(h0) != V.normal(h1) and n < 60:
                    L += [f"  = {f['text']}", f"    sin  {h0}", f"    con  {h1}"]
                    n += 1
    except Exception:  # noqa: BLE001
        L += ["", "ERROR:", traceback.format_exc()]
    texto_res = "\n".join(L) + "\n"
    salida = ENT / f"resultado-contexto{'-' + a.nombre if a.nombre else ''}.txt"
    salida.write_text(texto_res, encoding="utf-8")
    print("\n" + texto_res[:6000])
    print(f"[VozRad] Resultado en C:\\VozRad\\entrenamiento\\{salida.name}")


if __name__ == "__main__":
    main()

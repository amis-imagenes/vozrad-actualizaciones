#!/usr/bin/env bash
# VozRad - mide los errores del modelo original con tus frases de prueba (5-10 minutos).
# Uso en Ubuntu:  bash /mnt/c/VozRad/servidor/entrenar/medir.sh
# en WSL el reservador «expandible» de PyTorch falla al mapear memoria (cuMemSetAccess): se usa el clásico
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:False
"$HOME/vozrad-entrenar/bin/python" -u /mnt/c/VozRad/servidor/entrenar/vozrad_nemo.py medir "$@" 2>&1 | tee /mnt/c/VozRad/entrenamiento/medir.log
